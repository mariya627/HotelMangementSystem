using DBMS_HMS;
using hotalMS;
using System.Data.SqlClient;

namespace hotalMS
{
    public partial class Form1 : Form
    {
        private Button currentButton;
        private Random random;
        private int tempIndex;
        private Form activeForm;
        private Button previousButton;
        private PictureBox previousBtn;
        private Color originalIconBoxColor;
        public Form1()
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterScreen;
            random = new Random();

        }
        // SqlConnection con = new SqlConnection("Data Source=DESKTOP-KFDUOB5\\MSSQLSERVER2022;Initial Catalog=HotelManagementSystem;Integrated Security=True;Encrypt=True;Trust Server Certificate=True");

        private Color SelectThemeColor()
        {
            int index = random.Next(ThemeColor.ColorList.Count);
            while (tempIndex == index)
            {
                random.Next(ThemeColor.ColorList.Count);
            }
            tempIndex = index;
            string color = ThemeColor.ColorList[index];
            return ColorTranslator.FromHtml(color);
        }
        private void ActivateButton(object btnSender, PictureBox iconBox)
        {
            if (btnSender != null)
            {
                if (currentButton != (Button)btnSender)
                {
                    DisableButton();
                    Color color = SelectThemeColor();
                    currentButton = (Button)btnSender;
                    currentButton.BackColor = color;
                    currentButton.ForeColor = Color.White;
                    currentButton.Font = new Font("Segoe UI", 12.5F, FontStyle.Bold, GraphicsUnit.Point, 0);
                    paneltitle.BackColor = color;
                    panellogo.BackColor = ThemeColor.ChangeColorBrightness(color, -0.3);

                    // Change the color of the current button's associated iconbox
                    iconBox.BackColor = color;

                    // Save the current iconbox and its original color for future reference
                    previousButton = currentButton;
                    previousBtn = iconBox;
                    originalIconBoxColor = Color.FromArgb(51, 51, 76);
                }
            }
        }

        private void DisableButton()
        {
            if (previousButton != null && previousBtn != null)
            {
                previousButton.BackColor = Color.FromArgb(51, 51, 76);
                previousButton.ForeColor = Color.Gainsboro;
                previousButton.Font = new Font("Segoe UI", 10F, FontStyle.Bold, GraphicsUnit.Point, 0);
                previousBtn.BackColor = originalIconBoxColor;
            }
        }
        private void openChildForm(Form childform, object btnSender, PictureBox iconBox)
        {
            if (activeForm != null)
            {
                activeForm.Close();
            }
            //ActivateButton(btnSender, iconBox);
            //activeForm = childform;
            //childform.TopLevel = false;
            //childform.FormBorderStyle = FormBorderStyle.None;
            //childform.Dock = DockStyle.Fill;
            //this.paneldesktop.Controls.Add(childform);
            //this.paneldesktop.Tag = childform;
            //childform.BringToFront();
            //childform.Show();
            //labeltitle.Text = childform.Text;

            ActivateButton(btnSender, iconBox);
            activeForm = childform;
            childform.TopLevel = false;
            childform.FormBorderStyle = FormBorderStyle.None;
            childform.Dock = DockStyle.Fill;
            this.paneldesktop.Controls.Add(childform);
            this.paneldesktop.Tag = childform;
            childform.BringToFront();
            childform.Show();

            // Explicitly set the label text after changing the form name
            labeltitle.Text = childform.Text;



        }

        private void Guestbtn_Click(object sender, EventArgs e)
        {

        }

        private void Guestbtn_Click_1(object sender, EventArgs e)
        {
            ActivateButton(sender, iconguest);
            openChildForm(new Guest(), sender, iconguest); //formis a folder which havemultiple forms
        }

        private void Resbtn_Click(object sender, EventArgs e)
        {
            ActivateButton(sender, iconres);
            openChildForm(new Reservation(), sender, iconres);
        }

        private void Employeebtn_Click(object sender, EventArgs e)
        {
            ActivateButton(sender, iconbox2);
        }

        private void Membershipbtn_Click(object sender, EventArgs e)
        {
            ActivateButton(sender, iconmem);
           openChildForm(new forms.Membership(), sender, iconguest);

        }

        private void serbtn_Click(object sender, EventArgs e)
        {
            //ActivateButton(sender);
        }

        private void facbtn_Click(object sender, EventArgs e)
        {
            ActivateButton(sender, iconfac);
            //openChildForm(new Form1(), sender, iconguest);
        }

        private void serbtn_Click_1(object sender, EventArgs e)
        {
            ActivateButton(sender, iconservice);
           openChildForm(new forms.Services(), sender, iconservice);
        }

        private void checkoutbtn_Click(object sender, EventArgs e)
        {
            ActivateButton(sender, iconcheckout);
            openChildForm(new forms.CheckOut(), sender, iconguest);
        }

        private void iconPictureBox4_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void iconPictureBox2_Click(object sender, EventArgs e)
        {
            LOGIN l = new LOGIN();
            this.Hide();
            l.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ActivateButton(sender, iconfac);
            openChildForm(new Reservation(), sender, iconguest);
        }

        private void RoomDbtn_Click(object sender, EventArgs e)
        {
            ActivateButton(sender, iconroomD);
            openChildForm(new forms.RoomDetail(), sender, iconguest);
        }

        private void logoutbtn_Click(object sender, EventArgs e)
        {
            ActivateButton(sender, iconlog);
            LOGIN l = new LOGIN();
            this.Hide();
            l.Show();
        }
    }
}

﻿using DBMS_HMS;
using hotalMS.forms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace hotalMS
{
    public partial class Form2 : Form
    {

        private Button currentButton;
        private Random random;
        private int tempIndex;
        private Form activeForm;
        private Button previousButton;
        private PictureBox previousBtn;
        private Color originalIconBoxColor;
        public Form2()
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterScreen;
            random = new Random();
        }

        private Color SelectThemeColor()
        {
            int index = random.Next(ThemeColor.ColorList.Count);
            while (tempIndex == index)
            {
                random.Next(ThemeColor.ColorList.Count);
            }
            tempIndex = index;
            string color = ThemeColor.ColorList[index];
            return ColorTranslator.FromHtml(color);
        }
        private void ActivateButton(object btnSender, PictureBox iconBox)
        {
            if (btnSender != null)
            {
                if (currentButton != (Button)btnSender)
                {
                    DisableButton();
                    Color color = SelectThemeColor();
                    currentButton = (Button)btnSender;
                    currentButton.BackColor = color;
                    currentButton.ForeColor = Color.White;
                    currentButton.Font = new Font("Segoe UI", 12.5F, FontStyle.Bold, GraphicsUnit.Point, 0);
                    paneltitle.BackColor = color;
                    panellogo.BackColor = ThemeColor.ChangeColorBrightness(color, -0.3);

                    // Change the color of the current button's associated iconbox
                    iconBox.BackColor = color;

                    // Save the current iconbox and its original color for future reference
                    previousButton = currentButton;
                    previousBtn = iconBox;
                    originalIconBoxColor = Color.FromArgb(51, 51, 76);
                }
            }
        }

        private void DisableButton()
        {
            if (previousButton != null && previousBtn != null)
            {
                previousButton.BackColor = Color.FromArgb(51, 51, 76);
                previousButton.ForeColor = Color.Gainsboro;
                previousButton.Font = new Font("Segoe UI", 10F, FontStyle.Bold, GraphicsUnit.Point, 0);
                previousBtn.BackColor = originalIconBoxColor;
            }
        }
        private void openChildForm(Form childform, object btnSender, PictureBox iconBox)
        {
            if (activeForm != null)
            {
                activeForm.Close();
            }
            ActivateButton(btnSender, iconBox);
            activeForm = childform;
            childform.TopLevel = false;
            childform.FormBorderStyle = FormBorderStyle.None;
            childform.Dock = DockStyle.Fill;
            this.paneldesktop.Controls.Add(childform);
            this.paneldesktop.Tag = childform;
            childform.BringToFront();
            childform.Show();

            // Explicitly set the label text after changing the form name
            labeltitle.Text = childform.Text;



        }

        private void Manageuserbtn_Click(object sender, EventArgs e)
        {
            ActivateButton(sender, iconuser);
            openChildForm(new Users(), sender, iconuser);
        }

        private void logoutbtn_Click(object sender, EventArgs e)
        {
            ActivateButton(sender, iconlog);
            LOGIN L = new LOGIN();
            this.Hide();
            L.Show();
        }

        private void notifyIcon1_MouseDoubleClick(object sender, MouseEventArgs e)
        {

        }

        private void ManageRoombtn_Click(object sender, EventArgs e)
        {
            ActivateButton(sender, iconroom);
            openChildForm(new Admin_Room(), sender, iconroom);
        }

        private void viewdetailbtn_Click(object sender, EventArgs e)
        {
            ActivateButton(sender, icondetail);


            openChildForm(new forms.ViewDetails(), sender, iconroom);
            

        }

        private void Guestlbl_Click(object sender, EventArgs e)
        {
            //ActivateButton(sender, icondetail);
            //openChildForm(new forms.GuestDetail(), sender, icondetail);

        }

        private void guestbtn_Click(object sender, EventArgs e)
        {
           
        }

        private void label2_Click(object sender, EventArgs e)
        {
           
        }
    }
}

﻿using FontAwesome.Sharp;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;
using System.Windows.Forms;

namespace hotalMS.forms
{
    public partial class Services : Form
    {
        public Services()
        {
            InitializeComponent();
        }
        SqlConnection con = new SqlConnection("Data Source=DESKTOP-KFDUOB5\\MSSQLSERVER2022;Initial Catalog=HotelManagementSystem;Integrated Security=True;Encrypt=True;TrustServerCertificate=True");

        private void Addsalbtn_Click(object sender, EventArgs e)
        {
            int roomNo;
            string serviceName;
            string serviceDescription;
            int servicePrice;

            // Parse the input values from textboxes
            if (!int.TryParse(RNotxt.Text, out roomNo))
            {
                MessageBox.Show("Invalid Room Number");
                return;
            }

            serviceName = snametxt.Text;
            serviceDescription = destxt.Text;

            if (!int.TryParse(pritxt.Text, out servicePrice))
            {
                MessageBox.Show("Invalid Service Price");
                return;
            }

            try
            {
                con.Open();

                // Retrieve the room status from the database
                SqlCommand roomStatusCommand = new SqlCommand("SELECT Room_Status FROM room WHERE Room_No = @RoomNo", con);
                roomStatusCommand.Parameters.AddWithValue("@RoomNo", roomNo);

                string roomStatus = (string)roomStatusCommand.ExecuteScalar();

                // Check if the room status is "Vacant"
                if (roomStatus == "Vacant")
                {
                    MessageBox.Show("This room is empty. There is no guest available.");
                    return;
                }

                // Insert the service into the database
                SqlCommand command = new SqlCommand("ServiceInsert", con);
                command.CommandType = CommandType.StoredProcedure;

                command.Parameters.AddWithValue("@Room_No", roomNo);
                command.Parameters.AddWithValue("@Service_Name", serviceName);
                command.Parameters.AddWithValue("@Service_Description", serviceDescription);
                command.Parameters.AddWithValue("@Service_Price", servicePrice);

                command.ExecuteNonQuery();

                MessageBox.Show("Service added successfully!");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                con.Close();
            }
        }

        public void populate()
        {
            con.Open();
           string query = "select * from RoomServicesView";
           
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.ExecuteNonQuery();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            SqlCommandBuilder cb = new SqlCommandBuilder(da);
            var ds = new DataSet();
            da.Fill(ds);
            salgrid.DataSource = ds.Tables[0];
            con.Close();
        }

        private void searchbtn_Click(object sender, EventArgs e)
        {
           
            Search();

        }


        public void Search()
        {
            try
            {

                if (sertext.SelectedItem == null)
                {
                    MessageBox.Show("Please select a search option (SearchByID or SearchByRoomNo).");
                    return;
                }
                using (SqlConnection con = new SqlConnection("Data Source=DESKTOP-KFDUOB5\\MSSQLSERVER2022;Initial Catalog=HotelManagementSystem;Integrated Security=True;Encrypt=True;TrustServerCertificate=True"))
                {
                    con.Open();
                SqlDataAdapter adapter = new SqlDataAdapter();
                SqlCommand command;

                string searchTerm = searchtxt.Text.Trim();

                    if (sertext.SelectedItem.ToString() == "SearchByID")
                    {
                        // Search by ID
                        if (int.TryParse(searchTerm, out int serviceID))
                        {
                            command = new SqlCommand("SearchServiceByIDD", con);
                            command.CommandType = CommandType.StoredProcedure;
                            command.Parameters.AddWithValue("@ServiceID", serviceID);
                        }
                        else
                        {
                            MessageBox.Show("Invalid Service ID. Please enter a valid integer value.");
                            return;
                        }
                    }
                    else if (sertext.SelectedItem.ToString() == "SearchByRoomNo")
                    {
                        // Search by Room No
                        if (int.TryParse(searchTerm, out int roomNo))
                        {
                            command = new SqlCommand("SearchRoomByRoomNo", con);
                            command.CommandType = CommandType.StoredProcedure;
                            command.Parameters.AddWithValue("@RoomNo", roomNo);
                        }
                        else
                        {
                            MessageBox.Show("Invalid Room No. Please enter a valid integer value.");
                            return;
                        }
                    }
                    else
                    {
                        MessageBox.Show("Invalid search type selected.");
                        return;
                    }

                    DataTable dataTable = new DataTable();
                    adapter.SelectCommand = command;

                    adapter.Fill(dataTable);

                    if (dataTable.Rows.Count == 0)
                    {
                        MessageBox.Show("No matching records found.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    else
                    {
                        salgrid.DataSource = dataTable;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
            finally
            {
                con.Close();
            }
        }


      



        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                int serviceID = int.Parse(searchtxt.Text);
                con.Open();
                SqlCommand command = new SqlCommand("DeleteService", con);
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@Service_ID", serviceID);

                int rowsAffected = command.ExecuteNonQuery();

                if (rowsAffected > 0)
                {
                    MessageBox.Show("Service deleted successfully!");
                }
                else
                {
                    MessageBox.Show("Service ID not found in the database.");
                }
            }
            catch (FormatException)
            {
                MessageBox.Show("Invalid Service ID. Please enter a valid integer value.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
            finally
            {
                con.Close();
            }
        }

        private void updatebtn_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                int serviceID = int.Parse(Upidtxt.Text);
                int roomNo = int.Parse(uRtxt.Text);
                string serviceName = Usnametxt.Text;
                string serviceDescription = Udestxt.Text;
                int servicePrice = int.Parse(Upritxt.Text);

                // Check if the entered Room_No exists with Room_Status as "Occupied" in the Room table
                SqlCommand checkRoomCommand = new SqlCommand("SELECT COUNT(*) FROM Room WHERE Room_No = @Room_No AND Room_Status = 'Occupied'", con);
                checkRoomCommand.Parameters.AddWithValue("@Room_No", roomNo);

                int roomCount = (int)checkRoomCommand.ExecuteScalar();

                if (roomCount == 0)
                {
                    MessageBox.Show("Invalid Room_No. Room with the given Room_No is either not found or not in 'Occupied' status.");
                    return;
                }

                SqlCommand command = new SqlCommand("UpdateService", con);
                command.CommandType = CommandType.StoredProcedure;

                command.Parameters.AddWithValue("@Service_ID", serviceID);
                command.Parameters.AddWithValue("@Room_No", roomNo);
                command.Parameters.AddWithValue("@Service_Name", serviceName);
                command.Parameters.AddWithValue("@Service_Description", serviceDescription);
                command.Parameters.AddWithValue("@Service_Price", servicePrice);

                command.ExecuteNonQuery();

                MessageBox.Show("Service updated successfully!");
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
            finally
            {
                con.Close();
            }
        }


        private void FillDataByID(int serviceID)
        {
            try
            {
                con.Open();

                // Retrieve the service details
                SqlCommand command = new SqlCommand("SELECT * FROM Services WHERE Service_ID = @Service_ID", con);
                command.Parameters.AddWithValue("@Service_ID", serviceID);

                SqlDataReader reader = command.ExecuteReader();

                if (reader.Read())
                {
                    string roomID = reader["Room_ID"].ToString();
                    string serviceName = reader["Service_Name"].ToString();
                    string serviceDescription = reader["Service_Description"].ToString();
                    string servicePrice = reader["Service_Price"].ToString();

                    reader.Close(); // Close the first DataReader

                    // Retrieve the room number
                    SqlCommand roomCommand = new SqlCommand("SELECT Room_No FROM Room WHERE Room_ID = @Room_ID", con);
                    roomCommand.Parameters.AddWithValue("@Room_ID", int.Parse(roomID));

                    SqlDataReader roomReader = roomCommand.ExecuteReader();

                    if (roomReader.Read())
                    {
                        string roomNumber = roomReader["Room_No"].ToString();

                        // Assign the retrieved values to the respective textboxes
                        uRtxt.Text = roomNumber;
                        Usnametxt.Text = serviceName;
                        Udestxt.Text = serviceDescription;
                        Upritxt.Text = servicePrice;

                    }

                    roomReader.Close(); // Close the second DataReader
                }
                else
                {
                    MessageBox.Show("Service ID not found in the database.");
                    // Clear the textboxes if the service ID is not found
                    uRtxt.Text = "";
                    Usnametxt.Text = "";
                    Udestxt.Text = "";
                    Upritxt.Text = "";

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
            finally
            {
                con.Close();
            }

        }

        private string GetRoomNumberByRoomID(int roomID)
        {
            string roomNumber = "";

            try
            {
                SqlCommand command = new SqlCommand("SELECT Room_No FROM Room WHERE Room_ID = @Room_ID", con);
                command.Parameters.AddWithValue("@Room_ID", roomID);

                SqlDataReader reader = command.ExecuteReader();

                if (reader.Read())
                {
                    roomNumber = reader["Room_No"].ToString();
                }

                reader.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }

            return roomNumber;
        }

        private void Upidtxt_TextChanged(object sender, EventArgs e)
        {
            if (int.TryParse(Upidtxt.Text, out int serviceID))
            {
                FillDataByID(serviceID);
            }
        }

        private void Disbtn_Click(object sender, EventArgs e)
        {
            populate();
        }

        private void RNotxt_TextChanged(object sender, EventArgs e)
        {

        }
    }
}

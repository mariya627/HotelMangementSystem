﻿
namespace DBMS_HMS
{
    partial class Users
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            tabControl1 = new TabControl();
            tabPage1 = new TabPage();
            panel4 = new Panel();
            panel5 = new Panel();
            panel6 = new Panel();
            panel2 = new Panel();
            panel1 = new Panel();
            panel3 = new Panel();
            iconPictureBox5 = new FontAwesome.Sharp.IconPictureBox();
            label3 = new Label();
            iconPictureBox4 = new FontAwesome.Sharp.IconPictureBox();
            label1 = new Label();
            iconPictureBox1 = new FontAwesome.Sharp.IconPictureBox();
            label8 = new Label();
            addbtn = new Button();
            Passwordtxt = new TextBox();
            UserNametxt = new TextBox();
            tabPage2 = new TabPage();
            panel7 = new Panel();
            iconPictureBox10 = new FontAwesome.Sharp.IconPictureBox();
            label15 = new Label();
            iconPictureBox2 = new FontAwesome.Sharp.IconPictureBox();
            label7 = new Label();
            button2 = new Button();
            searchbtn = new Button();
            Idtxt = new TextBox();
            dataGridView1 = new DataGridView();
            tabPage3 = new TabPage();
            panel14 = new Panel();
            panel15 = new Panel();
            panel16 = new Panel();
            panel11 = new Panel();
            panel12 = new Panel();
            panel13 = new Panel();
            panel8 = new Panel();
            panel9 = new Panel();
            iconPictureBox7 = new FontAwesome.Sharp.IconPictureBox();
            label2 = new Label();
            iconPictureBox8 = new FontAwesome.Sharp.IconPictureBox();
            label4 = new Label();
            iconPictureBox6 = new FontAwesome.Sharp.IconPictureBox();
            label5 = new Label();
            iconPictureBox3 = new FontAwesome.Sharp.IconPictureBox();
            label9 = new Label();
            button4 = new Button();
            UIdtxt = new TextBox();
            button3 = new Button();
            UPass = new TextBox();
            UName = new TextBox();
            tabControl1.SuspendLayout();
            tabPage1.SuspendLayout();
            panel4.SuspendLayout();
            panel5.SuspendLayout();
            panel2.SuspendLayout();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox5).BeginInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox1).BeginInit();
            tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox10).BeginInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            tabPage3.SuspendLayout();
            panel14.SuspendLayout();
            panel15.SuspendLayout();
            panel11.SuspendLayout();
            panel12.SuspendLayout();
            panel8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox7).BeginInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox8).BeginInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox6).BeginInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox3).BeginInit();
            SuspendLayout();
            // 
            // tabControl1
            // 
            tabControl1.Alignment = TabAlignment.Bottom;
            tabControl1.Controls.Add(tabPage1);
            tabControl1.Controls.Add(tabPage2);
            tabControl1.Controls.Add(tabPage3);
            tabControl1.Dock = DockStyle.Fill;
            tabControl1.Location = new Point(0, 0);
            tabControl1.Margin = new Padding(2);
            tabControl1.Name = "tabControl1";
            tabControl1.SelectedIndex = 0;
            tabControl1.Size = new Size(880, 420);
            tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            tabPage1.BackColor = Color.FromArgb(51, 51, 76);
            tabPage1.Controls.Add(panel4);
            tabPage1.Controls.Add(panel2);
            tabPage1.Controls.Add(iconPictureBox5);
            tabPage1.Controls.Add(label3);
            tabPage1.Controls.Add(iconPictureBox4);
            tabPage1.Controls.Add(label1);
            tabPage1.Controls.Add(iconPictureBox1);
            tabPage1.Controls.Add(label8);
            tabPage1.Controls.Add(addbtn);
            tabPage1.Controls.Add(Passwordtxt);
            tabPage1.Controls.Add(UserNametxt);
            tabPage1.Font = new Font("Microsoft Sans Serif", 8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            tabPage1.Location = new Point(4, 4);
            tabPage1.Margin = new Padding(2);
            tabPage1.Name = "tabPage1";
            tabPage1.Padding = new Padding(2);
            tabPage1.Size = new Size(872, 392);
            tabPage1.TabIndex = 0;
            tabPage1.Text = "Add User";
            // 
            // panel4
            // 
            panel4.BackColor = Color.Gray;
            panel4.Controls.Add(panel5);
            panel4.Location = new Point(268, 205);
            panel4.Name = "panel4";
            panel4.Size = new Size(316, 1);
            panel4.TabIndex = 91;
            // 
            // panel5
            // 
            panel5.BackColor = Color.Gray;
            panel5.Controls.Add(panel6);
            panel5.Location = new Point(0, 0);
            panel5.Name = "panel5";
            panel5.Size = new Size(263, 1);
            panel5.TabIndex = 63;
            // 
            // panel6
            // 
            panel6.BackColor = Color.Gray;
            panel6.Location = new Point(0, 0);
            panel6.Name = "panel6";
            panel6.Size = new Size(263, 1);
            panel6.TabIndex = 63;
            // 
            // panel2
            // 
            panel2.BackColor = Color.Gray;
            panel2.Controls.Add(panel1);
            panel2.Location = new Point(267, 149);
            panel2.Name = "panel2";
            panel2.Size = new Size(316, 1);
            panel2.TabIndex = 90;
            // 
            // panel1
            // 
            panel1.BackColor = Color.Gray;
            panel1.Controls.Add(panel3);
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(263, 1);
            panel1.TabIndex = 63;
            // 
            // panel3
            // 
            panel3.BackColor = Color.Gray;
            panel3.Location = new Point(0, 0);
            panel3.Name = "panel3";
            panel3.Size = new Size(263, 1);
            panel3.TabIndex = 63;
            // 
            // iconPictureBox5
            // 
            iconPictureBox5.BackColor = Color.FromArgb(51, 51, 76);
            iconPictureBox5.ForeColor = SystemColors.AppWorkspace;
            iconPictureBox5.IconChar = FontAwesome.Sharp.IconChar.Lock;
            iconPictureBox5.IconColor = SystemColors.AppWorkspace;
            iconPictureBox5.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconPictureBox5.Location = new Point(117, 178);
            iconPictureBox5.Name = "iconPictureBox5";
            iconPictureBox5.Size = new Size(32, 32);
            iconPictureBox5.TabIndex = 89;
            iconPictureBox5.TabStop = false;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Sitka Banner", 14.2499981F, FontStyle.Bold);
            label3.ForeColor = Color.FromArgb(204, 204, 204);
            label3.Location = new Point(148, 178);
            label3.Name = "label3";
            label3.Size = new Size(88, 28);
            label3.TabIndex = 88;
            label3.Text = "Password";
            // 
            // iconPictureBox4
            // 
            iconPictureBox4.BackColor = Color.FromArgb(51, 51, 76);
            iconPictureBox4.ForeColor = SystemColors.AppWorkspace;
            iconPictureBox4.IconChar = FontAwesome.Sharp.IconChar.UserEdit;
            iconPictureBox4.IconColor = SystemColors.AppWorkspace;
            iconPictureBox4.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconPictureBox4.Location = new Point(117, 119);
            iconPictureBox4.Name = "iconPictureBox4";
            iconPictureBox4.Size = new Size(32, 32);
            iconPictureBox4.TabIndex = 87;
            iconPictureBox4.TabStop = false;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Sitka Banner", 14.2499981F, FontStyle.Bold);
            label1.ForeColor = SystemColors.AppWorkspace;
            label1.Location = new Point(148, 122);
            label1.Margin = new Padding(4, 0, 4, 0);
            label1.Name = "label1";
            label1.Size = new Size(97, 28);
            label1.TabIndex = 86;
            label1.Text = "User Name";
            // 
            // iconPictureBox1
            // 
            iconPictureBox1.BackColor = Color.FromArgb(51, 51, 76);
            iconPictureBox1.ForeColor = SystemColors.AppWorkspace;
            iconPictureBox1.IconChar = FontAwesome.Sharp.IconChar.PeopleRoof;
            iconPictureBox1.IconColor = SystemColors.AppWorkspace;
            iconPictureBox1.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconPictureBox1.IconSize = 39;
            iconPictureBox1.Location = new Point(6, 5);
            iconPictureBox1.Name = "iconPictureBox1";
            iconPictureBox1.Size = new Size(39, 46);
            iconPictureBox1.TabIndex = 85;
            iconPictureBox1.TabStop = false;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Sitka Banner", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label8.ForeColor = Color.FromArgb(204, 204, 204);
            label8.Location = new Point(51, 5);
            label8.Name = "label8";
            label8.Size = new Size(114, 35);
            label8.TabIndex = 84;
            label8.Text = "Add Users";
            // 
            // addbtn
            // 
            addbtn.BackColor = Color.FromArgb(51, 51, 76);
            addbtn.FlatStyle = FlatStyle.Flat;
            addbtn.Font = new Font("Sitka Banner", 18F, FontStyle.Bold);
            addbtn.ForeColor = SystemColors.AppWorkspace;
            addbtn.Location = new Point(527, 305);
            addbtn.Margin = new Padding(3, 4, 3, 4);
            addbtn.Name = "addbtn";
            addbtn.Size = new Size(319, 44);
            addbtn.TabIndex = 53;
            addbtn.Text = "Add User";
            addbtn.UseVisualStyleBackColor = false;
            addbtn.Click += addbtn_Click;
            // 
            // Passwordtxt
            // 
            Passwordtxt.BackColor = Color.FromArgb(51, 51, 76);
            Passwordtxt.BorderStyle = BorderStyle.None;
            Passwordtxt.Font = new Font("Sitka Banner", 14.2499981F, FontStyle.Bold);
            Passwordtxt.ForeColor = SystemColors.AppWorkspace;
            Passwordtxt.Location = new Point(267, 179);
            Passwordtxt.MaxLength = 10;
            Passwordtxt.Name = "Passwordtxt";
            Passwordtxt.PasswordChar = '*';
            Passwordtxt.Size = new Size(315, 24);
            Passwordtxt.TabIndex = 51;
            // 
            // UserNametxt
            // 
            UserNametxt.BackColor = Color.FromArgb(51, 51, 76);
            UserNametxt.BorderStyle = BorderStyle.None;
            UserNametxt.Font = new Font("Sitka Banner", 14.2499981F, FontStyle.Bold);
            UserNametxt.ForeColor = SystemColors.AppWorkspace;
            UserNametxt.Location = new Point(267, 122);
            UserNametxt.Name = "UserNametxt";
            UserNametxt.Size = new Size(315, 24);
            UserNametxt.TabIndex = 50;
            // 
            // tabPage2
            // 
            tabPage2.BackColor = Color.FromArgb(51, 51, 76);
            tabPage2.Controls.Add(panel7);
            tabPage2.Controls.Add(iconPictureBox10);
            tabPage2.Controls.Add(label15);
            tabPage2.Controls.Add(iconPictureBox2);
            tabPage2.Controls.Add(label7);
            tabPage2.Controls.Add(button2);
            tabPage2.Controls.Add(searchbtn);
            tabPage2.Controls.Add(Idtxt);
            tabPage2.Controls.Add(dataGridView1);
            tabPage2.Font = new Font("Microsoft Sans Serif", 8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            tabPage2.Location = new Point(4, 4);
            tabPage2.Margin = new Padding(2);
            tabPage2.Name = "tabPage2";
            tabPage2.Padding = new Padding(2);
            tabPage2.Size = new Size(872, 392);
            tabPage2.TabIndex = 1;
            tabPage2.Text = "Search User";
            tabPage2.Click += tabPage2_Click;
            // 
            // panel7
            // 
            panel7.BackColor = Color.Gray;
            panel7.Location = new Point(213, 77);
            panel7.Name = "panel7";
            panel7.Size = new Size(637, 1);
            panel7.TabIndex = 90;
            // 
            // iconPictureBox10
            // 
            iconPictureBox10.BackColor = Color.FromArgb(51, 51, 76);
            iconPictureBox10.ForeColor = SystemColors.AppWorkspace;
            iconPictureBox10.IconChar = FontAwesome.Sharp.IconChar.Search;
            iconPictureBox10.IconColor = SystemColors.AppWorkspace;
            iconPictureBox10.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconPictureBox10.IconSize = 25;
            iconPictureBox10.Location = new Point(15, 57);
            iconPictureBox10.Name = "iconPictureBox10";
            iconPictureBox10.Size = new Size(29, 25);
            iconPictureBox10.TabIndex = 89;
            iconPictureBox10.TabStop = false;
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.Font = new Font("Sitka Banner", 14.2499981F, FontStyle.Bold);
            label15.ForeColor = SystemColors.AppWorkspace;
            label15.Location = new Point(44, 54);
            label15.Margin = new Padding(4, 0, 4, 0);
            label15.Name = "label15";
            label15.Size = new Size(155, 28);
            label15.TabIndex = 88;
            label15.Text = "UserID/UserName";
            // 
            // iconPictureBox2
            // 
            iconPictureBox2.BackColor = Color.FromArgb(51, 51, 76);
            iconPictureBox2.ForeColor = SystemColors.AppWorkspace;
            iconPictureBox2.IconChar = FontAwesome.Sharp.IconChar.PeopleRoof;
            iconPictureBox2.IconColor = SystemColors.AppWorkspace;
            iconPictureBox2.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconPictureBox2.IconSize = 39;
            iconPictureBox2.Location = new Point(5, 5);
            iconPictureBox2.Name = "iconPictureBox2";
            iconPictureBox2.Size = new Size(39, 46);
            iconPictureBox2.TabIndex = 87;
            iconPictureBox2.TabStop = false;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Sitka Banner", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label7.ForeColor = Color.FromArgb(204, 204, 204);
            label7.Location = new Point(50, 5);
            label7.Name = "label7";
            label7.Size = new Size(133, 35);
            label7.TabIndex = 86;
            label7.Text = "Search User";
            // 
            // button2
            // 
            button2.BackColor = Color.FromArgb(51, 51, 76);
            button2.FlatStyle = FlatStyle.Flat;
            button2.Font = new Font("Sitka Banner", 18F, FontStyle.Bold);
            button2.ForeColor = SystemColors.AppWorkspace;
            button2.Location = new Point(610, 106);
            button2.Margin = new Padding(3, 4, 3, 4);
            button2.Name = "button2";
            button2.Size = new Size(240, 41);
            button2.TabIndex = 57;
            button2.Text = "Display all Users";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // searchbtn
            // 
            searchbtn.BackColor = Color.FromArgb(51, 51, 76);
            searchbtn.FlatStyle = FlatStyle.Flat;
            searchbtn.Font = new Font("Sitka Banner", 18F, FontStyle.Bold);
            searchbtn.ForeColor = SystemColors.AppWorkspace;
            searchbtn.Location = new Point(350, 106);
            searchbtn.Margin = new Padding(3, 4, 3, 4);
            searchbtn.Name = "searchbtn";
            searchbtn.Size = new Size(232, 41);
            searchbtn.TabIndex = 55;
            searchbtn.Text = "Search User";
            searchbtn.UseVisualStyleBackColor = false;
            searchbtn.Click += searchbtn_Click;
            // 
            // Idtxt
            // 
            Idtxt.BackColor = Color.FromArgb(51, 51, 76);
            Idtxt.BorderStyle = BorderStyle.None;
            Idtxt.Font = new Font("Sitka Banner", 14.2499981F, FontStyle.Bold);
            Idtxt.ForeColor = SystemColors.AppWorkspace;
            Idtxt.Location = new Point(213, 50);
            Idtxt.Margin = new Padding(3, 4, 3, 4);
            Idtxt.Name = "Idtxt";
            Idtxt.Size = new Size(637, 24);
            Idtxt.TabIndex = 54;
            Idtxt.Text = "\r\n";
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Dock = DockStyle.Bottom;
            dataGridView1.GridColor = Color.FromArgb(51, 51, 76);
            dataGridView1.Location = new Point(2, 153);
            dataGridView1.Margin = new Padding(2);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 62;
            dataGridView1.RowTemplate.Height = 33;
            dataGridView1.Size = new Size(868, 237);
            dataGridView1.TabIndex = 52;
            // 
            // tabPage3
            // 
            tabPage3.BackColor = Color.FromArgb(51, 51, 76);
            tabPage3.Controls.Add(panel14);
            tabPage3.Controls.Add(panel11);
            tabPage3.Controls.Add(panel8);
            tabPage3.Controls.Add(iconPictureBox7);
            tabPage3.Controls.Add(label2);
            tabPage3.Controls.Add(iconPictureBox8);
            tabPage3.Controls.Add(label4);
            tabPage3.Controls.Add(iconPictureBox6);
            tabPage3.Controls.Add(label5);
            tabPage3.Controls.Add(iconPictureBox3);
            tabPage3.Controls.Add(label9);
            tabPage3.Controls.Add(button4);
            tabPage3.Controls.Add(UIdtxt);
            tabPage3.Controls.Add(button3);
            tabPage3.Controls.Add(UPass);
            tabPage3.Controls.Add(UName);
            tabPage3.Font = new Font("Microsoft Sans Serif", 8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            tabPage3.Location = new Point(4, 4);
            tabPage3.Margin = new Padding(2);
            tabPage3.Name = "tabPage3";
            tabPage3.Size = new Size(872, 392);
            tabPage3.TabIndex = 2;
            tabPage3.Text = "Update Or Delete";
            // 
            // panel14
            // 
            panel14.BackColor = Color.Gray;
            panel14.Controls.Add(panel15);
            panel14.Location = new Point(285, 230);
            panel14.Name = "panel14";
            panel14.Size = new Size(316, 1);
            panel14.TabIndex = 98;
            // 
            // panel15
            // 
            panel15.BackColor = Color.Gray;
            panel15.Controls.Add(panel16);
            panel15.Location = new Point(0, 0);
            panel15.Name = "panel15";
            panel15.Size = new Size(263, 1);
            panel15.TabIndex = 63;
            // 
            // panel16
            // 
            panel16.BackColor = Color.Gray;
            panel16.Location = new Point(0, 0);
            panel16.Name = "panel16";
            panel16.Size = new Size(263, 1);
            panel16.TabIndex = 63;
            // 
            // panel11
            // 
            panel11.BackColor = Color.Gray;
            panel11.Controls.Add(panel12);
            panel11.Location = new Point(285, 174);
            panel11.Name = "panel11";
            panel11.Size = new Size(316, 1);
            panel11.TabIndex = 97;
            // 
            // panel12
            // 
            panel12.BackColor = Color.Gray;
            panel12.Controls.Add(panel13);
            panel12.Location = new Point(0, 0);
            panel12.Name = "panel12";
            panel12.Size = new Size(263, 1);
            panel12.TabIndex = 63;
            // 
            // panel13
            // 
            panel13.BackColor = Color.Gray;
            panel13.Location = new Point(0, 0);
            panel13.Name = "panel13";
            panel13.Size = new Size(263, 1);
            panel13.TabIndex = 63;
            // 
            // panel8
            // 
            panel8.BackColor = Color.Gray;
            panel8.Controls.Add(panel9);
            panel8.Location = new Point(285, 110);
            panel8.Name = "panel8";
            panel8.Size = new Size(316, 1);
            panel8.TabIndex = 96;
            // 
            // panel9
            // 
            panel9.BackColor = Color.Gray;
            panel9.Location = new Point(0, 0);
            panel9.Name = "panel9";
            panel9.Size = new Size(263, 1);
            panel9.TabIndex = 63;
            // 
            // iconPictureBox7
            // 
            iconPictureBox7.BackColor = Color.FromArgb(51, 51, 76);
            iconPictureBox7.ForeColor = SystemColors.AppWorkspace;
            iconPictureBox7.IconChar = FontAwesome.Sharp.IconChar.Lock;
            iconPictureBox7.IconColor = SystemColors.AppWorkspace;
            iconPictureBox7.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconPictureBox7.Location = new Point(136, 203);
            iconPictureBox7.Name = "iconPictureBox7";
            iconPictureBox7.Size = new Size(32, 32);
            iconPictureBox7.TabIndex = 95;
            iconPictureBox7.TabStop = false;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Sitka Banner", 14.2499981F, FontStyle.Bold);
            label2.ForeColor = Color.FromArgb(204, 204, 204);
            label2.Location = new Point(167, 203);
            label2.Name = "label2";
            label2.Size = new Size(88, 28);
            label2.TabIndex = 94;
            label2.Text = "Password";
            // 
            // iconPictureBox8
            // 
            iconPictureBox8.BackColor = Color.FromArgb(51, 51, 76);
            iconPictureBox8.ForeColor = SystemColors.AppWorkspace;
            iconPictureBox8.IconChar = FontAwesome.Sharp.IconChar.UserEdit;
            iconPictureBox8.IconColor = SystemColors.AppWorkspace;
            iconPictureBox8.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconPictureBox8.Location = new Point(136, 143);
            iconPictureBox8.Name = "iconPictureBox8";
            iconPictureBox8.Size = new Size(32, 32);
            iconPictureBox8.TabIndex = 93;
            iconPictureBox8.TabStop = false;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Sitka Banner", 14.2499981F, FontStyle.Bold);
            label4.ForeColor = SystemColors.AppWorkspace;
            label4.Location = new Point(167, 146);
            label4.Margin = new Padding(4, 0, 4, 0);
            label4.Name = "label4";
            label4.Size = new Size(97, 28);
            label4.TabIndex = 92;
            label4.Text = "User Name";
            // 
            // iconPictureBox6
            // 
            iconPictureBox6.BackColor = Color.FromArgb(51, 51, 76);
            iconPictureBox6.ForeColor = SystemColors.AppWorkspace;
            iconPictureBox6.IconChar = FontAwesome.Sharp.IconChar.UserEdit;
            iconPictureBox6.IconColor = SystemColors.AppWorkspace;
            iconPictureBox6.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconPictureBox6.Location = new Point(136, 79);
            iconPictureBox6.Name = "iconPictureBox6";
            iconPictureBox6.Size = new Size(32, 32);
            iconPictureBox6.TabIndex = 91;
            iconPictureBox6.TabStop = false;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Sitka Banner", 14.2499981F, FontStyle.Bold);
            label5.ForeColor = SystemColors.AppWorkspace;
            label5.Location = new Point(167, 83);
            label5.Margin = new Padding(4, 0, 4, 0);
            label5.Name = "label5";
            label5.Size = new Size(66, 28);
            label5.TabIndex = 90;
            label5.Text = "UserID";
            // 
            // iconPictureBox3
            // 
            iconPictureBox3.BackColor = Color.FromArgb(51, 51, 76);
            iconPictureBox3.ForeColor = SystemColors.AppWorkspace;
            iconPictureBox3.IconChar = FontAwesome.Sharp.IconChar.PeopleRoof;
            iconPictureBox3.IconColor = SystemColors.AppWorkspace;
            iconPictureBox3.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconPictureBox3.IconSize = 39;
            iconPictureBox3.Location = new Point(5, 5);
            iconPictureBox3.Name = "iconPictureBox3";
            iconPictureBox3.Size = new Size(39, 46);
            iconPictureBox3.TabIndex = 87;
            iconPictureBox3.TabStop = false;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Sitka Banner", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label9.ForeColor = Color.FromArgb(204, 204, 204);
            label9.Location = new Point(50, 5);
            label9.Name = "label9";
            label9.Size = new Size(232, 35);
            label9.TabIndex = 86;
            label9.Text = "Update Or Delete User";
            // 
            // button4
            // 
            button4.BackColor = Color.FromArgb(51, 51, 76);
            button4.FlatStyle = FlatStyle.Flat;
            button4.Font = new Font("Sitka Banner", 18F, FontStyle.Bold);
            button4.ForeColor = SystemColors.AppWorkspace;
            button4.Location = new Point(603, 326);
            button4.Margin = new Padding(3, 4, 3, 4);
            button4.Name = "button4";
            button4.Size = new Size(250, 40);
            button4.TabIndex = 61;
            button4.Text = "Delete User";
            button4.UseVisualStyleBackColor = false;
            button4.Click += button4_Click;
            // 
            // UIdtxt
            // 
            UIdtxt.BackColor = Color.FromArgb(51, 51, 76);
            UIdtxt.BorderStyle = BorderStyle.None;
            UIdtxt.Font = new Font("Sitka Banner", 14.2499981F, FontStyle.Bold);
            UIdtxt.ForeColor = SystemColors.AppWorkspace;
            UIdtxt.Location = new Point(285, 83);
            UIdtxt.Margin = new Padding(3, 4, 3, 4);
            UIdtxt.Name = "UIdtxt";
            UIdtxt.Size = new Size(313, 24);
            UIdtxt.TabIndex = 59;
            UIdtxt.Text = "\r\n";
            UIdtxt.TextChanged += UIdtxt_TextChanged;
            // 
            // button3
            // 
            button3.BackColor = Color.FromArgb(51, 51, 76);
            button3.FlatStyle = FlatStyle.Flat;
            button3.Font = new Font("Sitka Banner", 18F, FontStyle.Bold);
            button3.ForeColor = SystemColors.AppWorkspace;
            button3.Location = new Point(351, 326);
            button3.Margin = new Padding(3, 4, 3, 4);
            button3.Name = "button3";
            button3.Size = new Size(235, 40);
            button3.TabIndex = 58;
            button3.Text = "Update User";
            button3.UseVisualStyleBackColor = false;
            button3.Click += button3_Click;
            // 
            // UPass
            // 
            UPass.BackColor = Color.FromArgb(51, 51, 76);
            UPass.BorderStyle = BorderStyle.None;
            UPass.Font = new Font("Sitka Banner", 14.2499981F, FontStyle.Bold);
            UPass.ForeColor = SystemColors.AppWorkspace;
            UPass.Location = new Point(285, 204);
            UPass.MaxLength = 10;
            UPass.Name = "UPass";
            UPass.PasswordChar = '*';
            UPass.Size = new Size(313, 24);
            UPass.TabIndex = 56;
            // 
            // UName
            // 
            UName.BackColor = Color.FromArgb(51, 51, 76);
            UName.BorderStyle = BorderStyle.None;
            UName.Font = new Font("Sitka Banner", 14.2499981F, FontStyle.Bold);
            UName.ForeColor = SystemColors.AppWorkspace;
            UName.Location = new Point(285, 148);
            UName.Name = "UName";
            UName.Size = new Size(313, 24);
            UName.TabIndex = 55;
            // 
            // Users
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(51, 51, 76);
            ClientSize = new Size(880, 420);
            Controls.Add(tabControl1);
            FormBorderStyle = FormBorderStyle.None;
            Margin = new Padding(2);
            Name = "Users";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Users";
            tabControl1.ResumeLayout(false);
            tabPage1.ResumeLayout(false);
            tabPage1.PerformLayout();
            panel4.ResumeLayout(false);
            panel5.ResumeLayout(false);
            panel2.ResumeLayout(false);
            panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)iconPictureBox5).EndInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox4).EndInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox1).EndInit();
            tabPage2.ResumeLayout(false);
            tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox10).EndInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            tabPage3.ResumeLayout(false);
            tabPage3.PerformLayout();
            panel14.ResumeLayout(false);
            panel15.ResumeLayout(false);
            panel11.ResumeLayout(false);
            panel12.ResumeLayout(false);
            panel8.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)iconPictureBox7).EndInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox8).EndInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox6).EndInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox3).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TextBox Passwordtxt;
        private System.Windows.Forms.TextBox UserNametxt;
        private System.Windows.Forms.Button addbtn;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button searchbtn;
        private System.Windows.Forms.TextBox Idtxt;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.TextBox UPass;
        private System.Windows.Forms.TextBox UName;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.TextBox UIdtxt;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox1;
        private Label label8;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox2;
        private Label label7;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox3;
        private Label label9;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox4;
        private Label label1;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox5;
        private Label label3;
        private Panel panel4;
        private Panel panel5;
        private Panel panel6;
        private Panel panel2;
        private Panel panel1;
        private Panel panel3;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox10;
        private Label label15;
        private Panel panel7;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox7;
        private Label label2;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox8;
        private Label label4;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox6;
        private Label label5;
        private Panel panel14;
        private Panel panel15;
        private Panel panel16;
        private Panel panel11;
        private Panel panel12;
        private Panel panel13;
        private Panel panel8;
        private Panel panel9;
    }
}
﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Text.RegularExpressions;

namespace DBMS_HMS
{
    public partial class Guest : Form
    {
        public Guest()
        {
            InitializeComponent();
        }
        SqlConnection con = new SqlConnection("Data Source=DESKTOP-KFDUOB5\\MSSQLSERVER2022;Initial Catalog=HotelManagementSystem;Integrated Security=True;Encrypt=True;TrustServerCertificate=True;");

        private void addGbtn_Click(object sender, EventArgs e)
        {
            string membershipStatus = null;
            string cnic = CNICtxt.Text.Trim();

            // Representation Invariant: Ensure a valid membership status is selected
            if (ActiveRadioBtn.Checked)
            {
                membershipStatus = "Active";
            }
            else if (InactiveRadioBtn.Checked)
            {
                membershipStatus = "Inactive";
            }
            else
            {
                MessageBox.Show("Please select a valid membership status.", "Invalid Membership Status", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return; // Exit the method without proceeding further
            }

            if (ValidateCNIC(cnic) && ValidatePhoneNumber(phone_txt.Text.Trim()))
            {
                try
                {
                    con.Open();

                    // If the membership status is null, show a message to select a membership status
                    // Note: With the representation invariant, this check is redundant, but we keep it for safety.
                    if (membershipStatus == null)
                    {
                        MessageBox.Show("Please select a membership status.", "Missing Membership Status", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return; // Exit the method without proceeding further
                    }

                    // Insert the guest record with the provided information
                    string insertQuery = "INSERT INTO Guests (First_Name, Last_Name, Address, Contact_No, E_mail, Membership_Status, CNIC) " +
                                         "VALUES (@First_Name, @Last_Name, @Address, @Contact_No, @E_mail, @Membership_Status, @CNIC); " +
                                         "SELECT SCOPE_IDENTITY();";

                    SqlCommand insertCommand = new SqlCommand(insertQuery, con);

                    // Set the parameter values
                    insertCommand.Parameters.AddWithValue("@First_Name", fname_txt.Text);
                    insertCommand.Parameters.AddWithValue("@Last_Name", lname_txt.Text);
                    insertCommand.Parameters.AddWithValue("@Address", add_txt.Text);
                    insertCommand.Parameters.AddWithValue("@Contact_No", phone_txt.Text);
                    insertCommand.Parameters.AddWithValue("@E_mail", email_txt.Text);
                    insertCommand.Parameters.AddWithValue("@Membership_Status", membershipStatus);
                    insertCommand.Parameters.AddWithValue("@CNIC", cnic);

                    int guestID = Convert.ToInt32(insertCommand.ExecuteScalar());

                    MessageBox.Show("Guest record inserted successfully!\n         Guest ID: " + guestID);
                    clear();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
                finally
                {
                    if (con.State == ConnectionState.Open)
                    {
                        con.Close(); // Ensure the connection is closed, even if an exception occurs
                    }
                }
            }
            else
            {
                if (!ValidateCNIC(cnic))
                {
                    MessageBox.Show("Invalid CNIC format. Please enter a valid CNIC in the format 'xxxxx-xxxxxxx-x'.", "Invalid CNIC", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else if (!ValidatePhoneNumber(phone_txt.Text.Trim()))
                {
                    MessageBox.Show("Invalid phone number format. Please enter a valid phone number 'xxxx-xxxxxxx'.", "Invalid Phone Number", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }


            populate(); // You can call populate() outside of the if-else block


        }
        private bool ValidateCNIC(string cnic)
        {
            // Remove any spaces and hyphens from the CNIC number
            cnic = cnic.Replace(" ", "").Replace("-", "");

            // Use regular expression pattern to check for the specified format
            string pattern = @"^\d{5}[- ]?\d{7}[- ]?\d$";

            return Regex.IsMatch(cnic, pattern);
        }
        private bool ValidatePhoneNumber(string phoneNumber)
        {
            // Remove any spaces and hyphens from the phone number
            phoneNumber = phoneNumber.Replace(" ", "").Replace("-", "");

            // Use regular expression pattern to check for the specified format
            string pattern = @"^\d{4}[-]?\d{7}$";

            return Regex.IsMatch(phoneNumber, pattern);
        }

        public void populate()
        {
            con.Open();
            string query = "select * from Guests";
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.ExecuteNonQuery();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            SqlCommandBuilder cb = new SqlCommandBuilder(da);
            var ds = new DataSet();
            da.Fill(ds);
            R_datagrid.DataSource = ds.Tables[0];
            con.Close();
        }

        private void R_searchbtn_Click(object sender, EventArgs e)
        {
            try
            {
                string searchTerm = R_idsearch.Text.Trim();
                con.Open();
                SqlDataAdapter adapter = new SqlDataAdapter();
                SqlCommand command;

                if (int.TryParse(searchTerm, out int Employee_ID))
                {
                    command = new SqlCommand("EXEC SearchGuestByID @SearchTerm", con);
                    command.Parameters.AddWithValue("@SearchTerm", searchTerm);
                }
                else
                {
                    command = new SqlCommand("EXEC SearchGuestByNamee @Name", con);
                    command.Parameters.AddWithValue("@Name", searchTerm);
                }

                adapter.SelectCommand = command;
                DataTable dataTable = new DataTable();
                adapter.Fill(dataTable);

                if (dataTable.Rows.Count > 0)
                {
                    R_datagrid.DataSource = dataTable;
                }
                else
                {
                    MessageBox.Show("No guest found with the provided search term.");
                    R_datagrid.DataSource = null;
                }

                con.Close();
            }
            catch (FormatException)
            {
                MessageBox.Show("Invalid guest ID. Please enter a valid integer value.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
            finally
            {
                con.Close();
            }
        }


        private void updateGbtn_Click(object sender, EventArgs e)
        {
            
          int guestID = int.Parse(Idtxt.Text); // Replace with the actual Guest_ID value to update
            string connectionString = "Data Source=DESKTOP-KFDUOB5\\MSSQLSERVER2022;Initial Catalog=HotelManagementSystem;Integrated Security=True;Encrypt=True;TrustServerCertificate=True"; // Replace with your actual connection string
            string phoneNo = UpPhotxt.Text.Trim();
            string cnic = textBox.Text.Trim();                                                                                                                                                   //con.Open();
                                                                                                                                                                                                 // Retrieve the current membership status from the database
            string currentMembershipStatus = GetMembershipStatusFromDatabase(guestID, connectionString);
            //  string currentMembershipStatus = GetMembershipStatusFromDatabase(guestID, "con");
            // Use the current membership status instead of the one selected by the user
            string membershipStatus = currentMembershipStatus;

            // Rest of the code remains the same...
            // Validate CNIC and phone number
            if (ValidateCNIC(cnic) && ValidatePhoneNumber(phoneNo))
            {
                // Rest of your code remains the same...
                using (SqlConnection connection = new SqlConnection("Data Source=DESKTOP-KFDUOB5\\MSSQLSERVER2022;Initial Catalog=HotelManagementSystem;Integrated Security=True;Encrypt=True;TrustServerCertificate=True"))
                {
                    try
                    {
                        connection.Open();

                        SqlCommand command = new SqlCommand("UpdateGuest", connection);
                        command.CommandType = CommandType.StoredProcedure;

                        command.Parameters.AddWithValue("@Guest_ID", guestID);
                        command.Parameters.AddWithValue("@First_Name", UpFNametxt.Text);
                        command.Parameters.AddWithValue("@Last_Name", UPLNametxt.Text);
                        command.Parameters.AddWithValue("@Address", Upaddtxt.Text);
                        command.Parameters.AddWithValue("@Contact_No", phoneNo);
                        command.Parameters.AddWithValue("@E_mail", UpEmailtxt.Text);
                        command.Parameters.AddWithValue("@Membership_Status", membershipStatus);
                        command.Parameters.AddWithValue("@CNIC", cnic);

                        int rowsAffected = command.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Guest record updated successfully!");
                            clear();
                        }
                        else
                        {
                            MessageBox.Show("Guest record not found.");
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error: " + ex.Message);
                    }
                }
                populate();
            }
            else
            {
                if (!ValidateCNIC(cnic))
                {
                    MessageBox.Show("Invalid CNIC format. Please enter a valid CNIC in the format 'xxxxx-xxxxxxx-x'.", "Invalid CNIC", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else if (!ValidatePhoneNumber(phoneNo))
                {
                    MessageBox.Show("Invalid phone number format. Please enter a valid phone number in the format '03xx-xxxxxxx'.", "Invalid Phone Number", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }


        }
        private string GetMembershipStatusFromDatabase(int guestID, string connectionString)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                SqlCommand command = new SqlCommand("SELECT Membership_Status FROM Guests WHERE Guest_ID = @Guest_ID", connection);
                command.Parameters.AddWithValue("@Guest_ID", guestID);

                using (SqlDataReader reader = command.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        // Retrieve the current membership status from the database
                        return reader["Membership_Status"].ToString();
                    }
                }
            }

            // Return a default value or handle the case when the guest record is not found
            return null;
        }
        public void clear()
        {
            add_txt.Clear();
            email_txt.Clear();
            fname_txt.Clear();
            phone_txt.Clear();
            Idtxt.Clear();
            UpEmailtxt.Clear();
            UpFNametxt.Clear();
            UPLNametxt.Clear();
            UpPhotxt.Clear();
            Upaddtxt.Clear();
            lname_txt.Clear();
            CNICtxt.Clear();

        }

        private void Displaybtn_Click(object sender, EventArgs e)
        {
            populate();
        }



        private void tabPage3_Click(object sender, EventArgs e)
        {
            //   populate();
        }

        private void Guest_Load(object sender, EventArgs e)
        {
            // populate();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            string membershipStatus = null;
            string cnic = CNICtxt.Text.Trim();
            con.Open();

            // Check if the guest with the provided CNIC exists in the Guests table
            string selectQuery = "SELECT * FROM Guests WHERE CNIC = @CNIC";
            SqlCommand selectCommand = new SqlCommand(selectQuery, con);
            selectCommand.Parameters.AddWithValue("@CNIC", cnic);
            SqlDataReader reader = selectCommand.ExecuteReader();

            if (reader.Read())
            {
                // Guest with the provided CNIC exists
                // Retrieve the membership status
                membershipStatus = reader["Membership_Status"].ToString();

                // Auto-fill the ActiveRadioBtn or InactiveRadioBtn based on the membership status
                if (membershipStatus == "Active")
                {
                    ActiveRadioBtn.Checked = true;
                }
                else if (membershipStatus == "Inactive")
                {
                    InactiveRadioBtn.Checked = true;
                }
            }
            else
            {
                InactiveRadioBtn.Checked = true;
                //// Guest with the provided CNIC does not exist
                //MessageBox.Show("No guest record found with the provided CNIC.");
            }

            reader.Close();
            con.Close();
        }

        private void Idtxt_TextChanged(object sender, EventArgs e)
        {
            string guestID = Idtxt.Text;

            using (SqlCommand command = new SqlCommand("SELECT * FROM Guests WHERE Guest_ID = @Guest_ID", con))
            {
                command.Parameters.AddWithValue("@Guest_ID", guestID);

                try
                {
                    con.Open();
                    SqlDataReader reader = command.ExecuteReader();

                    if (reader.Read())
                    {
                        // Fill the other text boxes with matching information
                        UpFNametxt.Text = reader["First_Name"].ToString();
                        UPLNametxt.Text = reader["Last_Name"].ToString();
                        Upaddtxt.Text = reader["Address"].ToString();
                        UpPhotxt.Text = reader["Contact_No"].ToString();
                        UpEmailtxt.Text = reader["E_mail"].ToString();
                        textBox.Text = reader["CNIC"].ToString();

                        // Retrieve the Membership_Status value
                        string membershipStatus = reader["Membership_Status"].ToString();

                        //// Auto-fill the ActiveRadioButton or InactiveRadioButton based on the Membership_Status
                        //if (membershipStatus == "Active")
                        //{
                        //    ActiveRadioButton.Checked = true;
                        //}
                        //else if (membershipStatus == "Inactive")
                        //{
                        //    InactiveRadioButton.Checked = true;
                        //}
                    }
                    else
                    {
                        // No matching record found, clear the other text boxes and radio buttons
                        UpFNametxt.Text = string.Empty;
                        UPLNametxt.Text = string.Empty;
                        Upaddtxt.Text = string.Empty;
                        UpPhotxt.Text = string.Empty;
                        UpEmailtxt.Text = string.Empty;
                        textBox.Text = string.Empty;
                        //ActiveRadioButton.Checked = false;
                        //InactiveRadioButton.Checked = false;
                    }

                    reader.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
                finally
                {
                    con.Close();
                }
            }
        }


        private void pictureBox2_Click(object sender, EventArgs e)
        {
            //    HOME h = new HOME();
            //    this.Hide();
            //    h.Show();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void label15_Click(object sender, EventArgs e)
        {

        }

        private void tabPage1_Click(object sender, EventArgs e)
        {

        }
    }
}

﻿
namespace DBMS_HMS
{
    partial class Guest
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            tabControl1 = new TabControl();
            tabPage2 = new TabPage();
            iconPictureBox8 = new FontAwesome.Sharp.IconPictureBox();
            iconPictureBox7 = new FontAwesome.Sharp.IconPictureBox();
            iconPictureBox6 = new FontAwesome.Sharp.IconPictureBox();
            iconPictureBox5 = new FontAwesome.Sharp.IconPictureBox();
            iconPictureBox4 = new FontAwesome.Sharp.IconPictureBox();
            iconPictureBox3 = new FontAwesome.Sharp.IconPictureBox();
            iconPictureBox2 = new FontAwesome.Sharp.IconPictureBox();
            panel10 = new Panel();
            panel9 = new Panel();
            panel8 = new Panel();
            panel7 = new Panel();
            panel4 = new Panel();
            panel2 = new Panel();
            panel1 = new Panel();
            panel3 = new Panel();
            iconPictureBox1 = new FontAwesome.Sharp.IconPictureBox();
            label1 = new Label();
            CNICtxt = new TextBox();
            CNIC = new Label();
            InactiveRadioBtn = new RadioButton();
            ActiveRadioBtn = new RadioButton();
            label16 = new Label();
            addGbtn = new Button();
            add_txt = new TextBox();
            email_txt = new TextBox();
            phone_txt = new TextBox();
            lname_txt = new TextBox();
            fname_txt = new TextBox();
            label6 = new Label();
            label5 = new Label();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            tabPage4 = new TabPage();
            iconPictureBox10 = new FontAwesome.Sharp.IconPictureBox();
            panel5 = new Panel();
            iconPictureBox9 = new FontAwesome.Sharp.IconPictureBox();
            label18 = new Label();
            label15 = new Label();
            Displaybtn = new Button();
            R_datagrid = new DataGridView();
            label13 = new Label();
            R_idsearch = new TextBox();
            R_searchbtn = new Button();
            tabPage1 = new TabPage();
            panel17 = new Panel();
            panel16 = new Panel();
            panel15 = new Panel();
            panel14 = new Panel();
            panel13 = new Panel();
            panel12 = new Panel();
            panel6 = new Panel();
            panel11 = new Panel();
            iconPictureBox18 = new FontAwesome.Sharp.IconPictureBox();
            label7 = new Label();
            iconPictureBox17 = new FontAwesome.Sharp.IconPictureBox();
            label17 = new Label();
            iconPictureBox16 = new FontAwesome.Sharp.IconPictureBox();
            label8 = new Label();
            iconPictureBox15 = new FontAwesome.Sharp.IconPictureBox();
            label9 = new Label();
            iconPictureBox14 = new FontAwesome.Sharp.IconPictureBox();
            label11 = new Label();
            iconPictureBox13 = new FontAwesome.Sharp.IconPictureBox();
            label12 = new Label();
            iconPictureBox12 = new FontAwesome.Sharp.IconPictureBox();
            label14 = new Label();
            iconPictureBox11 = new FontAwesome.Sharp.IconPictureBox();
            label10 = new Label();
            label19 = new Label();
            textBox = new TextBox();
            Idtxt = new TextBox();
            UPLNametxt = new TextBox();
            UpFNametxt = new TextBox();
            updateGbtn = new Button();
            Upaddtxt = new TextBox();
            UpEmailtxt = new TextBox();
            UpPhotxt = new TextBox();
            tabControl1.SuspendLayout();
            tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox8).BeginInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox7).BeginInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox6).BeginInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox5).BeginInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox2).BeginInit();
            panel2.SuspendLayout();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox1).BeginInit();
            tabPage4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox10).BeginInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox9).BeginInit();
            ((System.ComponentModel.ISupportInitialize)R_datagrid).BeginInit();
            tabPage1.SuspendLayout();
            panel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox18).BeginInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox17).BeginInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox16).BeginInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox15).BeginInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox14).BeginInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox13).BeginInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox12).BeginInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox11).BeginInit();
            SuspendLayout();
            // 
            // tabControl1
            // 
            tabControl1.Alignment = TabAlignment.Bottom;
            tabControl1.Controls.Add(tabPage2);
            tabControl1.Controls.Add(tabPage4);
            tabControl1.Controls.Add(tabPage1);
            tabControl1.Dock = DockStyle.Fill;
            tabControl1.Location = new Point(0, 0);
            tabControl1.Margin = new Padding(4, 3, 4, 3);
            tabControl1.Name = "tabControl1";
            tabControl1.SelectedIndex = 0;
            tabControl1.Size = new Size(880, 420);
            tabControl1.TabIndex = 2;
            // 
            // tabPage2
            // 
            tabPage2.BackColor = Color.FromArgb(51, 51, 76);
            tabPage2.Controls.Add(iconPictureBox8);
            tabPage2.Controls.Add(iconPictureBox7);
            tabPage2.Controls.Add(iconPictureBox6);
            tabPage2.Controls.Add(iconPictureBox5);
            tabPage2.Controls.Add(iconPictureBox4);
            tabPage2.Controls.Add(iconPictureBox3);
            tabPage2.Controls.Add(iconPictureBox2);
            tabPage2.Controls.Add(panel10);
            tabPage2.Controls.Add(panel9);
            tabPage2.Controls.Add(panel8);
            tabPage2.Controls.Add(panel7);
            tabPage2.Controls.Add(panel4);
            tabPage2.Controls.Add(panel2);
            tabPage2.Controls.Add(iconPictureBox1);
            tabPage2.Controls.Add(label1);
            tabPage2.Controls.Add(CNICtxt);
            tabPage2.Controls.Add(CNIC);
            tabPage2.Controls.Add(InactiveRadioBtn);
            tabPage2.Controls.Add(ActiveRadioBtn);
            tabPage2.Controls.Add(label16);
            tabPage2.Controls.Add(addGbtn);
            tabPage2.Controls.Add(add_txt);
            tabPage2.Controls.Add(email_txt);
            tabPage2.Controls.Add(phone_txt);
            tabPage2.Controls.Add(lname_txt);
            tabPage2.Controls.Add(fname_txt);
            tabPage2.Controls.Add(label6);
            tabPage2.Controls.Add(label5);
            tabPage2.Controls.Add(label4);
            tabPage2.Controls.Add(label3);
            tabPage2.Controls.Add(label2);
            tabPage2.Location = new Point(4, 4);
            tabPage2.Margin = new Padding(4, 3, 4, 3);
            tabPage2.Name = "tabPage2";
            tabPage2.Padding = new Padding(4, 3, 4, 3);
            tabPage2.Size = new Size(872, 392);
            tabPage2.TabIndex = 1;
            tabPage2.Text = "Add Guests";
            // 
            // iconPictureBox8
            // 
            iconPictureBox8.BackColor = Color.FromArgb(51, 51, 76);
            iconPictureBox8.ForeColor = SystemColors.AppWorkspace;
            iconPictureBox8.IconChar = FontAwesome.Sharp.IconChar.BalanceScale;
            iconPictureBox8.IconColor = SystemColors.AppWorkspace;
            iconPictureBox8.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconPictureBox8.Location = new Point(8, 237);
            iconPictureBox8.Name = "iconPictureBox8";
            iconPictureBox8.Size = new Size(32, 32);
            iconPictureBox8.TabIndex = 72;
            iconPictureBox8.TabStop = false;
            // 
            // iconPictureBox7
            // 
            iconPictureBox7.BackColor = Color.FromArgb(51, 51, 76);
            iconPictureBox7.ForeColor = SystemColors.AppWorkspace;
            iconPictureBox7.IconChar = FontAwesome.Sharp.IconChar.IdCard;
            iconPictureBox7.IconColor = SystemColors.AppWorkspace;
            iconPictureBox7.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconPictureBox7.Location = new Point(8, 176);
            iconPictureBox7.Name = "iconPictureBox7";
            iconPictureBox7.Size = new Size(32, 32);
            iconPictureBox7.TabIndex = 71;
            iconPictureBox7.TabStop = false;
            // 
            // iconPictureBox6
            // 
            iconPictureBox6.BackColor = Color.FromArgb(51, 51, 76);
            iconPictureBox6.ForeColor = SystemColors.AppWorkspace;
            iconPictureBox6.IconChar = FontAwesome.Sharp.IconChar.Archway;
            iconPictureBox6.IconColor = SystemColors.AppWorkspace;
            iconPictureBox6.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconPictureBox6.Location = new Point(476, 172);
            iconPictureBox6.Name = "iconPictureBox6";
            iconPictureBox6.Size = new Size(32, 32);
            iconPictureBox6.TabIndex = 70;
            iconPictureBox6.TabStop = false;
            // 
            // iconPictureBox5
            // 
            iconPictureBox5.BackColor = Color.FromArgb(51, 51, 76);
            iconPictureBox5.ForeColor = SystemColors.AppWorkspace;
            iconPictureBox5.IconChar = FontAwesome.Sharp.IconChar.Envelope;
            iconPictureBox5.IconColor = SystemColors.AppWorkspace;
            iconPictureBox5.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconPictureBox5.Location = new Point(476, 127);
            iconPictureBox5.Name = "iconPictureBox5";
            iconPictureBox5.Size = new Size(32, 32);
            iconPictureBox5.TabIndex = 69;
            iconPictureBox5.TabStop = false;
            // 
            // iconPictureBox4
            // 
            iconPictureBox4.BackColor = Color.FromArgb(51, 51, 76);
            iconPictureBox4.ForeColor = SystemColors.AppWorkspace;
            iconPictureBox4.IconChar = FontAwesome.Sharp.IconChar.Phone;
            iconPictureBox4.IconColor = SystemColors.AppWorkspace;
            iconPictureBox4.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconPictureBox4.IconSize = 30;
            iconPictureBox4.Location = new Point(8, 129);
            iconPictureBox4.Name = "iconPictureBox4";
            iconPictureBox4.Size = new Size(31, 30);
            iconPictureBox4.TabIndex = 68;
            iconPictureBox4.TabStop = false;
            // 
            // iconPictureBox3
            // 
            iconPictureBox3.BackColor = Color.FromArgb(51, 51, 76);
            iconPictureBox3.ForeColor = SystemColors.AppWorkspace;
            iconPictureBox3.IconChar = FontAwesome.Sharp.IconChar.UserEdit;
            iconPictureBox3.IconColor = SystemColors.AppWorkspace;
            iconPictureBox3.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconPictureBox3.Location = new Point(476, 77);
            iconPictureBox3.Name = "iconPictureBox3";
            iconPictureBox3.Size = new Size(32, 32);
            iconPictureBox3.TabIndex = 67;
            iconPictureBox3.TabStop = false;
            // 
            // iconPictureBox2
            // 
            iconPictureBox2.BackColor = Color.FromArgb(51, 51, 76);
            iconPictureBox2.ForeColor = SystemColors.AppWorkspace;
            iconPictureBox2.IconChar = FontAwesome.Sharp.IconChar.UserEdit;
            iconPictureBox2.IconColor = SystemColors.AppWorkspace;
            iconPictureBox2.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconPictureBox2.Location = new Point(7, 73);
            iconPictureBox2.Name = "iconPictureBox2";
            iconPictureBox2.Size = new Size(32, 32);
            iconPictureBox2.TabIndex = 66;
            iconPictureBox2.TabStop = false;
            // 
            // panel10
            // 
            panel10.BackColor = Color.Gray;
            panel10.Location = new Point(605, 199);
            panel10.Name = "panel10";
            panel10.Size = new Size(250, 1);
            panel10.TabIndex = 64;
            // 
            // panel9
            // 
            panel9.BackColor = Color.Gray;
            panel9.Location = new Point(606, 153);
            panel9.Name = "panel9";
            panel9.Size = new Size(250, 1);
            panel9.TabIndex = 65;
            // 
            // panel8
            // 
            panel8.BackColor = Color.Gray;
            panel8.Location = new Point(144, 153);
            panel8.Name = "panel8";
            panel8.Size = new Size(263, 1);
            panel8.TabIndex = 63;
            // 
            // panel7
            // 
            panel7.BackColor = Color.Gray;
            panel7.Location = new Point(144, 199);
            panel7.Name = "panel7";
            panel7.Size = new Size(263, 1);
            panel7.TabIndex = 63;
            // 
            // panel4
            // 
            panel4.BackColor = Color.Gray;
            panel4.Location = new Point(606, 108);
            panel4.Name = "panel4";
            panel4.Size = new Size(250, 1);
            panel4.TabIndex = 63;
            // 
            // panel2
            // 
            panel2.BackColor = Color.Gray;
            panel2.Controls.Add(panel1);
            panel2.Location = new Point(144, 103);
            panel2.Name = "panel2";
            panel2.Size = new Size(263, 1);
            panel2.TabIndex = 62;
            // 
            // panel1
            // 
            panel1.BackColor = Color.Gray;
            panel1.Controls.Add(panel3);
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(263, 1);
            panel1.TabIndex = 63;
            // 
            // panel3
            // 
            panel3.BackColor = Color.Gray;
            panel3.Location = new Point(0, 0);
            panel3.Name = "panel3";
            panel3.Size = new Size(263, 1);
            panel3.TabIndex = 63;
            // 
            // iconPictureBox1
            // 
            iconPictureBox1.BackColor = Color.FromArgb(51, 51, 76);
            iconPictureBox1.ForeColor = SystemColors.AppWorkspace;
            iconPictureBox1.IconChar = FontAwesome.Sharp.IconChar.PeopleRoof;
            iconPictureBox1.IconColor = SystemColors.AppWorkspace;
            iconPictureBox1.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconPictureBox1.IconSize = 39;
            iconPictureBox1.Location = new Point(8, 17);
            iconPictureBox1.Name = "iconPictureBox1";
            iconPictureBox1.Size = new Size(39, 46);
            iconPictureBox1.TabIndex = 47;
            iconPictureBox1.TabStop = false;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Sitka Banner", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.FromArgb(204, 204, 204);
            label1.Location = new Point(44, 17);
            label1.Name = "label1";
            label1.Size = new Size(241, 35);
            label1.TabIndex = 46;
            label1.Text = "Add Guest Information";
            // 
            // CNICtxt
            // 
            CNICtxt.BackColor = Color.FromArgb(51, 51, 76);
            CNICtxt.BorderStyle = BorderStyle.None;
            CNICtxt.Font = new Font("Sitka Banner", 14.2499981F, FontStyle.Bold);
            CNICtxt.ForeColor = SystemColors.AppWorkspace;
            CNICtxt.Location = new Point(144, 172);
            CNICtxt.Margin = new Padding(4, 3, 4, 3);
            CNICtxt.Name = "CNICtxt";
            CNICtxt.Size = new Size(263, 24);
            CNICtxt.TabIndex = 38;
            CNICtxt.TextChanged += textBox1_TextChanged;
            // 
            // CNIC
            // 
            CNIC.AutoSize = true;
            CNIC.Font = new Font("Sitka Banner", 14.2499981F, FontStyle.Bold);
            CNIC.ForeColor = SystemColors.AppWorkspace;
            CNIC.Location = new Point(39, 176);
            CNIC.Margin = new Padding(4, 0, 4, 0);
            CNIC.Name = "CNIC";
            CNIC.Size = new Size(51, 28);
            CNIC.TabIndex = 37;
            CNIC.Text = "CNIC";
            // 
            // InactiveRadioBtn
            // 
            InactiveRadioBtn.AutoSize = true;
            InactiveRadioBtn.Font = new Font("Sitka Banner", 14.2499981F, FontStyle.Bold);
            InactiveRadioBtn.ForeColor = SystemColors.AppWorkspace;
            InactiveRadioBtn.Location = new Point(144, 290);
            InactiveRadioBtn.Margin = new Padding(4, 3, 4, 3);
            InactiveRadioBtn.Name = "InactiveRadioBtn";
            InactiveRadioBtn.Size = new Size(93, 32);
            InactiveRadioBtn.TabIndex = 36;
            InactiveRadioBtn.TabStop = true;
            InactiveRadioBtn.Text = "InActive";
            InactiveRadioBtn.UseVisualStyleBackColor = true;
            // 
            // ActiveRadioBtn
            // 
            ActiveRadioBtn.AutoSize = true;
            ActiveRadioBtn.Font = new Font("Sitka Banner", 14.2499981F, FontStyle.Bold);
            ActiveRadioBtn.ForeColor = SystemColors.AppWorkspace;
            ActiveRadioBtn.Location = new Point(39, 290);
            ActiveRadioBtn.Margin = new Padding(4, 3, 4, 3);
            ActiveRadioBtn.Name = "ActiveRadioBtn";
            ActiveRadioBtn.Size = new Size(77, 32);
            ActiveRadioBtn.TabIndex = 35;
            ActiveRadioBtn.TabStop = true;
            ActiveRadioBtn.Text = "Active";
            ActiveRadioBtn.UseVisualStyleBackColor = true;
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.Font = new Font("Sitka Banner", 14.2499981F, FontStyle.Bold);
            label16.ForeColor = SystemColors.AppWorkspace;
            label16.Location = new Point(44, 241);
            label16.Margin = new Padding(4, 0, 4, 0);
            label16.Name = "label16";
            label16.Size = new Size(162, 28);
            label16.TabIndex = 34;
            label16.Text = "Membership Status";
            // 
            // addGbtn
            // 
            addGbtn.BackColor = Color.FromArgb(51, 51, 76);
            addGbtn.FlatStyle = FlatStyle.Flat;
            addGbtn.Font = new Font("Sitka Banner", 14.2499981F, FontStyle.Bold);
            addGbtn.ForeColor = SystemColors.AppWorkspace;
            addGbtn.Location = new Point(605, 332);
            addGbtn.Margin = new Padding(4, 3, 4, 3);
            addGbtn.Name = "addGbtn";
            addGbtn.Size = new Size(258, 44);
            addGbtn.TabIndex = 23;
            addGbtn.Text = "Add GuestInfo";
            addGbtn.UseVisualStyleBackColor = false;
            addGbtn.Click += addGbtn_Click;
            // 
            // add_txt
            // 
            add_txt.BackColor = Color.FromArgb(51, 51, 76);
            add_txt.BorderStyle = BorderStyle.None;
            add_txt.Font = new Font("Sitka Banner", 14.2499981F, FontStyle.Bold);
            add_txt.ForeColor = SystemColors.AppWorkspace;
            add_txt.Location = new Point(606, 172);
            add_txt.Margin = new Padding(4, 3, 4, 3);
            add_txt.Name = "add_txt";
            add_txt.Size = new Size(246, 24);
            add_txt.TabIndex = 21;
            // 
            // email_txt
            // 
            email_txt.BackColor = Color.FromArgb(51, 51, 76);
            email_txt.BorderStyle = BorderStyle.None;
            email_txt.Font = new Font("Sitka Banner", 14.2499981F, FontStyle.Bold);
            email_txt.ForeColor = SystemColors.AppWorkspace;
            email_txt.Location = new Point(605, 128);
            email_txt.Margin = new Padding(4, 3, 4, 3);
            email_txt.Name = "email_txt";
            email_txt.Size = new Size(246, 24);
            email_txt.TabIndex = 20;
            // 
            // phone_txt
            // 
            phone_txt.BackColor = Color.FromArgb(51, 51, 76);
            phone_txt.BorderStyle = BorderStyle.None;
            phone_txt.Font = new Font("Sitka Banner", 14.2499981F, FontStyle.Bold);
            phone_txt.ForeColor = SystemColors.AppWorkspace;
            phone_txt.Location = new Point(144, 123);
            phone_txt.Margin = new Padding(4, 3, 4, 3);
            phone_txt.Name = "phone_txt";
            phone_txt.Size = new Size(261, 24);
            phone_txt.TabIndex = 19;
            // 
            // lname_txt
            // 
            lname_txt.BackColor = Color.FromArgb(51, 51, 76);
            lname_txt.BorderStyle = BorderStyle.None;
            lname_txt.Font = new Font("Sitka Banner", 14.2499981F, FontStyle.Bold);
            lname_txt.ForeColor = SystemColors.AppWorkspace;
            lname_txt.Location = new Point(607, 83);
            lname_txt.Margin = new Padding(4, 3, 4, 3);
            lname_txt.Name = "lname_txt";
            lname_txt.Size = new Size(246, 24);
            lname_txt.TabIndex = 18;
            // 
            // fname_txt
            // 
            fname_txt.BackColor = Color.FromArgb(51, 51, 76);
            fname_txt.BorderStyle = BorderStyle.None;
            fname_txt.Font = new Font("Sitka Banner", 14.2499981F, FontStyle.Bold);
            fname_txt.ForeColor = SystemColors.AppWorkspace;
            fname_txt.Location = new Point(144, 77);
            fname_txt.Margin = new Padding(4, 3, 4, 3);
            fname_txt.Name = "fname_txt";
            fname_txt.Size = new Size(261, 24);
            fname_txt.TabIndex = 17;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Sitka Banner", 14.2499981F, FontStyle.Bold);
            label6.ForeColor = SystemColors.AppWorkspace;
            label6.Location = new Point(505, 172);
            label6.Margin = new Padding(4, 0, 4, 0);
            label6.Name = "label6";
            label6.Size = new Size(75, 28);
            label6.TabIndex = 16;
            label6.Text = "Address";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Sitka Banner", 14.2499981F, FontStyle.Bold);
            label5.ForeColor = SystemColors.AppWorkspace;
            label5.Location = new Point(505, 128);
            label5.Margin = new Padding(4, 0, 4, 0);
            label5.Name = "label5";
            label5.Size = new Size(61, 28);
            label5.TabIndex = 15;
            label5.Text = "Email ";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Sitka Banner", 14.2499981F, FontStyle.Bold);
            label4.ForeColor = SystemColors.AppWorkspace;
            label4.Location = new Point(505, 79);
            label4.Margin = new Padding(4, 0, 4, 0);
            label4.Name = "label4";
            label4.Size = new Size(94, 28);
            label4.TabIndex = 14;
            label4.Text = "Last Name";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Sitka Banner", 14.2499981F, FontStyle.Bold);
            label3.ForeColor = SystemColors.AppWorkspace;
            label3.Location = new Point(39, 131);
            label3.Margin = new Padding(4, 0, 4, 0);
            label3.Name = "label3";
            label3.Size = new Size(90, 28);
            label3.TabIndex = 13;
            label3.Text = "Phone No.";
            label3.Click += label3_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Sitka Banner", 14.2499981F, FontStyle.Bold);
            label2.ForeColor = SystemColors.AppWorkspace;
            label2.Location = new Point(38, 76);
            label2.Margin = new Padding(4, 0, 4, 0);
            label2.Name = "label2";
            label2.Size = new Size(98, 28);
            label2.TabIndex = 12;
            label2.Text = "First Name";
            // 
            // tabPage4
            // 
            tabPage4.BackColor = Color.FromArgb(51, 51, 76);
            tabPage4.Controls.Add(iconPictureBox10);
            tabPage4.Controls.Add(panel5);
            tabPage4.Controls.Add(iconPictureBox9);
            tabPage4.Controls.Add(label18);
            tabPage4.Controls.Add(label15);
            tabPage4.Controls.Add(Displaybtn);
            tabPage4.Controls.Add(R_datagrid);
            tabPage4.Controls.Add(label13);
            tabPage4.Controls.Add(R_idsearch);
            tabPage4.Controls.Add(R_searchbtn);
            tabPage4.Location = new Point(4, 4);
            tabPage4.Margin = new Padding(4, 3, 4, 3);
            tabPage4.Name = "tabPage4";
            tabPage4.Size = new Size(872, 392);
            tabPage4.TabIndex = 4;
            tabPage4.Text = "Search Guest";
            // 
            // iconPictureBox10
            // 
            iconPictureBox10.BackColor = Color.FromArgb(51, 51, 76);
            iconPictureBox10.ForeColor = SystemColors.AppWorkspace;
            iconPictureBox10.IconChar = FontAwesome.Sharp.IconChar.Search;
            iconPictureBox10.IconColor = SystemColors.AppWorkspace;
            iconPictureBox10.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconPictureBox10.IconSize = 39;
            iconPictureBox10.Location = new Point(8, 57);
            iconPictureBox10.Name = "iconPictureBox10";
            iconPictureBox10.Size = new Size(39, 48);
            iconPictureBox10.TabIndex = 65;
            iconPictureBox10.TabStop = false;
            // 
            // panel5
            // 
            panel5.BackColor = Color.Gray;
            panel5.Location = new Point(130, 85);
            panel5.Name = "panel5";
            panel5.Size = new Size(263, 1);
            panel5.TabIndex = 64;
            // 
            // iconPictureBox9
            // 
            iconPictureBox9.BackColor = Color.FromArgb(51, 51, 76);
            iconPictureBox9.ForeColor = SystemColors.AppWorkspace;
            iconPictureBox9.IconChar = FontAwesome.Sharp.IconChar.PeopleRoof;
            iconPictureBox9.IconColor = SystemColors.AppWorkspace;
            iconPictureBox9.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconPictureBox9.IconSize = 39;
            iconPictureBox9.Location = new Point(8, 5);
            iconPictureBox9.Name = "iconPictureBox9";
            iconPictureBox9.Size = new Size(39, 46);
            iconPictureBox9.TabIndex = 49;
            iconPictureBox9.TabStop = false;
            // 
            // label18
            // 
            label18.AutoSize = true;
            label18.Font = new Font("Sitka Banner", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label18.ForeColor = Color.FromArgb(204, 204, 204);
            label18.Location = new Point(44, 5);
            label18.Name = "label18";
            label18.Size = new Size(270, 35);
            label18.TabIndex = 48;
            label18.Text = "Search Guest Information";
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.Font = new Font("Sitka Banner", 14.2499981F, FontStyle.Bold);
            label15.ForeColor = SystemColors.AppWorkspace;
            label15.Location = new Point(44, 66);
            label15.Margin = new Padding(4, 0, 4, 0);
            label15.Name = "label15";
            label15.Size = new Size(78, 28);
            label15.TabIndex = 38;
            label15.Text = "Guest ID";
            label15.Click += label15_Click;
            // 
            // Displaybtn
            // 
            Displaybtn.BackColor = Color.FromArgb(51, 51, 76);
            Displaybtn.FlatStyle = FlatStyle.Flat;
            Displaybtn.Font = new Font("Sitka Banner", 14.2499981F, FontStyle.Bold);
            Displaybtn.ForeColor = SystemColors.AppWorkspace;
            Displaybtn.Location = new Point(668, 58);
            Displaybtn.Margin = new Padding(4, 3, 4, 3);
            Displaybtn.Name = "Displaybtn";
            Displaybtn.RightToLeft = RightToLeft.No;
            Displaybtn.Size = new Size(195, 36);
            Displaybtn.TabIndex = 32;
            Displaybtn.Text = "Display GuestInfo";
            Displaybtn.UseVisualStyleBackColor = false;
            Displaybtn.Click += Displaybtn_Click;
            // 
            // R_datagrid
            // 
            R_datagrid.BackgroundColor = Color.FromArgb(51, 51, 76);
            R_datagrid.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            R_datagrid.Dock = DockStyle.Bottom;
            R_datagrid.Location = new Point(0, 111);
            R_datagrid.Margin = new Padding(4, 3, 4, 3);
            R_datagrid.Name = "R_datagrid";
            R_datagrid.RowHeadersWidth = 62;
            R_datagrid.Size = new Size(872, 281);
            R_datagrid.TabIndex = 31;
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Font = new Font("Microsoft Tai Le", 15.75F);
            label13.Location = new Point(26, 22);
            label13.Margin = new Padding(4, 0, 4, 0);
            label13.Name = "label13";
            label13.Size = new Size(0, 26);
            label13.TabIndex = 30;
            // 
            // R_idsearch
            // 
            R_idsearch.BackColor = Color.FromArgb(51, 51, 76);
            R_idsearch.BorderStyle = BorderStyle.None;
            R_idsearch.Font = new Font("Sitka Banner", 14.2499981F, FontStyle.Bold);
            R_idsearch.ForeColor = SystemColors.AppWorkspace;
            R_idsearch.Location = new Point(130, 59);
            R_idsearch.Margin = new Padding(4, 3, 4, 3);
            R_idsearch.Name = "R_idsearch";
            R_idsearch.Size = new Size(262, 24);
            R_idsearch.TabIndex = 29;
            // 
            // R_searchbtn
            // 
            R_searchbtn.BackColor = Color.FromArgb(51, 51, 76);
            R_searchbtn.FlatStyle = FlatStyle.Flat;
            R_searchbtn.Font = new Font("Sitka Banner", 14.2499981F, FontStyle.Bold);
            R_searchbtn.ForeColor = SystemColors.AppWorkspace;
            R_searchbtn.Location = new Point(430, 56);
            R_searchbtn.Margin = new Padding(4, 3, 4, 3);
            R_searchbtn.Name = "R_searchbtn";
            R_searchbtn.RightToLeft = RightToLeft.No;
            R_searchbtn.Size = new Size(183, 38);
            R_searchbtn.TabIndex = 28;
            R_searchbtn.Text = "Search GuestInfo";
            R_searchbtn.UseVisualStyleBackColor = false;
            R_searchbtn.Click += R_searchbtn_Click;
            // 
            // tabPage1
            // 
            tabPage1.BackColor = Color.FromArgb(51, 51, 76);
            tabPage1.Controls.Add(panel17);
            tabPage1.Controls.Add(panel16);
            tabPage1.Controls.Add(panel15);
            tabPage1.Controls.Add(panel14);
            tabPage1.Controls.Add(panel13);
            tabPage1.Controls.Add(panel12);
            tabPage1.Controls.Add(panel6);
            tabPage1.Controls.Add(iconPictureBox18);
            tabPage1.Controls.Add(label7);
            tabPage1.Controls.Add(iconPictureBox17);
            tabPage1.Controls.Add(label17);
            tabPage1.Controls.Add(iconPictureBox16);
            tabPage1.Controls.Add(label8);
            tabPage1.Controls.Add(iconPictureBox15);
            tabPage1.Controls.Add(label9);
            tabPage1.Controls.Add(iconPictureBox14);
            tabPage1.Controls.Add(label11);
            tabPage1.Controls.Add(iconPictureBox13);
            tabPage1.Controls.Add(label12);
            tabPage1.Controls.Add(iconPictureBox12);
            tabPage1.Controls.Add(label14);
            tabPage1.Controls.Add(iconPictureBox11);
            tabPage1.Controls.Add(label10);
            tabPage1.Controls.Add(label19);
            tabPage1.Controls.Add(textBox);
            tabPage1.Controls.Add(Idtxt);
            tabPage1.Controls.Add(UPLNametxt);
            tabPage1.Controls.Add(UpFNametxt);
            tabPage1.Controls.Add(updateGbtn);
            tabPage1.Controls.Add(Upaddtxt);
            tabPage1.Controls.Add(UpEmailtxt);
            tabPage1.Controls.Add(UpPhotxt);
            tabPage1.Location = new Point(4, 4);
            tabPage1.Margin = new Padding(4, 3, 4, 3);
            tabPage1.Name = "tabPage1";
            tabPage1.Size = new Size(872, 392);
            tabPage1.TabIndex = 2;
            tabPage1.Text = "Update  Guest";
            tabPage1.Click += tabPage1_Click;
            // 
            // panel17
            // 
            panel17.BackColor = Color.Gray;
            panel17.Location = new Point(142, 114);
            panel17.Name = "panel17";
            panel17.Size = new Size(704, 1);
            panel17.TabIndex = 86;
            // 
            // panel16
            // 
            panel16.BackColor = Color.Gray;
            panel16.Location = new Point(609, 298);
            panel16.Name = "panel16";
            panel16.Size = new Size(239, 1);
            panel16.TabIndex = 85;
            // 
            // panel15
            // 
            panel15.BackColor = Color.Gray;
            panel15.Location = new Point(609, 232);
            panel15.Name = "panel15";
            panel15.Size = new Size(239, 1);
            panel15.TabIndex = 84;
            // 
            // panel14
            // 
            panel14.BackColor = Color.Gray;
            panel14.Location = new Point(609, 174);
            panel14.Name = "panel14";
            panel14.Size = new Size(239, 1);
            panel14.TabIndex = 83;
            // 
            // panel13
            // 
            panel13.BackColor = Color.Gray;
            panel13.Location = new Point(149, 298);
            panel13.Name = "panel13";
            panel13.Size = new Size(263, 1);
            panel13.TabIndex = 82;
            // 
            // panel12
            // 
            panel12.BackColor = Color.Gray;
            panel12.Location = new Point(149, 232);
            panel12.Name = "panel12";
            panel12.Size = new Size(263, 1);
            panel12.TabIndex = 81;
            // 
            // panel6
            // 
            panel6.BackColor = Color.Gray;
            panel6.Controls.Add(panel11);
            panel6.Location = new Point(154, 174);
            panel6.Name = "panel6";
            panel6.Size = new Size(263, 1);
            panel6.TabIndex = 80;
            // 
            // panel11
            // 
            panel11.BackColor = Color.Gray;
            panel11.Location = new Point(0, 0);
            panel11.Name = "panel11";
            panel11.Size = new Size(263, 1);
            panel11.TabIndex = 64;
            // 
            // iconPictureBox18
            // 
            iconPictureBox18.BackColor = Color.FromArgb(51, 51, 76);
            iconPictureBox18.ForeColor = SystemColors.AppWorkspace;
            iconPictureBox18.IconChar = FontAwesome.Sharp.IconChar.Archway;
            iconPictureBox18.IconColor = SystemColors.AppWorkspace;
            iconPictureBox18.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconPictureBox18.Location = new Point(475, 261);
            iconPictureBox18.Name = "iconPictureBox18";
            iconPictureBox18.Size = new Size(32, 32);
            iconPictureBox18.TabIndex = 79;
            iconPictureBox18.TabStop = false;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Sitka Banner", 14.2499981F, FontStyle.Bold);
            label7.ForeColor = SystemColors.AppWorkspace;
            label7.Location = new Point(504, 261);
            label7.Margin = new Padding(4, 0, 4, 0);
            label7.Name = "label7";
            label7.Size = new Size(75, 28);
            label7.TabIndex = 78;
            label7.Text = "Address";
            // 
            // iconPictureBox17
            // 
            iconPictureBox17.BackColor = Color.FromArgb(51, 51, 76);
            iconPictureBox17.ForeColor = SystemColors.AppWorkspace;
            iconPictureBox17.IconChar = FontAwesome.Sharp.IconChar.IdCard;
            iconPictureBox17.IconColor = SystemColors.AppWorkspace;
            iconPictureBox17.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconPictureBox17.Location = new Point(10, 265);
            iconPictureBox17.Name = "iconPictureBox17";
            iconPictureBox17.Size = new Size(32, 32);
            iconPictureBox17.TabIndex = 77;
            iconPictureBox17.TabStop = false;
            // 
            // label17
            // 
            label17.AutoSize = true;
            label17.Font = new Font("Sitka Banner", 14.2499981F, FontStyle.Bold);
            label17.ForeColor = SystemColors.AppWorkspace;
            label17.Location = new Point(41, 265);
            label17.Margin = new Padding(4, 0, 4, 0);
            label17.Name = "label17";
            label17.Size = new Size(51, 28);
            label17.TabIndex = 76;
            label17.Text = "CNIC";
            // 
            // iconPictureBox16
            // 
            iconPictureBox16.BackColor = Color.FromArgb(51, 51, 76);
            iconPictureBox16.ForeColor = SystemColors.AppWorkspace;
            iconPictureBox16.IconChar = FontAwesome.Sharp.IconChar.Envelope;
            iconPictureBox16.IconColor = SystemColors.AppWorkspace;
            iconPictureBox16.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconPictureBox16.Location = new Point(475, 194);
            iconPictureBox16.Name = "iconPictureBox16";
            iconPictureBox16.Size = new Size(32, 32);
            iconPictureBox16.TabIndex = 75;
            iconPictureBox16.TabStop = false;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Sitka Banner", 14.2499981F, FontStyle.Bold);
            label8.ForeColor = SystemColors.AppWorkspace;
            label8.Location = new Point(504, 195);
            label8.Margin = new Padding(4, 0, 4, 0);
            label8.Name = "label8";
            label8.Size = new Size(61, 28);
            label8.TabIndex = 74;
            label8.Text = "Email ";
            // 
            // iconPictureBox15
            // 
            iconPictureBox15.BackColor = Color.FromArgb(51, 51, 76);
            iconPictureBox15.ForeColor = SystemColors.AppWorkspace;
            iconPictureBox15.IconChar = FontAwesome.Sharp.IconChar.Phone;
            iconPictureBox15.IconColor = SystemColors.AppWorkspace;
            iconPictureBox15.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconPictureBox15.IconSize = 30;
            iconPictureBox15.Location = new Point(10, 197);
            iconPictureBox15.Name = "iconPictureBox15";
            iconPictureBox15.Size = new Size(31, 30);
            iconPictureBox15.TabIndex = 73;
            iconPictureBox15.TabStop = false;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Sitka Banner", 14.2499981F, FontStyle.Bold);
            label9.ForeColor = SystemColors.AppWorkspace;
            label9.Location = new Point(41, 199);
            label9.Margin = new Padding(4, 0, 4, 0);
            label9.Name = "label9";
            label9.Size = new Size(90, 28);
            label9.TabIndex = 72;
            label9.Text = "Phone No.";
            // 
            // iconPictureBox14
            // 
            iconPictureBox14.BackColor = Color.FromArgb(51, 51, 76);
            iconPictureBox14.ForeColor = SystemColors.AppWorkspace;
            iconPictureBox14.IconChar = FontAwesome.Sharp.IconChar.UserEdit;
            iconPictureBox14.IconColor = SystemColors.AppWorkspace;
            iconPictureBox14.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconPictureBox14.Location = new Point(475, 133);
            iconPictureBox14.Name = "iconPictureBox14";
            iconPictureBox14.Size = new Size(32, 32);
            iconPictureBox14.TabIndex = 71;
            iconPictureBox14.TabStop = false;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new Font("Sitka Banner", 14.2499981F, FontStyle.Bold);
            label11.ForeColor = SystemColors.AppWorkspace;
            label11.Location = new Point(504, 139);
            label11.Margin = new Padding(4, 0, 4, 0);
            label11.Name = "label11";
            label11.Size = new Size(94, 28);
            label11.TabIndex = 70;
            label11.Text = "Last Name";
            // 
            // iconPictureBox13
            // 
            iconPictureBox13.BackColor = Color.FromArgb(51, 51, 76);
            iconPictureBox13.ForeColor = SystemColors.AppWorkspace;
            iconPictureBox13.IconChar = FontAwesome.Sharp.IconChar.UserEdit;
            iconPictureBox13.IconColor = SystemColors.AppWorkspace;
            iconPictureBox13.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconPictureBox13.Location = new Point(11, 133);
            iconPictureBox13.Name = "iconPictureBox13";
            iconPictureBox13.Size = new Size(32, 32);
            iconPictureBox13.TabIndex = 69;
            iconPictureBox13.TabStop = false;
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Font = new Font("Sitka Banner", 14.2499981F, FontStyle.Bold);
            label12.ForeColor = SystemColors.AppWorkspace;
            label12.Location = new Point(43, 137);
            label12.Margin = new Padding(4, 0, 4, 0);
            label12.Name = "label12";
            label12.Size = new Size(98, 28);
            label12.TabIndex = 68;
            label12.Text = "First Name";
            // 
            // iconPictureBox12
            // 
            iconPictureBox12.BackColor = Color.FromArgb(51, 51, 76);
            iconPictureBox12.ForeColor = SystemColors.AppWorkspace;
            iconPictureBox12.IconChar = FontAwesome.Sharp.IconChar.Search;
            iconPictureBox12.IconColor = SystemColors.AppWorkspace;
            iconPictureBox12.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconPictureBox12.IconSize = 39;
            iconPictureBox12.Location = new Point(10, 68);
            iconPictureBox12.Name = "iconPictureBox12";
            iconPictureBox12.Size = new Size(39, 48);
            iconPictureBox12.TabIndex = 67;
            iconPictureBox12.TabStop = false;
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Font = new Font("Sitka Banner", 14.2499981F, FontStyle.Bold);
            label14.ForeColor = SystemColors.AppWorkspace;
            label14.Location = new Point(53, 80);
            label14.Margin = new Padding(4, 0, 4, 0);
            label14.Name = "label14";
            label14.Size = new Size(78, 28);
            label14.TabIndex = 66;
            label14.Text = "Guest ID";
            // 
            // iconPictureBox11
            // 
            iconPictureBox11.BackColor = Color.FromArgb(51, 51, 76);
            iconPictureBox11.ForeColor = SystemColors.AppWorkspace;
            iconPictureBox11.IconChar = FontAwesome.Sharp.IconChar.PeopleRoof;
            iconPictureBox11.IconColor = SystemColors.AppWorkspace;
            iconPictureBox11.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconPictureBox11.IconSize = 39;
            iconPictureBox11.Location = new Point(5, 5);
            iconPictureBox11.Name = "iconPictureBox11";
            iconPictureBox11.Size = new Size(39, 46);
            iconPictureBox11.TabIndex = 52;
            iconPictureBox11.TabStop = false;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Sitka Banner", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label10.ForeColor = Color.FromArgb(204, 204, 204);
            label10.Location = new Point(41, 5);
            label10.Name = "label10";
            label10.Size = new Size(272, 35);
            label10.TabIndex = 51;
            label10.Text = "Update Guest Information";
            // 
            // label19
            // 
            label19.AutoSize = true;
            label19.Font = new Font("Microsoft Tai Le", 15.75F);
            label19.Location = new Point(23, 22);
            label19.Margin = new Padding(4, 0, 4, 0);
            label19.Name = "label19";
            label19.Size = new Size(0, 26);
            label19.TabIndex = 50;
            // 
            // textBox
            // 
            textBox.BackColor = Color.FromArgb(51, 51, 76);
            textBox.BorderStyle = BorderStyle.None;
            textBox.Font = new Font("Sitka Banner", 14.2499981F, FontStyle.Bold);
            textBox.ForeColor = SystemColors.AppWorkspace;
            textBox.Location = new Point(149, 268);
            textBox.Margin = new Padding(4, 3, 4, 3);
            textBox.Name = "textBox";
            textBox.Size = new Size(268, 24);
            textBox.TabIndex = 40;
            // 
            // Idtxt
            // 
            Idtxt.BackColor = Color.FromArgb(51, 51, 76);
            Idtxt.BorderStyle = BorderStyle.None;
            Idtxt.Font = new Font("Sitka Banner", 14.2499981F, FontStyle.Bold);
            Idtxt.ForeColor = SystemColors.AppWorkspace;
            Idtxt.Location = new Point(142, 84);
            Idtxt.Margin = new Padding(4, 3, 4, 3);
            Idtxt.Name = "Idtxt";
            Idtxt.Size = new Size(706, 24);
            Idtxt.TabIndex = 30;
            Idtxt.TextChanged += Idtxt_TextChanged;
            // 
            // UPLNametxt
            // 
            UPLNametxt.BackColor = Color.FromArgb(51, 51, 76);
            UPLNametxt.BorderStyle = BorderStyle.None;
            UPLNametxt.Font = new Font("Sitka Banner", 14.2499981F, FontStyle.Bold);
            UPLNametxt.ForeColor = SystemColors.AppWorkspace;
            UPLNametxt.Location = new Point(606, 144);
            UPLNametxt.Margin = new Padding(4, 3, 4, 3);
            UPLNametxt.Name = "UPLNametxt";
            UPLNametxt.Size = new Size(242, 24);
            UPLNametxt.TabIndex = 27;
            // 
            // UpFNametxt
            // 
            UpFNametxt.BackColor = Color.FromArgb(51, 51, 76);
            UpFNametxt.BorderStyle = BorderStyle.None;
            UpFNametxt.Font = new Font("Sitka Banner", 14.2499981F, FontStyle.Bold);
            UpFNametxt.ForeColor = SystemColors.AppWorkspace;
            UpFNametxt.Location = new Point(149, 144);
            UpFNametxt.Margin = new Padding(4, 3, 4, 3);
            UpFNametxt.Name = "UpFNametxt";
            UpFNametxt.Size = new Size(268, 24);
            UpFNametxt.TabIndex = 26;
            // 
            // updateGbtn
            // 
            updateGbtn.BackColor = Color.FromArgb(51, 51, 76);
            updateGbtn.Font = new Font("Sitka Banner", 14.2499981F, FontStyle.Bold);
            updateGbtn.ForeColor = SystemColors.AppWorkspace;
            updateGbtn.Location = new Point(475, 332);
            updateGbtn.Margin = new Padding(4, 3, 4, 3);
            updateGbtn.Name = "updateGbtn";
            updateGbtn.Size = new Size(373, 44);
            updateGbtn.TabIndex = 22;
            updateGbtn.Text = "Update GuestInfo";
            updateGbtn.UseVisualStyleBackColor = false;
            updateGbtn.Click += updateGbtn_Click;
            // 
            // Upaddtxt
            // 
            Upaddtxt.BackColor = Color.FromArgb(51, 51, 76);
            Upaddtxt.BorderStyle = BorderStyle.None;
            Upaddtxt.Font = new Font("Sitka Banner", 14.2499981F, FontStyle.Bold);
            Upaddtxt.ForeColor = SystemColors.AppWorkspace;
            Upaddtxt.Location = new Point(606, 268);
            Upaddtxt.Margin = new Padding(4, 3, 4, 3);
            Upaddtxt.Name = "Upaddtxt";
            Upaddtxt.Size = new Size(242, 24);
            Upaddtxt.TabIndex = 20;
            // 
            // UpEmailtxt
            // 
            UpEmailtxt.BackColor = Color.FromArgb(51, 51, 76);
            UpEmailtxt.BorderStyle = BorderStyle.None;
            UpEmailtxt.Font = new Font("Sitka Banner", 14.2499981F, FontStyle.Bold);
            UpEmailtxt.ForeColor = SystemColors.AppWorkspace;
            UpEmailtxt.Location = new Point(606, 202);
            UpEmailtxt.Margin = new Padding(4, 3, 4, 3);
            UpEmailtxt.Name = "UpEmailtxt";
            UpEmailtxt.Size = new Size(242, 24);
            UpEmailtxt.TabIndex = 19;
            // 
            // UpPhotxt
            // 
            UpPhotxt.BackColor = Color.FromArgb(51, 51, 76);
            UpPhotxt.BorderStyle = BorderStyle.None;
            UpPhotxt.Font = new Font("Sitka Banner", 14.2499981F, FontStyle.Bold);
            UpPhotxt.ForeColor = SystemColors.AppWorkspace;
            UpPhotxt.Location = new Point(149, 199);
            UpPhotxt.Margin = new Padding(4, 3, 4, 3);
            UpPhotxt.Name = "UpPhotxt";
            UpPhotxt.Size = new Size(268, 24);
            UpPhotxt.TabIndex = 18;
            // 
            // Guest
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(51, 51, 76);
            ClientSize = new Size(880, 420);
            Controls.Add(tabControl1);
            FormBorderStyle = FormBorderStyle.None;
            Margin = new Padding(2);
            Name = "Guest";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Guest";
            Load += Guest_Load;
            tabControl1.ResumeLayout(false);
            tabPage2.ResumeLayout(false);
            tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox8).EndInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox7).EndInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox6).EndInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox5).EndInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox4).EndInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox3).EndInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox2).EndInit();
            panel2.ResumeLayout(false);
            panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)iconPictureBox1).EndInit();
            tabPage4.ResumeLayout(false);
            tabPage4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox10).EndInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox9).EndInit();
            ((System.ComponentModel.ISupportInitialize)R_datagrid).EndInit();
            tabPage1.ResumeLayout(false);
            tabPage1.PerformLayout();
            panel6.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)iconPictureBox18).EndInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox17).EndInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox16).EndInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox15).EndInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox14).EndInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox13).EndInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox12).EndInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox11).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Button addGbtn;
        private System.Windows.Forms.TextBox add_txt;
        private System.Windows.Forms.TextBox email_txt;
        private System.Windows.Forms.TextBox phone_txt;
        private System.Windows.Forms.TextBox lname_txt;
        private System.Windows.Forms.TextBox fname_txt;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TextBox Idtxt;
        private System.Windows.Forms.TextBox UPLNametxt;
        private System.Windows.Forms.TextBox UpFNametxt;
        private System.Windows.Forms.Button updateGbtn;
        private System.Windows.Forms.TextBox Upaddtxt;
        private System.Windows.Forms.TextBox UpEmailtxt;
        private System.Windows.Forms.TextBox UpPhotxt;
        private System.Windows.Forms.RadioButton InactiveRadioBtn;
        private System.Windows.Forms.RadioButton ActiveRadioBtn;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.Button Displaybtn;
        private System.Windows.Forms.DataGridView R_datagrid;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox R_idsearch;
        private System.Windows.Forms.Button R_searchbtn;
        private System.Windows.Forms.TextBox CNICtxt;
        private System.Windows.Forms.Label CNIC;
        private System.Windows.Forms.TextBox textBox;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox1;
        private Label label1;
        private Panel panel2;
        private Panel panel8;
        private Panel panel7;
        private Panel panel4;
        private Panel panel1;
        private Panel panel3;
        private Panel panel10;
        private Panel panel9;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox4;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox3;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox2;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox7;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox6;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox5;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox8;
        private Label label15;
        private Panel panel5;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox9;
        private Label label18;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox10;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox12;
        private Label label14;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox11;
        private Label label10;
        private Label label19;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox18;
        private Label label7;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox17;
        private Label label17;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox16;
        private Label label8;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox15;
        private Label label9;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox14;
        private Label label11;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox13;
        private Label label12;
        private Panel panel6;
        private Panel panel11;
        private Panel panel17;
        private Panel panel16;
        private Panel panel15;
        private Panel panel14;
        private Panel panel13;
        private Panel panel12;
    }
}
﻿//using System;
//using System.Collections.Generic;
//using System.ComponentModel;
//using System.Data;
//using System.Drawing;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;
//using System.Windows.Forms;

//namespace DBMS_HMS
//{



//    public partial class Facilities : Form
//    {
//        public List<KeyValuePair<string, decimal>> facilityPrices;
//        public decimal totalSum { get; set; }
//        // public decimal totalSum;
//        //public decimal totalSumm
//        //{
//        //    get { return totalSum; }
//        //    set { totalSum = value; }
//        //}
//        public static Facilities Instance;

//        public Facilities()
//        {
//            InitializeComponent();
//            facilityPrices = new List<KeyValuePair<string, decimal>>
//            {
//                new KeyValuePair<string, decimal>("SwimmidecimalngPool", 1200),
//                new KeyValuePair<string, decimal>("Lobby", 800),
//                new KeyValuePair<string, decimal>("Gym", 1000),
//                new KeyValuePair<string, decimal>("Spa", 1500),
//                new KeyValuePair<string, decimal>("GameRoom",1220),
//                new KeyValuePair<string, decimal>("HorseRiding", 3000),
//                new KeyValuePair<string, decimal>("DinningArea", 600)
//            };
//            totalSum = 0;
//            Instance = this;
//        }


//        private void pictureBox4_Click(object sender, EventArgs e)
//        {
//            this.Hide();
//        }

//        private void Res_addGbtn_Click(object sender, EventArgs e)
//        {
//            totalSum = 0;
//            Dictionary<string, decimal> selectedFacilities = new Dictionary<string, decimal>();

//            // Loop through all the CheckBoxes to check which ones are selected
//            foreach (CheckBox facilityCheckBox in groupBoxFacilities.Controls.OfType<CheckBox>())
//            {
//                if (facilityCheckBox.Checked)
//                {
//                    // Get the price assigned to the selected facility
//                    decimal facilityPrice = GetFacilityPrice(facilityCheckBox.Name);

//                    // Sum up the prices of selected facilities
//                    totalSum += facilityPrice;

//                    // Add the selected facility and its price to the dictionary
//                    selectedFacilities.Add(facilityCheckBox.Text, facilityPrice);
//                }
//            }

//            // CalculateAndPrintReceipt method call
//            CalculateAndPrintReceipt(totalSum, selectedFacilities);
//        }

//        public decimal GetFacilityPrice(string facilityName)
//        {
//            // Search for the facility price in the list
//            foreach (KeyValuePair<string, decimal> facility in facilityPrices)
//            {
//                if (facility.Key == facilityName)
//                {
//                    return facility.Value;
//                }
//            }
//            return 0; // Facility price not found
//        }

//        public void CalculateAndPrintReceipt(decimal totalSum, Dictionary<string, decimal> selectedFacilities)
//        {

//            // Example:
//            StringBuilder receiptBuilder = new StringBuilder();
//            receiptBuilder.AppendLine("Receipt");
//            receiptBuilder.AppendLine("---------");
//            receiptBuilder.AppendLine($"Total Sum: {totalSum:C}");
//            receiptBuilder.AppendLine("Selected Facilities:");
//            foreach (var facility in selectedFacilities)
//            {
//                receiptBuilder.AppendLine($"{facility.Key}: {facility.Value:C}");
//            }

//            // Display or process the receipt as needed
//            MessageBox.Show(receiptBuilder.ToString());
//            this.Hide();
//            Reservation reservationForm = new Reservation();
//            reservationForm.FacilitiesTotalSum = totalSum; // Assign the total sum value
//            //reservationForm.Show();
//        }

//        private void btnAddReservation_Click(object sender, EventArgs e)
//        {
//            // Your code to add the reservation goes here
//        }

//        private void checkedListBoxFaclities_SelectedIndexChanged(object sender, EventArgs e)
//        {
//            // Your code for handling the selected index change event goes here
//        }

//        private void iconPictureBox1_Click(object sender, EventArgs e)
//        {
//            Application.Exit();
//        }
//    }
//}


using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Windows.Forms;

namespace DBMS_HMS
{
    public partial class Facilities : Form
    {
        public List<KeyValuePair<string, decimal>> facilityPrices;
        public decimal totalSum { get; set; }

        public static Facilities Instance;

        public Facilities()
        {
            InitializeComponent();
            facilityPrices = new List<KeyValuePair<string, decimal>>
            {
                new KeyValuePair<string, decimal>("SwimmingPool", 1200),
                new KeyValuePair<string, decimal>("Lobby", 800),
                new KeyValuePair<string, decimal>("Gym", 1000),
                new KeyValuePair<string, decimal>("Spa", 1500),
                new KeyValuePair<string, decimal>("GameRoom", 1220),
                new KeyValuePair<string, decimal>("HorseRiding", 3000),
                new KeyValuePair<string, decimal>("DinningArea", 600)
            };
            totalSum = 0;
            Instance = this;
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void Res_addGbtn_Click(object sender, EventArgs e)
        {
            totalSum = 0;
            Dictionary<string, decimal> selectedFacilities = new Dictionary<string, decimal>();

            // Loop through all the CheckBoxes to check which ones are selected
            foreach (CheckBox facilityCheckBox in groupBoxFacilities.Controls.OfType<CheckBox>())
            {
                if (facilityCheckBox.Checked)
                {
                    // Get the price assigned to the selected facility
                    decimal facilityPrice = GetFacilityPrice(facilityCheckBox.Name);

                    // Sum up the prices of selected facilities
                    totalSum += facilityPrice;

                    // Add the selected facility and its price to the dictionary
                    selectedFacilities.Add(facilityCheckBox.Text, facilityPrice);
                }
            }

            // CalculateAndPrintReceipt method call
            CalculateAndPrintReceipt(totalSum, selectedFacilities);

            // Save the totalSum value to a file at runtime
            SaveTotalSumToFile(totalSum);
        }

        public decimal GetFacilityPrice(string facilityName)
        {
            // Search for the facility price in the list
            foreach (KeyValuePair<string, decimal> facility in facilityPrices)
            {
                if (facility.Key == facilityName)
                {
                    return facility.Value;
                }
            }
            return 0; // Facility price not found
        }

        public void CalculateAndPrintReceipt(decimal totalSum, Dictionary<string, decimal> selectedFacilities)
        {
            // Example:
            StringBuilder receiptBuilder = new StringBuilder();
            receiptBuilder.AppendLine("Receipt");
            receiptBuilder.AppendLine("---------");
            receiptBuilder.AppendLine($"Total Sum: {totalSum:C}");
            receiptBuilder.AppendLine("Selected Facilities:");
            foreach (var facility in selectedFacilities)
            {
                receiptBuilder.AppendLine($"{facility.Key}: {facility.Value:C}");
            }

            // Display or process the receipt as needed
            MessageBox.Show(receiptBuilder.ToString());
            this.Hide();
            Reservation reservationForm = new Reservation();
            reservationForm.FacilitiesTotalSum = totalSum; // Assign the total sum value
            //reservationForm.Show();
        }

        private void SaveTotalSumToFile(decimal totalSum)
        {
            try
            {
                // Generate a unique filename with a timestamp
                string fileName = $"TotalFacilitiesSum_{DateTime.Now:yyyyMMdd}.txt";

                // Combine the desktop path with the generated filename
                string desktopPath = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
                string filePath = Path.Combine(desktopPath, fileName);

                // Convert the totalSum value to a string
                string totalSumString = totalSum.ToString();

                // Check if the file already exists
                if (File.Exists(filePath))
                {
                    // Append the totalSum value to the existing file
                    File.AppendAllText(filePath, totalSumString + Environment.NewLine);
                }
                else
                {
                    // Create a new file and write the totalSum value
                    File.WriteAllText(filePath, totalSumString + Environment.NewLine);
                }

                MessageBox.Show($"Total Facilities Sum appended to file: {filePath}");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error saving Total Facilities Sum to file: {ex.Message}");
            }
        }

        private void btnAddReservation_Click(object sender, EventArgs e)
        {
            // Your code to add the reservation goes here
        }

        private void checkedListBoxFaclities_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Your code for handling the selected index change event goes here
        }

        private void iconPictureBox1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}

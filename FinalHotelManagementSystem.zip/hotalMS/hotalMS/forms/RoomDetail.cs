﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace hotalMS.forms
{
    public partial class RoomDetail : Form
    {
        public RoomDetail()
        {
            InitializeComponent();
        }

        SqlConnection con = new SqlConnection("Data Source=DESKTOP-KFDUOB5\\MSSQLSERVER2022;Initial Catalog=HotelManagementSystem;Integrated Security=True;Encrypt=True;TrustServerCertificate=True");

        private void iconRoomId_Click(object sender, EventArgs e)
        {
           

            string roomIdText = R_idsearch.Text;
            if (int.TryParse(roomIdText, out int roomId))
            {
                using (SqlConnection con = new SqlConnection("Data Source=DESKTOP-KFDUOB5\\MSSQLSERVER2022;Initial Catalog=HotelManagementSystem;Integrated Security=True;Encrypt=True;TrustServerCertificate=True"))
                {
                    try
                    {
                        con.Open();
                        SqlCommand cmd = new SqlCommand("SearchByRoomID", con);
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@RoomID", roomId);

                        SqlDataAdapter da = new SqlDataAdapter(cmd);
                        DataTable dt = new DataTable();
                        da.Fill(dt);

                        if (dt.Rows.Count > 0)
                        {
                            dataGridView1.DataSource = dt;
                            R_idsearch.Clear();
                        }
                        else
                        {
                            MessageBox.Show("Room ID not found in the database.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("An error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            else
            {
                MessageBox.Show("Invalid Room ID! Please enter a valid integer value.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }


        }

        private void iconRoomstatus_Click(object sender, EventArgs e)
        {
           
            string Room_Status = Rtyp.Text.ToLower(); // Convert to lowercase

            if (string.Equals(Room_Status, "vacant", StringComparison.OrdinalIgnoreCase))
            {
                using (SqlConnection con = new SqlConnection("Data Source=DESKTOP-KFDUOB5\\MSSQLSERVER2022;Initial Catalog=HotelManagementSystem;Integrated Security=True;Encrypt=True;TrustServerCertificate=True"))
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand("Select * from ReservationView where LOWER(Room_Status) = 'vacant'", con); // Use LOWER function here
                    cmd.ExecuteNonQuery();
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    dataGridView1.DataSource = dt;
                    Rtyp.Clear();
                    con.Close();
                }
            }
            else if (string.Equals(Room_Status, "occupied", StringComparison.OrdinalIgnoreCase))
            {
                using (SqlConnection con = new SqlConnection("Data Source=DESKTOP-KFDUOB5\\MSSQLSERVER2022;Initial Catalog=HotelManagementSystem;Integrated Security=True;Encrypt=True;TrustServerCertificate=True"))
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand("Select * from ReservationView where LOWER(Room_Status) = 'occupied'", con); // Use LOWER function here
                    cmd.ExecuteNonQuery();
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    dataGridView1.DataSource = dt;
                    Rtyp.Clear();
                    con.Close();
                }
            }
            else
            {
                MessageBox.Show("Invalid Room Type!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void Displaybtn_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("select * from ReservationView", con);
            cmd.ExecuteNonQuery();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
            con.Close();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }
    }
}

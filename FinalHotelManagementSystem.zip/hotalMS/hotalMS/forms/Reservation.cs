﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace DBMS_HMS
{

    public partial class Reservation : Form
    {


        public decimal totalFacilitiesSum;
        private decimal totalRoomPrice;
        private decimal facilitiesTotalSum;
        private Facilities fa;
        public decimal summ;

        public decimal FacilitiesTotalSum
        {
            get { return facilitiesTotalSum; }
            set { facilitiesTotalSum = value; }
        }

        decimal totalSumValue;

        public Reservation(Facilities f)
        {
            InitializeComponent();
            totalRoomPrice = 0;
            fa = f;
            totalSumValue = fa.totalSum;
            facilitiesTotalSum = f.totalSum;  // Set facilitiesTotalSum directly
        }

        public Reservation()
        {
            InitializeComponent();
            Facilities F = new Facilities();
            this.facilitiesTotalSum = F.totalSum;  // Set facilitiesTotalSum directly for the current object
        }




        SqlConnection con = new SqlConnection("Data Source=DESKTOP-KFDUOB5\\MSSQLSERVER2022;Initial Catalog=HotelManagementSystem;Integrated Security=True;Encrypt=True;TrustServerCertificate=True");
        // ProgrammingClassDataContext db = new ProgrammingClassDataContext();
        DateTime today;

        private void Reservation_Load(object sender, EventArgs e)
        {
            today = checkin.Value;

        }

        private void checkin_ValueChanged(object sender, EventArgs e)
        {
            int res = DateTime.Compare(checkin.Value, today);
            if (res < 0)
                MessageBox.Show("WRONG date for reservation");
        }

        private void checkout_ValueChanged(object sender, EventArgs e)
        {
            //int res = DateTime.Compare(checkout.Value, checkin.Value);
            //if (res <= 0)
            //    MessageBox.Show("Invalid date for check out");

            int res = DateTime.Compare(checkout.Value, checkin.Value);
            if (res < 0)
                MessageBox.Show("Invalid date for check out");

        }



        ///extraaaa

        private bool HasActiveReservation(int guestId)
        {
            // Replace "YourConnectionString" with your actual database connection string
            string connectionString = "Data Source=DESKTOP-KFDUOB5\\MSSQLSERVER2022;Initial Catalog=HotelManagementSystem;Integrated Security=True;Encrypt=True;TrustServerCertificate=True";

            // Replace the SQL query with your actual query to check for active reservations
            string query = "SELECT COUNT(*) FROM Reservations WHERE Guest_ID = @GuestId AND Check_Out_Date > GETDATE()";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@GuestId", guestId);

                    try
                    {
                        connection.Open();
                        int count = (int)command.ExecuteScalar();

                        // If count is greater than 0, there is an active reservation
                        return count > 0;
                    }
                    catch (Exception ex)
                    {
                        // Handle exceptions as needed
                        Console.WriteLine("Error checking for active reservation: " + ex.Message);
                        return false;
                    }
                }
            }
        }


        private void Res_addGbtn_Click(object sender, EventArgs e)
        {
            

            int guestId;
            if (int.TryParse(G_combo.Text, out guestId))
            {
                if (!CheckGuestExists(guestId))
                {
                    MessageBox.Show("Invalid Guest ID. Please enter a valid Guest ID.");
                    return; // Exit the method without proceeding further
                }
            }
            else
            {
                MessageBox.Show("Invalid Guest ID. Please enter a numeric value.");
                return; // Exit the method without proceeding further
            }

            if (G_combo.Text.Trim() == string.Empty || R_nocombo.Text.Trim() == string.Empty || Rtypecombo.Text == string.Empty)
            {
                MessageBox.Show("Please fill all fields.", "Require all fields", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return; // Exit the method without proceeding further
            }

            if (HasActiveReservation(guestId))
            {
                MessageBox.Show("Guest has an active reservation or has not checked out yet. Cannot add a new reservation.");
                return; // Exit the method without proceeding further
            }

            decimal sum = GetLastAppendedSumFromFile();


            // Ask for confirmation before adding the reservation
            DialogResult result = MessageBox.Show("Are you sure you want to add the reservation?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            {
                // User clicked "Yes," proceed with adding the reservation
                AddReservation();
                populate();
               
            }


        }


        private void AddReservation()
        {
            try
            {
                con.Open();
                decimal sum = GetLastAppendedSumFromFile();
                string guestid = G_combo.Text; // Replace with your actual TextBox for Guest Name
                string roomNumber = R_nocombo.Text;

                string roomType = Rtypecombo.SelectedItem.ToString();
                DateTime checkInDate = checkin.Value;
                DateTime checkOutDate = checkout.Value;

                //int guestId = RetrieveGuestId(guestid);
                int roomId = RetrieveRoomId(roomNumber);

                using (SqlConnection connection = new SqlConnection("Data Source=DESKTOP-KFDUOB5\\MSSQLSERVER2022;Initial Catalog=HotelManagementSystem;Integrated Security=True;Encrypt=True;TrustServerCertificate=True"))
                {
                    SqlCommand command = new SqlCommand("InsertReservation", connection);
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@GuestID", guestid);
                    command.Parameters.AddWithValue("@RoomID", roomId);
                    command.Parameters.AddWithValue("@Roomtype", roomType);
                    command.Parameters.AddWithValue("@RoomNo", roomNumber);
                    command.Parameters.AddWithValue("@CheckInDate", checkInDate);
                    command.Parameters.AddWithValue("@CheckOutDate", checkOutDate);

                    connection.Open();
                    int rowsAffected = command.ExecuteNonQuery();
                    connection.Close();

                    if (rowsAffected > 0)
                    {
                        // Update room status to "occupied"
                        string updateRoomStatusQuery = "UPDATE Room SET Room_Status = 'Occupied' WHERE Room_No = @RoomNum";
                        using (SqlCommand updateCommand = new SqlCommand(updateRoomStatusQuery, connection))
                        {
                            updateCommand.Parameters.AddWithValue("@RoomNum", roomNumber);

                            connection.Open();
                            int updateRowsAffected = updateCommand.ExecuteNonQuery();
                            connection.Close();

                            if (updateRowsAffected > 0)
                            {
                               // MessageBox.Show("Reservation added successfully.");

                                // Calculate total amount
                                decimal totalAmount = CalculateTotalAmount(guestid, roomNumber, checkInDate, checkOutDate);

                                // Update transactions table
                                int reservationId = GetReservationId();
                                string guestName = GetGuestName(guestid);
                                string paymentStatus = "Paid"; // Assuming initial payment status is false

                                string insertTransactionQuery = "INSERT INTO transactions (Reservation_ID, Guest_ID, Guest_Name, Total_Amount, Payment_Status) VALUES (@ReservationID, @GuestID, @GuestName, @TotalAmount, @PaymentStatus)";
                                using (SqlCommand insertTransactionCommand = new SqlCommand(insertTransactionQuery, connection))
                                {
                                    insertTransactionCommand.Parameters.AddWithValue("@ReservationID", reservationId);
                                    insertTransactionCommand.Parameters.AddWithValue("@GuestID", guestid);
                                    insertTransactionCommand.Parameters.AddWithValue("@GuestName", guestName);
                                    insertTransactionCommand.Parameters.AddWithValue("@TotalAmount", totalAmount);
                                    insertTransactionCommand.Parameters.AddWithValue("@PaymentStatus", paymentStatus);

                                    connection.Open();
                                    int insertRowsAffected = insertTransactionCommand.ExecuteNonQuery();
                                    connection.Close();

                                    if (insertRowsAffected > 0)
                                    {
                                        CalculateAndPrintReceipt(guestid, roomNumber, roomType, checkInDate, checkOutDate);
                                    }
                                    else
                                    {
                                        MessageBox.Show("Failed to insert transaction into the database.");
                                    }
                                }
                            }
                            else
                            {
                                MessageBox.Show("Failed to update room status.");
                            }
                        }
                    }
                    else
                    {
                        MessageBox.Show("Failed to add reservation.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                con.Close();
            }
        }

        private decimal CalculateTotalAmount(string guestid, string roomNumber, DateTime checkInDate, DateTime checkOutDate)
        {
            decimal roomPrice = GetRoomPrice(roomNumber);
            int numberOfDays = (int)(checkOutDate - checkInDate).TotalDays;
          //  numberOfDays++;
           // numberOfDays = Math.Max(numberOfDays, 1);
            decimal sum = GetLastAppendedSumFromFile();
            decimal totalAmount = roomPrice * numberOfDays + 2500 + sum;

            // Retrieve the membership type based on the guest ID
            string membershipType = GetMembershipType(guestid);

            // Apply discount based on the membership type
            decimal discountPercentage = 0;
            if (membershipType == "Basic")
            {
                discountPercentage = 0.3m; // 30% discount for Basic membership
            }
            else if (membershipType == "Standard")
            {
                discountPercentage = 0.4m; // 40% discount for Standard membership
            }
            else if (membershipType == "Premium")
            {
                discountPercentage = 0.6m; // 60% discount for Premium membership
            }

            decimal discountedAmount = totalAmount * (1 - discountPercentage);

            return discountedAmount;

        }

        private int RetrieveRoomId(string roomNumber)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection("Data Source=DESKTOP-KFDUOB5\\MSSQLSERVER2022;Initial Catalog=HotelManagementSystem;Integrated Security=True;Encrypt=True;TrustServerCertificate=True"))
                {
                    string query = "SELECT Room_ID FROM Room WHERE Room_No = @RoomNumber";

                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@RoomNumber", roomNumber);

                    connection.Open();

                    object result = command.ExecuteScalar();

                    if (result != null && result != DBNull.Value)
                    {
                        return (int)result;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }

            return -1;
        }

        public void populate()
        {
         //   SqlConnection con = new SqlConnection("Data Source=DESKTOP-KFDUOB5\\MSSQLSERVER2022;Initial Catalog=HotelManagementSystem;Integrated Security=True;Encrypt=True;");
            con.Open();
            string query = "select * from ResView";
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.ExecuteNonQuery();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            SqlCommandBuilder cb = new SqlCommandBuilder(da);
            var ds = new DataSet();
            da.Fill(ds);
            R_datagrid.DataSource = ds.Tables[0];
            con.Close();

        }

        private void Res_searchbtn_Click(object sender, EventArgs e)
        {

            search();
        }
        private void Res_idsearch_KeyPress(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                e.Handled = true; // Prevent the Enter key from processing further
                search();
            }
        }

        private  static decimal GetLastAppendedSumFromFile()
        {
            try
            {
                // Generate a unique filename with a timestamp
                string fileName = $"TotalFacilitiesSum_{DateTime.Now:yyyyMMdd}.txt";

                // Combine the desktop path with the generated filename
                string desktopPath = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
                string filePath = Path.Combine(desktopPath, fileName);

                // Check if the file exists
                if (File.Exists(filePath))
                {
                    // Read all lines from the file
                    string[] lines = File.ReadAllLines(filePath);

                    // If there are lines, parse the last one as a decimal
                    if (lines.Length > 0 && decimal.TryParse(lines.Last(), out decimal lastSum))
                    {
                        // Clear the file after reading its content
                      //  File.WriteAllText(filePath, string.Empty);
                        return lastSum;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error reading Total Facilities Sum from file: {ex.Message}");
            }

            return 0; // Default value if there's an error or the file doesn't exist
        }




        public void search()
        {

            try
            {
                SqlConnection con = new SqlConnection("Data Source=DESKTOP-KFDUOB5\\MSSQLSERVER2022;Initial Catalog=HotelManagementSystem;Integrated Security=True;Encrypt=True;TrustServerCertificate=True")
                {

                };
                string searchTerm = Res_idsearch.Text.Trim();
                con.Open();
                SqlDataAdapter adapter = new SqlDataAdapter();
                SqlCommand command;

                if (int.TryParse(searchTerm, out int Reservation_ID))
                {
                    command = new SqlCommand("EXEC SearchByID @ID", con);
                    command.Parameters.AddWithValue("@ID", searchTerm);
                }
                else
                {
                    command = new SqlCommand("EXEC SearchByGuestNameee @name", con);
                    command.Parameters.AddWithValue("@name", searchTerm);
                }
                DataTable dataTable = new DataTable();
                adapter.SelectCommand = command;

                adapter.Fill(dataTable);
                R_datagrid.DataSource = dataTable;
                if (dataTable.Rows.Count == 0)
                {
                    MessageBox.Show("Reservation  not found.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                if (dataTable.Rows.Count > 0)
                {
                    R_datagrid.DataSource = dataTable;
                }
                else
                {
                    MessageBox.Show("Reservatin ID not found in the database.");
                }
                con.Close();
            }
            catch (FormatException)
            {
                MessageBox.Show("Invalid Reservation ID. Please enter a valid integer value.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
            finally
            {
                con.Close();
            }

        }

        private void clearbtn_Click(object sender, EventArgs e)
        {
            populate();
        }

        private void Rtypecombo_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selectedRoomType = Rtypecombo.SelectedItem.ToString();

            // Retrieve vacant room numbers for the selected room type
            string query = "SELECT Room_No FROM Room WHERE Room_Type=@Room_Type and Room_Status='Vacant'";
            SqlCommand command = new SqlCommand(query, con);
            command.Parameters.AddWithValue("@Room_Type", selectedRoomType);
            SqlDataAdapter da = new SqlDataAdapter(command);
            SqlCommandBuilder cb = new SqlCommandBuilder(da);
            da = new SqlDataAdapter(command);
            var ds = new DataSet();
            //dataSet = new DataSet();
            da.Fill(ds);

            // Clear the RoomNumber ComboBox and load the retrieved room numbers
            R_nocombo.Items.Clear();
            foreach (DataRow row in ds.Tables[0].Rows)
            {
                R_nocombo.Items.Add(row["Room_No"]);
            }
        }

        private void updateGbtn_Click(object sender, EventArgs e)
        {

            int resid = int.Parse(txtReservationID.Text);
            string roomType = Typecombo.SelectedItem?.ToString(); // Using ?. to handle null
            string roomNum = Nocombo.SelectedItem?.ToString();
            DateTime checkOutDate = OutdateTime.Value;

            using (SqlConnection connection = new SqlConnection("Data Source=DESKTOP-KFDUOB5\\MSSQLSERVER2022;Initial Catalog=HotelManagementSystem;Integrated Security=True;Encrypt=True;TrustServerCertificate=True"))
            {
                try
                {
                    connection.Open();

                    // Retrieve the original room number from the Reservation table
                    string originalRoomQuery = "SELECT Room_No FROM Reservations WHERE Reservation_ID = @ReservationID";
                    using (SqlCommand originalRoomCommand = new SqlCommand(originalRoomQuery, connection))
                    {
                        originalRoomCommand.Parameters.AddWithValue("@ReservationID", resid);
                        object originalRoomResult = originalRoomCommand.ExecuteScalar();

                        if (originalRoomResult != null && originalRoomResult != DBNull.Value)
                        {
                            string originalRoomNum = originalRoomResult.ToString();

                            // Update the reservation details
                            using (SqlCommand command = new SqlCommand("UpdateReservation", connection))
                            {
                                command.CommandType = CommandType.StoredProcedure;
                                command.Parameters.AddWithValue("@ReservationID", resid);
                                command.Parameters.AddWithValue("@Room_Type", roomType);
                                command.Parameters.AddWithValue("@Room_No", roomNum);
                                command.Parameters.AddWithValue("@CheckOutDate", checkOutDate);
                                command.ExecuteNonQuery();

                                // Update the room status in the Room table
                                string updateRoomStatusQuery = "UPDATE Room SET Room_Status = " +
                                                               "CASE " +
                                                               "    WHEN Room_No = @NewRoom_No THEN 'Occupied' " +
                                                               "    ELSE 'Vacant' " +
                                                               "END " +
                                                               "WHERE Room_No IN (@NewRoom_No, @OldRoom_No)";
                                using (SqlCommand updateRoomStatusCommand = new SqlCommand(updateRoomStatusQuery, connection))
                                {
                                    updateRoomStatusCommand.Parameters.AddWithValue("@NewRoom_No", roomNum);
                                    updateRoomStatusCommand.Parameters.AddWithValue("@OldRoom_No", originalRoomNum);
                                    updateRoomStatusCommand.ExecuteNonQuery();
                                }

                                MessageBox.Show("Reservation updated successfully!");
                            }
                        }
                        else
                        {
                            MessageBox.Show("Original room number not found for the reservation.");
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
                finally
                {
                    connection.Close();
                }
            }


        }


        private void Typecombo_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selectedRoomType = Typecombo.SelectedItem.ToString();

            // Retrieve vacant room numbers for the selected room type
            string query = "SELECT Room_No FROM Room WHERE Room_Type=@Room_Type and Room_Status='Vacant'";
            SqlCommand command = new SqlCommand(query, con);
            command.Parameters.AddWithValue("@Room_Type", selectedRoomType);
            SqlDataAdapter da = new SqlDataAdapter(command);
            SqlCommandBuilder cb = new SqlCommandBuilder(da);
            da = new SqlDataAdapter(command);
            var ds = new DataSet();
            //dataSet = new DataSet();
            da.Fill(ds);

            // Clear the RoomNumber ComboBox and load the retrieved room numbers
            Nocombo.Items.Clear();
            foreach (DataRow row in ds.Tables[0].Rows)
            {
                Nocombo.Items.Add(row["Room_No"]);
            }
        }

        private void Guestcombo_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void G_combo_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void R_datagrid_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && e.ColumnIndex >= 0)
            {
                DataGridViewCell cell = R_datagrid.Rows[e.RowIndex].Cells[e.ColumnIndex];

                if (cell.Value != null)
                {
                    // Assuming the columns in the DataGridView are in the following order:
                    int reservationID = (int)R_datagrid.Rows[e.RowIndex].Cells[0].Value;
                    // int guestID = (int)R_datagrid.Rows[e.RowIndex].Cells[1].Value;
                    // int roomID = (int)R_datagrid.Rows[e.RowIndex].Cells[2].Value;
                    string roomType = R_datagrid.Rows[e.RowIndex].Cells[3].Value.ToString();
                    int roomNumber = (int)R_datagrid.Rows[e.RowIndex].Cells[4].Value;
                    // DateTime checkInDate = (DateTime)R_datagrid.Rows[e.RowIndex].Cells[5].Value;
                    DateTime checkOutDate = (DateTime)R_datagrid.Rows[e.RowIndex].Cells[6].Value;

                    // Populate the text boxes with the data
                    txtReservationID.Text = reservationID.ToString();
                    //  txtGuestID.Text = guestID.ToString();
                    //  txtRoomID.Text = roomID.ToString();
                    Typecombo.SelectedItem = roomType;
                    Nocombo.SelectedItem = roomNumber.ToString();
                    //  dtpCheckInDate.Value = checkInDate;
                    OutdateTime.Value = checkOutDate;
                }
            }
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            //HOME h = new HOME();
            //this.Hide();
            //h.Show();
        }

        private void G_combo_TextChanged(object sender, EventArgs e)
        {
        }
        private bool CheckGuestExists(int guestId)
        {
            using (SqlConnection connection = new SqlConnection("Data Source=DESKTOP-KFDUOB5\\MSSQLSERVER2022;Initial Catalog=HotelManagementSystem;Integrated Security=True;Encrypt=True;TrustServerCertificate=True"))
            {
                connection.Open();

                SqlCommand checkGuestCommand = new SqlCommand("SELECT COUNT(*) FROM Guests WHERE Guest_ID = @GuestID", connection);
                checkGuestCommand.Parameters.AddWithValue("@GuestID", guestId);

                int guestExists = (int)checkGuestCommand.ExecuteScalar();

                connection.Close();

                return guestExists > 0;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Facilities f = new Facilities();
            f.Show();
        }
      
        decimal summ1=GetLastAppendedSumFromFile();

        private void CalculateAndPrintReceipt(string guestid, string roomNumber, string roomType, DateTime checkInDate, DateTime checkOutDate)
        {
            decimal roomPrice = GetRoomPrice(roomNumber);
            int numberOfDays = (int)((checkOutDate - checkInDate).TotalDays);
            numberOfDays = numberOfDays + 1;
            //int numberOfDays = (int)Math.Ceiling((checkOutDate - checkInDate).TotalDays);
            decimal summ = summ1;
            totalRoomPrice = roomPrice * numberOfDays;
            decimal totalPayment = totalRoomPrice + summ + 2500;

            // Retrieve the membership type based on the guest ID
            string membershipType = GetMembershipType(guestid);

            // Calculate the discounted amount based on the membership type
            decimal discountPercentage = 0;
            if (membershipType == "Basic")
            {
                discountPercentage = 0.3m; // 30% discount for Basic membership
            }
            else if (membershipType == "Standard")
            {
                discountPercentage = 0.4m; // 40% discount for Standard membership
            }
            else if (membershipType == "Premium")
            {
                discountPercentage = 0.6m; // 60% discount for Premium membership
            }

            decimal discountedAmount = totalPayment * (1 - discountPercentage);

            string guestName = GetGuestName(guestid);
            int reservationId = GetReservationId();
            string filePath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Desktop), "Receipt.txt");


            string receipt = GenerateReceiptAndSaveToFile(reservationId, guestName, checkInDate, checkOutDate, numberOfDays, roomPrice, summ, totalPayment, discountedAmount, membershipType, filePath); ;

            PrintReceipt(receipt);
        }

        private decimal GetRoomPrice(string roomNumber)
        {

            decimal roomPrice = 0;

            // Replace with your actual query to retrieve the room price based on the room number
            string roomPriceQuery = "SELECT Charges FROM Room WHERE Room_No = @RoomNo";

            using (SqlConnection connection = new SqlConnection("Data Source=DESKTOP-KFDUOB5\\MSSQLSERVER2022;Initial Catalog=HotelManagementSystem;Integrated Security=True;Encrypt=True;TrustServerCertificate=True"))
            using (SqlCommand command = new SqlCommand(roomPriceQuery, connection))
            {
                command.Parameters.AddWithValue("@RoomNo", roomNumber);

                connection.Open();
                object result = command.ExecuteScalar();
                if (result != null && decimal.TryParse(result.ToString(), out decimal parsedPrice))
                {
                    roomPrice = parsedPrice;
                }
                connection.Close();
            }

            return roomPrice;



        }

        private string GetGuestName(string guestid)
        {
            string guestName = string.Empty;

            // Replace with your actual query to retrieve the guest name based on the guest ID
            string guestNameQuery = "SELECT First_Name FROM Guests WHERE Guest_ID = @GuestID";

            using (SqlConnection connection = new SqlConnection("Data Source=DESKTOP-KFDUOB5\\MSSQLSERVER2022;Initial Catalog=HotelManagementSystem;Integrated Security=True;Encrypt=True;TrustServerCertificate=True"))
            using (SqlCommand command = new SqlCommand(guestNameQuery, connection))
            {
                command.Parameters.AddWithValue("@GuestID", guestid);

                connection.Open();
                object result = command.ExecuteScalar();
                if (result != null)
                {
                    guestName = result.ToString();
                }
                connection.Close();
            }

            return guestName;
        }

        private int GetReservationId()
        {
            int reservationId = 0;

            // Replace with your actual query to retrieve the maximum reservation ID
            string reservationIdQuery = "SELECT MAX(Reservation_ID) FROM Reservations";

            using (SqlConnection connection = new SqlConnection("Data Source=DESKTOP-KFDUOB5\\MSSQLSERVER2022;Initial Catalog=HotelManagementSystem;Integrated Security=True;Encrypt=True;TrustServerCertificate=True"))
            using (SqlCommand command = new SqlCommand(reservationIdQuery, connection))
            {
                connection.Open();
                object result = command.ExecuteScalar();
                if (result != null && !string.IsNullOrEmpty(result.ToString()))
                {
                    reservationId = (int)result;
                }
                connection.Close();
            }

            return reservationId;
        }


        private string GenerateReceiptAndSaveToFile(int reservationId, string guestName, DateTime checkInDate, DateTime checkOutDate, int numberOfDays, decimal roomPrice, decimal facilitiesAmount, decimal totalPayment, decimal discountedAmount, string membershipType, string filePath)
        {
            decimal sum = summ1;
            string membershipTypeText = string.IsNullOrEmpty(membershipType) ? "None" : membershipType;

            string receipt = string.Format(
                "-----------------------------------------" + Environment.NewLine +
                "            Grand Hotel       " + Environment.NewLine +
                "        Where Luxury Meets Unforgettable Moments" + Environment.NewLine +
                "-----------------------------------------" + Environment.NewLine +
                "Reservation ID: {0}" + Environment.NewLine +
                "Guest Name: {1}" + Environment.NewLine +
                "Membership Type: {2}" + Environment.NewLine +
                "Check-in Date: {3}" + Environment.NewLine +
                "Check-out Date: {4}" + Environment.NewLine +
                "Number of Days: {5}" + Environment.NewLine +
                "-----------------------------------------" + Environment.NewLine +
                "Room Price per Day: {6:C}" + Environment.NewLine +
                "Facilities Amount: {7:C}" + Environment.NewLine +
                "Service Charge: {8:C}" + Environment.NewLine +
                "-----------------------------------------" + Environment.NewLine +
                "Total Payment: {9:C}" + Environment.NewLine +
                "Discount: {10:C}" + Environment.NewLine +
                "-----------------------------------------" + Environment.NewLine +
                "Amount to Pay: {11:C}" + Environment.NewLine +
                "-----------------------------------------" + Environment.NewLine +
                "Date: {12}" + Environment.NewLine +
                "Time: {13}" + Environment.NewLine +
                "-----------------------------------------" + Environment.NewLine +
                "Thank you for choosing Grand Hotel." + Environment.NewLine +
                "We look forward to serving you again!",
                reservationId,
                guestName,
                membershipTypeText,
                checkInDate.ToShortDateString(),
                checkOutDate.ToShortDateString(),
                numberOfDays,
                roomPrice,
                sum,
                2500.0m,
                totalPayment,
                totalPayment - discountedAmount,
                discountedAmount,
                DateTime.Now.ToShortDateString(),
                DateTime.Now.ToShortTimeString());

            // Save the receipt data to the specified file path
            File.WriteAllText(filePath, receipt);

            return receipt;
        }



        private string GetMembershipType(string guestId)
        {
            // Code to retrieve the membership type based on the guest ID
            // You need to replace this with your actual implementation
            // Here's an example assuming you have a database table called "Memberships" with a column "MembershipType" and you retrieve it using a query or ORM:

            string membershipType = string.Empty;

            // Replace the following code with your actual implementation
            using (var connection = new SqlConnection("Data Source=DESKTOP-KFDUOB5\\MSSQLSERVER2022;Initial Catalog=HotelManagementSystem;Integrated Security=True;Encrypt=True;TrustServerCertificate=True"))
            {
                connection.Open();

                string query = "SELECT Membership_Type FROM Memberships WHERE Guest_Id = @GuestId";
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@GuestId", guestId);

                membershipType = (string)command.ExecuteScalar();
            }

            return membershipType;
        }


        private void PrintReceipt(string receipt)
        {
            Receipt receiptForm = new Receipt(receipt);
            receiptForm.ShowDialog();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            con.Open();
            string query = "select * from ReservationAudit";
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.ExecuteNonQuery();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            SqlCommandBuilder cb = new SqlCommandBuilder(da);
            var ds = new DataSet();
            da.Fill(ds);
            dataGridView1.DataSource = ds.Tables[0];
            con.Close();
        }

        private void txtReservationID_TextChanged(object sender, EventArgs e)
        {


        }

        private void tabPage2_Click(object sender, EventArgs e)
        {

        }
    }
}

﻿
namespace DBMS_HMS
{
    partial class Admin_Room
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            tabPage3 = new TabPage();
            panel7 = new Panel();
            panel5 = new Panel();
            panel4 = new Panel();
            panel3 = new Panel();
            panel1 = new Panel();
            panel2 = new Panel();
            iconPictureBox14 = new FontAwesome.Sharp.IconPictureBox();
            label5 = new Label();
            iconPictureBox11 = new FontAwesome.Sharp.IconPictureBox();
            label14 = new Label();
            iconPictureBox12 = new FontAwesome.Sharp.IconPictureBox();
            label16 = new Label();
            iconPictureBox13 = new FontAwesome.Sharp.IconPictureBox();
            label17 = new Label();
            iconPictureBox10 = new FontAwesome.Sharp.IconPictureBox();
            label6 = new Label();
            iconPictureBox9 = new FontAwesome.Sharp.IconPictureBox();
            label12 = new Label();
            iconPictureBox7 = new FontAwesome.Sharp.IconPictureBox();
            label11 = new Label();
            Status = new TextBox();
            IDtxt = new TextBox();
            roomtxt = new TextBox();
            updatebtn = new Button();
            delbtn = new Button();
            prtxt = new TextBox();
            limtxt = new TextBox();
            comboBox = new ComboBox();
            button1 = new Button();
            tabControl1 = new TabControl();
            tabPage1 = new TabPage();
            panel10 = new Panel();
            panel9 = new Panel();
            panel8 = new Panel();
            iconPictureBox8 = new FontAwesome.Sharp.IconPictureBox();
            label7 = new Label();
            iconPictureBox4 = new FontAwesome.Sharp.IconPictureBox();
            label4 = new Label();
            iconPictureBox2 = new FontAwesome.Sharp.IconPictureBox();
            label1 = new Label();
            iconPictureBox3 = new FontAwesome.Sharp.IconPictureBox();
            label3 = new Label();
            iconPictureBox1 = new FontAwesome.Sharp.IconPictureBox();
            label2 = new Label();
            RoomNotxt = new TextBox();
            Pricetxt = new TextBox();
            Limittxt = new TextBox();
            RoomTypecomboBox = new ComboBox();
            tabPage2 = new TabPage();
            panel6 = new Panel();
            panel11 = new Panel();
            iconPictureBox15 = new FontAwesome.Sharp.IconPictureBox();
            iconPictureBox6 = new FontAwesome.Sharp.IconPictureBox();
            label8 = new Label();
            iconPictureBox5 = new FontAwesome.Sharp.IconPictureBox();
            label13 = new Label();
            button3 = new Button();
            searchtxt = new TextBox();
            dataGridView1 = new DataGridView();
            Column1 = new DataGridViewTextBoxColumn();
            Column2 = new DataGridViewTextBoxColumn();
            Column3 = new DataGridViewTextBoxColumn();
            Column4 = new DataGridViewTextBoxColumn();
            Charges = new DataGridViewTextBoxColumn();
            Column5 = new DataGridViewTextBoxColumn();
            tabPage3.SuspendLayout();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox14).BeginInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox11).BeginInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox12).BeginInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox13).BeginInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox10).BeginInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox9).BeginInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox7).BeginInit();
            tabControl1.SuspendLayout();
            tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox8).BeginInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox1).BeginInit();
            tabPage2.SuspendLayout();
            panel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox15).BeginInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox6).BeginInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox5).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // tabPage3
            // 
            tabPage3.BackColor = Color.FromArgb(51, 51, 76);
            tabPage3.Controls.Add(panel7);
            tabPage3.Controls.Add(panel5);
            tabPage3.Controls.Add(panel4);
            tabPage3.Controls.Add(panel3);
            tabPage3.Controls.Add(panel1);
            tabPage3.Controls.Add(iconPictureBox14);
            tabPage3.Controls.Add(label5);
            tabPage3.Controls.Add(iconPictureBox11);
            tabPage3.Controls.Add(label14);
            tabPage3.Controls.Add(iconPictureBox12);
            tabPage3.Controls.Add(label16);
            tabPage3.Controls.Add(iconPictureBox13);
            tabPage3.Controls.Add(label17);
            tabPage3.Controls.Add(iconPictureBox10);
            tabPage3.Controls.Add(label6);
            tabPage3.Controls.Add(iconPictureBox9);
            tabPage3.Controls.Add(label12);
            tabPage3.Controls.Add(iconPictureBox7);
            tabPage3.Controls.Add(label11);
            tabPage3.Controls.Add(Status);
            tabPage3.Controls.Add(IDtxt);
            tabPage3.Controls.Add(roomtxt);
            tabPage3.Controls.Add(updatebtn);
            tabPage3.Controls.Add(delbtn);
            tabPage3.Controls.Add(prtxt);
            tabPage3.Controls.Add(limtxt);
            tabPage3.Controls.Add(comboBox);
            tabPage3.Location = new Point(4, 4);
            tabPage3.Margin = new Padding(2);
            tabPage3.Name = "tabPage3";
            tabPage3.Size = new Size(872, 392);
            tabPage3.TabIndex = 2;
            tabPage3.Text = "Update & Delete";
            tabPage3.Click += tabPage3_Click;
            // 
            // panel7
            // 
            panel7.BackColor = Color.Gray;
            panel7.Location = new Point(606, 225);
            panel7.Name = "panel7";
            panel7.Size = new Size(234, 1);
            panel7.TabIndex = 114;
            // 
            // panel5
            // 
            panel5.BackColor = Color.Gray;
            panel5.Location = new Point(606, 158);
            panel5.Name = "panel5";
            panel5.Size = new Size(243, 1);
            panel5.TabIndex = 113;
            // 
            // panel4
            // 
            panel4.BackColor = Color.Gray;
            panel4.Location = new Point(160, 157);
            panel4.Name = "panel4";
            panel4.Size = new Size(232, 1);
            panel4.TabIndex = 64;
            // 
            // panel3
            // 
            panel3.BackColor = Color.Gray;
            panel3.Location = new Point(160, 229);
            panel3.Name = "panel3";
            panel3.Size = new Size(234, 1);
            panel3.TabIndex = 112;
            // 
            // panel1
            // 
            panel1.BackColor = Color.Gray;
            panel1.Controls.Add(panel2);
            panel1.Location = new Point(160, 96);
            panel1.Name = "panel1";
            panel1.Size = new Size(234, 1);
            panel1.TabIndex = 111;
            // 
            // panel2
            // 
            panel2.BackColor = Color.Gray;
            panel2.Location = new Point(0, 0);
            panel2.Name = "panel2";
            panel2.Size = new Size(263, 1);
            panel2.TabIndex = 64;
            // 
            // iconPictureBox14
            // 
            iconPictureBox14.BackColor = Color.FromArgb(51, 51, 76);
            iconPictureBox14.ForeColor = SystemColors.AppWorkspace;
            iconPictureBox14.IconChar = FontAwesome.Sharp.IconChar.BedPulse;
            iconPictureBox14.IconColor = SystemColors.AppWorkspace;
            iconPictureBox14.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconPictureBox14.Location = new Point(15, 200);
            iconPictureBox14.Name = "iconPictureBox14";
            iconPictureBox14.Size = new Size(32, 32);
            iconPictureBox14.TabIndex = 110;
            iconPictureBox14.TabStop = false;
            // 
            // label5
            // 
            label5.Font = new Font("Sitka Banner", 14.2499981F, FontStyle.Bold);
            label5.ForeColor = SystemColors.AppWorkspace;
            label5.Location = new Point(44, 200);
            label5.Name = "label5";
            label5.Size = new Size(110, 41);
            label5.TabIndex = 109;
            label5.Text = "Room Status";
            // 
            // iconPictureBox11
            // 
            iconPictureBox11.BackColor = Color.FromArgb(51, 51, 76);
            iconPictureBox11.ForeColor = SystemColors.AppWorkspace;
            iconPictureBox11.IconChar = FontAwesome.Sharp.IconChar.MoneyBillWaveAlt;
            iconPictureBox11.IconColor = SystemColors.AppWorkspace;
            iconPictureBox11.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconPictureBox11.Location = new Point(16, 129);
            iconPictureBox11.Name = "iconPictureBox11";
            iconPictureBox11.Size = new Size(32, 32);
            iconPictureBox11.TabIndex = 108;
            iconPictureBox11.TabStop = false;
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Font = new Font("Sitka Banner", 14.2499981F, FontStyle.Bold);
            label14.ForeColor = SystemColors.AppWorkspace;
            label14.Location = new Point(45, 131);
            label14.Margin = new Padding(4, 0, 4, 0);
            label14.Name = "label14";
            label14.Size = new Size(74, 28);
            label14.TabIndex = 107;
            label14.Text = "Charges";
            // 
            // iconPictureBox12
            // 
            iconPictureBox12.BackColor = Color.FromArgb(51, 51, 76);
            iconPictureBox12.ForeColor = SystemColors.AppWorkspace;
            iconPictureBox12.IconChar = FontAwesome.Sharp.IconChar.Bed;
            iconPictureBox12.IconColor = SystemColors.AppWorkspace;
            iconPictureBox12.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconPictureBox12.IconSize = 28;
            iconPictureBox12.Location = new Point(432, 202);
            iconPictureBox12.Name = "iconPictureBox12";
            iconPictureBox12.Size = new Size(28, 32);
            iconPictureBox12.TabIndex = 106;
            iconPictureBox12.TabStop = false;
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.Font = new Font("Sitka Banner", 14.2499981F, FontStyle.Bold);
            label16.ForeColor = SystemColors.AppWorkspace;
            label16.Location = new Point(457, 202);
            label16.Margin = new Padding(4, 0, 4, 0);
            label16.Name = "label16";
            label16.Size = new Size(141, 28);
            label16.TabIndex = 105;
            label16.Text = "Occupancy Limit";
            // 
            // iconPictureBox13
            // 
            iconPictureBox13.BackColor = Color.FromArgb(51, 51, 76);
            iconPictureBox13.ForeColor = SystemColors.AppWorkspace;
            iconPictureBox13.IconChar = FontAwesome.Sharp.IconChar.Bed;
            iconPictureBox13.IconColor = SystemColors.AppWorkspace;
            iconPictureBox13.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconPictureBox13.IconSize = 28;
            iconPictureBox13.Location = new Point(432, 126);
            iconPictureBox13.Name = "iconPictureBox13";
            iconPictureBox13.Size = new Size(28, 32);
            iconPictureBox13.TabIndex = 104;
            iconPictureBox13.TabStop = false;
            // 
            // label17
            // 
            label17.AutoSize = true;
            label17.Font = new Font("Sitka Banner", 14.2499981F, FontStyle.Bold);
            label17.ForeColor = SystemColors.AppWorkspace;
            label17.Location = new Point(467, 131);
            label17.Margin = new Padding(4, 0, 4, 0);
            label17.Name = "label17";
            label17.Size = new Size(98, 28);
            label17.TabIndex = 103;
            label17.Text = "Room Type";
            // 
            // iconPictureBox10
            // 
            iconPictureBox10.BackColor = Color.FromArgb(51, 51, 76);
            iconPictureBox10.ForeColor = SystemColors.AppWorkspace;
            iconPictureBox10.IconChar = FontAwesome.Sharp.IconChar.BedPulse;
            iconPictureBox10.IconColor = SystemColors.AppWorkspace;
            iconPictureBox10.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconPictureBox10.IconSize = 28;
            iconPictureBox10.Location = new Point(432, 72);
            iconPictureBox10.Name = "iconPictureBox10";
            iconPictureBox10.Size = new Size(28, 32);
            iconPictureBox10.TabIndex = 102;
            iconPictureBox10.TabStop = false;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Sitka Banner", 14.2499981F, FontStyle.Bold);
            label6.ForeColor = SystemColors.AppWorkspace;
            label6.Location = new Point(467, 72);
            label6.Margin = new Padding(4, 0, 4, 0);
            label6.Name = "label6";
            label6.Size = new Size(82, 28);
            label6.TabIndex = 101;
            label6.Text = "Room No";
            label6.Click += label6_Click;
            // 
            // iconPictureBox9
            // 
            iconPictureBox9.BackColor = Color.FromArgb(51, 51, 76);
            iconPictureBox9.ForeColor = SystemColors.AppWorkspace;
            iconPictureBox9.IconChar = FontAwesome.Sharp.IconChar.BedPulse;
            iconPictureBox9.IconColor = SystemColors.AppWorkspace;
            iconPictureBox9.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconPictureBox9.Location = new Point(16, 66);
            iconPictureBox9.Name = "iconPictureBox9";
            iconPictureBox9.Size = new Size(32, 32);
            iconPictureBox9.TabIndex = 100;
            iconPictureBox9.TabStop = false;
            // 
            // label12
            // 
            label12.Font = new Font("Sitka Banner", 14.2499981F, FontStyle.Bold);
            label12.ForeColor = SystemColors.AppWorkspace;
            label12.Location = new Point(44, 65);
            label12.Name = "label12";
            label12.Size = new Size(85, 32);
            label12.TabIndex = 99;
            label12.Text = "Room ID";
            // 
            // iconPictureBox7
            // 
            iconPictureBox7.BackColor = Color.FromArgb(51, 51, 76);
            iconPictureBox7.ForeColor = SystemColors.AppWorkspace;
            iconPictureBox7.IconChar = FontAwesome.Sharp.IconChar.BoxOpen;
            iconPictureBox7.IconColor = SystemColors.AppWorkspace;
            iconPictureBox7.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconPictureBox7.IconSize = 39;
            iconPictureBox7.Location = new Point(9, 14);
            iconPictureBox7.Name = "iconPictureBox7";
            iconPictureBox7.Size = new Size(39, 46);
            iconPictureBox7.TabIndex = 55;
            iconPictureBox7.TabStop = false;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new Font("Sitka Banner", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label11.ForeColor = Color.FromArgb(204, 204, 204);
            label11.Location = new Point(45, 14);
            label11.Name = "label11";
            label11.Size = new Size(218, 35);
            label11.TabIndex = 54;
            label11.Text = "Update/Delete Room";
            // 
            // Status
            // 
            Status.BackColor = Color.FromArgb(51, 51, 76);
            Status.BorderStyle = BorderStyle.None;
            Status.Font = new Font("Sitka Banner", 14.2499981F, FontStyle.Bold);
            Status.ForeColor = SystemColors.AppWorkspace;
            Status.Location = new Point(160, 202);
            Status.Margin = new Padding(3, 4, 3, 4);
            Status.Name = "Status";
            Status.Size = new Size(234, 24);
            Status.TabIndex = 51;
            // 
            // IDtxt
            // 
            IDtxt.BackColor = Color.FromArgb(51, 51, 76);
            IDtxt.BorderStyle = BorderStyle.None;
            IDtxt.Font = new Font("Sitka Banner", 14.2499981F, FontStyle.Bold);
            IDtxt.ForeColor = SystemColors.AppWorkspace;
            IDtxt.Location = new Point(160, 69);
            IDtxt.Margin = new Padding(3, 4, 3, 4);
            IDtxt.Name = "IDtxt";
            IDtxt.Size = new Size(234, 24);
            IDtxt.TabIndex = 49;
            // 
            // roomtxt
            // 
            roomtxt.BackColor = Color.FromArgb(51, 51, 76);
            roomtxt.BorderStyle = BorderStyle.None;
            roomtxt.Font = new Font("Sitka Banner", 14.2499981F, FontStyle.Bold);
            roomtxt.ForeColor = SystemColors.AppWorkspace;
            roomtxt.Location = new Point(606, 131);
            roomtxt.Margin = new Padding(3, 4, 3, 4);
            roomtxt.Name = "roomtxt";
            roomtxt.Size = new Size(244, 24);
            roomtxt.TabIndex = 47;
            // 
            // updatebtn
            // 
            updatebtn.BackColor = Color.FromArgb(51, 51, 76);
            updatebtn.FlatStyle = FlatStyle.Flat;
            updatebtn.Font = new Font("Sitka Banner", 14.2499981F, FontStyle.Bold);
            updatebtn.ForeColor = SystemColors.AppWorkspace;
            updatebtn.Location = new Point(605, 303);
            updatebtn.Margin = new Padding(3, 4, 3, 4);
            updatebtn.Name = "updatebtn";
            updatebtn.Size = new Size(244, 43);
            updatebtn.TabIndex = 46;
            updatebtn.Text = "Update Room";
            updatebtn.UseVisualStyleBackColor = false;
            updatebtn.Click += updatebtn_Click;
            // 
            // delbtn
            // 
            delbtn.BackColor = Color.FromArgb(51, 51, 76);
            delbtn.FlatStyle = FlatStyle.Flat;
            delbtn.Font = new Font("Sitka Banner", 14.2499981F, FontStyle.Bold);
            delbtn.ForeColor = SystemColors.AppWorkspace;
            delbtn.Location = new Point(316, 303);
            delbtn.Margin = new Padding(3, 4, 3, 4);
            delbtn.Name = "delbtn";
            delbtn.Size = new Size(249, 43);
            delbtn.TabIndex = 45;
            delbtn.Text = "Delete Room";
            delbtn.UseVisualStyleBackColor = false;
            delbtn.Click += delbtn_Click;
            // 
            // prtxt
            // 
            prtxt.BackColor = Color.FromArgb(51, 51, 76);
            prtxt.BorderStyle = BorderStyle.None;
            prtxt.Font = new Font("Sitka Banner", 14.2499981F, FontStyle.Bold);
            prtxt.ForeColor = SystemColors.AppWorkspace;
            prtxt.Location = new Point(160, 131);
            prtxt.Margin = new Padding(3, 4, 3, 4);
            prtxt.Name = "prtxt";
            prtxt.Size = new Size(234, 24);
            prtxt.TabIndex = 44;
            prtxt.TextChanged += prtxt_TextChanged;
            // 
            // limtxt
            // 
            limtxt.BackColor = Color.FromArgb(51, 51, 76);
            limtxt.BorderStyle = BorderStyle.None;
            limtxt.Font = new Font("Sitka Banner", 14.2499981F, FontStyle.Bold);
            limtxt.ForeColor = SystemColors.AppWorkspace;
            limtxt.Location = new Point(605, 198);
            limtxt.Margin = new Padding(3, 4, 3, 4);
            limtxt.Name = "limtxt";
            limtxt.Size = new Size(244, 24);
            limtxt.TabIndex = 43;
            // 
            // comboBox
            // 
            comboBox.BackColor = Color.FromArgb(51, 51, 76);
            comboBox.FlatStyle = FlatStyle.Flat;
            comboBox.Font = new Font("Sitka Banner", 14.2499981F, FontStyle.Bold);
            comboBox.ForeColor = SystemColors.AppWorkspace;
            comboBox.FormattingEnabled = true;
            comboBox.Items.AddRange(new object[] { "Single", "Double ", "Family ", "Suite" });
            comboBox.Location = new Point(605, 68);
            comboBox.Margin = new Padding(2);
            comboBox.Name = "comboBox";
            comboBox.Size = new Size(244, 36);
            comboBox.TabIndex = 41;
            // 
            // button1
            // 
            button1.BackColor = Color.FromArgb(51, 51, 76);
            button1.FlatStyle = FlatStyle.Flat;
            button1.Font = new Font("Sitka Banner", 14.2499981F, FontStyle.Bold);
            button1.ForeColor = SystemColors.AppWorkspace;
            button1.Location = new Point(523, 323);
            button1.Margin = new Padding(3, 4, 3, 4);
            button1.Name = "button1";
            button1.Size = new Size(331, 47);
            button1.TabIndex = 35;
            button1.Text = "Add Room";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // tabControl1
            // 
            tabControl1.Alignment = TabAlignment.Bottom;
            tabControl1.Controls.Add(tabPage1);
            tabControl1.Controls.Add(tabPage2);
            tabControl1.Controls.Add(tabPage3);
            tabControl1.Dock = DockStyle.Fill;
            tabControl1.Location = new Point(0, 0);
            tabControl1.Margin = new Padding(2);
            tabControl1.Name = "tabControl1";
            tabControl1.SelectedIndex = 0;
            tabControl1.Size = new Size(880, 420);
            tabControl1.TabIndex = 27;
            // 
            // tabPage1
            // 
            tabPage1.BackColor = Color.FromArgb(51, 51, 76);
            tabPage1.Controls.Add(panel10);
            tabPage1.Controls.Add(panel9);
            tabPage1.Controls.Add(panel8);
            tabPage1.Controls.Add(iconPictureBox8);
            tabPage1.Controls.Add(label7);
            tabPage1.Controls.Add(iconPictureBox4);
            tabPage1.Controls.Add(label4);
            tabPage1.Controls.Add(iconPictureBox2);
            tabPage1.Controls.Add(label1);
            tabPage1.Controls.Add(iconPictureBox3);
            tabPage1.Controls.Add(label3);
            tabPage1.Controls.Add(iconPictureBox1);
            tabPage1.Controls.Add(label2);
            tabPage1.Controls.Add(RoomNotxt);
            tabPage1.Controls.Add(button1);
            tabPage1.Controls.Add(Pricetxt);
            tabPage1.Controls.Add(Limittxt);
            tabPage1.Controls.Add(RoomTypecomboBox);
            tabPage1.Location = new Point(4, 4);
            tabPage1.Margin = new Padding(2);
            tabPage1.Name = "tabPage1";
            tabPage1.Padding = new Padding(2);
            tabPage1.Size = new Size(872, 392);
            tabPage1.TabIndex = 0;
            tabPage1.Text = "Add Room";
            // 
            // panel10
            // 
            panel10.BackColor = SystemColors.AppWorkspace;
            panel10.Location = new Point(235, 286);
            panel10.Name = "panel10";
            panel10.Size = new Size(372, 1);
            panel10.TabIndex = 88;
            // 
            // panel9
            // 
            panel9.BackColor = SystemColors.AppWorkspace;
            panel9.Location = new Point(236, 227);
            panel9.Name = "panel9";
            panel9.Size = new Size(372, 1);
            panel9.TabIndex = 87;
            // 
            // panel8
            // 
            panel8.BackColor = SystemColors.AppWorkspace;
            panel8.Location = new Point(235, 114);
            panel8.Name = "panel8";
            panel8.Size = new Size(372, 1);
            panel8.TabIndex = 86;
            // 
            // iconPictureBox8
            // 
            iconPictureBox8.BackColor = Color.FromArgb(51, 51, 76);
            iconPictureBox8.ForeColor = SystemColors.AppWorkspace;
            iconPictureBox8.IconChar = FontAwesome.Sharp.IconChar.MoneyBillWaveAlt;
            iconPictureBox8.IconColor = SystemColors.AppWorkspace;
            iconPictureBox8.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconPictureBox8.Location = new Point(37, 247);
            iconPictureBox8.Name = "iconPictureBox8";
            iconPictureBox8.Size = new Size(32, 32);
            iconPictureBox8.TabIndex = 85;
            iconPictureBox8.TabStop = false;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Sitka Banner", 14.2499981F, FontStyle.Bold);
            label7.ForeColor = SystemColors.AppWorkspace;
            label7.Location = new Point(72, 249);
            label7.Margin = new Padding(4, 0, 4, 0);
            label7.Name = "label7";
            label7.Size = new Size(74, 28);
            label7.TabIndex = 84;
            label7.Text = "Charges";
            // 
            // iconPictureBox4
            // 
            iconPictureBox4.BackColor = Color.FromArgb(51, 51, 76);
            iconPictureBox4.ForeColor = SystemColors.AppWorkspace;
            iconPictureBox4.IconChar = FontAwesome.Sharp.IconChar.Bed;
            iconPictureBox4.IconColor = SystemColors.AppWorkspace;
            iconPictureBox4.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconPictureBox4.IconSize = 28;
            iconPictureBox4.Location = new Point(38, 196);
            iconPictureBox4.Name = "iconPictureBox4";
            iconPictureBox4.Size = new Size(28, 32);
            iconPictureBox4.TabIndex = 75;
            iconPictureBox4.TabStop = false;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Sitka Banner", 14.2499981F, FontStyle.Bold);
            label4.ForeColor = SystemColors.AppWorkspace;
            label4.Location = new Point(63, 196);
            label4.Margin = new Padding(4, 0, 4, 0);
            label4.Name = "label4";
            label4.Size = new Size(141, 28);
            label4.TabIndex = 74;
            label4.Text = "Occupancy Limit";
            // 
            // iconPictureBox2
            // 
            iconPictureBox2.BackColor = Color.FromArgb(51, 51, 76);
            iconPictureBox2.ForeColor = SystemColors.AppWorkspace;
            iconPictureBox2.IconChar = FontAwesome.Sharp.IconChar.Bed;
            iconPictureBox2.IconColor = SystemColors.AppWorkspace;
            iconPictureBox2.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconPictureBox2.IconSize = 28;
            iconPictureBox2.Location = new Point(38, 143);
            iconPictureBox2.Name = "iconPictureBox2";
            iconPictureBox2.Size = new Size(28, 32);
            iconPictureBox2.TabIndex = 73;
            iconPictureBox2.TabStop = false;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Sitka Banner", 14.2499981F, FontStyle.Bold);
            label1.ForeColor = SystemColors.AppWorkspace;
            label1.Location = new Point(63, 143);
            label1.Margin = new Padding(4, 0, 4, 0);
            label1.Name = "label1";
            label1.Size = new Size(98, 28);
            label1.TabIndex = 72;
            label1.Text = "Room Type";
            // 
            // iconPictureBox3
            // 
            iconPictureBox3.BackColor = Color.FromArgb(51, 51, 76);
            iconPictureBox3.ForeColor = SystemColors.AppWorkspace;
            iconPictureBox3.IconChar = FontAwesome.Sharp.IconChar.BedPulse;
            iconPictureBox3.IconColor = SystemColors.AppWorkspace;
            iconPictureBox3.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconPictureBox3.IconSize = 28;
            iconPictureBox3.Location = new Point(38, 87);
            iconPictureBox3.Name = "iconPictureBox3";
            iconPictureBox3.Size = new Size(28, 32);
            iconPictureBox3.TabIndex = 71;
            iconPictureBox3.TabStop = false;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Sitka Banner", 14.2499981F, FontStyle.Bold);
            label3.ForeColor = SystemColors.AppWorkspace;
            label3.Location = new Point(63, 87);
            label3.Margin = new Padding(4, 0, 4, 0);
            label3.Name = "label3";
            label3.Size = new Size(82, 28);
            label3.TabIndex = 70;
            label3.Text = "Room No";
            // 
            // iconPictureBox1
            // 
            iconPictureBox1.BackColor = Color.FromArgb(51, 51, 76);
            iconPictureBox1.ForeColor = SystemColors.AppWorkspace;
            iconPictureBox1.IconChar = FontAwesome.Sharp.IconChar.BoxOpen;
            iconPictureBox1.IconColor = SystemColors.AppWorkspace;
            iconPictureBox1.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconPictureBox1.IconSize = 39;
            iconPictureBox1.Location = new Point(10, 5);
            iconPictureBox1.Name = "iconPictureBox1";
            iconPictureBox1.Size = new Size(39, 46);
            iconPictureBox1.TabIndex = 53;
            iconPictureBox1.TabStop = false;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Sitka Banner", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.ForeColor = Color.FromArgb(204, 204, 204);
            label2.Location = new Point(46, 5);
            label2.Name = "label2";
            label2.Size = new Size(115, 35);
            label2.TabIndex = 52;
            label2.Text = "Add Room";
            // 
            // RoomNotxt
            // 
            RoomNotxt.BackColor = Color.FromArgb(51, 51, 76);
            RoomNotxt.BorderStyle = BorderStyle.None;
            RoomNotxt.Font = new Font("Sitka Banner", 14.2499981F, FontStyle.Bold);
            RoomNotxt.ForeColor = SystemColors.AppWorkspace;
            RoomNotxt.Location = new Point(235, 87);
            RoomNotxt.Margin = new Padding(3, 4, 3, 4);
            RoomNotxt.Name = "RoomNotxt";
            RoomNotxt.Size = new Size(373, 24);
            RoomNotxt.TabIndex = 44;
            // 
            // Pricetxt
            // 
            Pricetxt.BackColor = Color.FromArgb(51, 51, 76);
            Pricetxt.BorderStyle = BorderStyle.None;
            Pricetxt.Font = new Font("Sitka Banner", 14.2499981F, FontStyle.Bold);
            Pricetxt.ForeColor = SystemColors.AppWorkspace;
            Pricetxt.Location = new Point(235, 259);
            Pricetxt.Margin = new Padding(3, 4, 3, 4);
            Pricetxt.Name = "Pricetxt";
            Pricetxt.Size = new Size(373, 24);
            Pricetxt.TabIndex = 34;
            // 
            // Limittxt
            // 
            Limittxt.BackColor = Color.FromArgb(51, 51, 76);
            Limittxt.BorderStyle = BorderStyle.None;
            Limittxt.Font = new Font("Sitka Banner", 14.2499981F, FontStyle.Bold);
            Limittxt.ForeColor = SystemColors.AppWorkspace;
            Limittxt.Location = new Point(235, 202);
            Limittxt.Margin = new Padding(3, 4, 3, 4);
            Limittxt.Name = "Limittxt";
            Limittxt.Size = new Size(373, 24);
            Limittxt.TabIndex = 33;
            // 
            // RoomTypecomboBox
            // 
            RoomTypecomboBox.BackColor = Color.FromArgb(51, 51, 76);
            RoomTypecomboBox.Font = new Font("Sitka Banner", 11.2499981F, FontStyle.Bold);
            RoomTypecomboBox.ForeColor = SystemColors.AppWorkspace;
            RoomTypecomboBox.FormattingEnabled = true;
            RoomTypecomboBox.Items.AddRange(new object[] { "Single", "Double ", "Family ", "Suite" });
            RoomTypecomboBox.Location = new Point(234, 150);
            RoomTypecomboBox.Margin = new Padding(2);
            RoomTypecomboBox.Name = "RoomTypecomboBox";
            RoomTypecomboBox.Size = new Size(373, 29);
            RoomTypecomboBox.TabIndex = 31;
            RoomTypecomboBox.SelectedIndexChanged += RoomTypecomboBox_SelectedIndexChanged;
            // 
            // tabPage2
            // 
            tabPage2.BackColor = Color.FromArgb(51, 51, 76);
            tabPage2.Controls.Add(panel6);
            tabPage2.Controls.Add(iconPictureBox15);
            tabPage2.Controls.Add(iconPictureBox6);
            tabPage2.Controls.Add(label8);
            tabPage2.Controls.Add(iconPictureBox5);
            tabPage2.Controls.Add(label13);
            tabPage2.Controls.Add(button3);
            tabPage2.Controls.Add(searchtxt);
            tabPage2.Controls.Add(dataGridView1);
            tabPage2.Location = new Point(4, 4);
            tabPage2.Margin = new Padding(2);
            tabPage2.Name = "tabPage2";
            tabPage2.Padding = new Padding(2);
            tabPage2.Size = new Size(872, 392);
            tabPage2.TabIndex = 1;
            tabPage2.Text = "Search Room";
            // 
            // panel6
            // 
            panel6.BackColor = Color.Gray;
            panel6.Controls.Add(panel11);
            panel6.Location = new Point(166, 70);
            panel6.Name = "panel6";
            panel6.Size = new Size(305, 1);
            panel6.TabIndex = 112;
            // 
            // panel11
            // 
            panel11.BackColor = Color.Gray;
            panel11.Location = new Point(0, 0);
            panel11.Name = "panel11";
            panel11.Size = new Size(263, 1);
            panel11.TabIndex = 64;
            // 
            // iconPictureBox15
            // 
            iconPictureBox15.BackColor = Color.FromArgb(51, 51, 76);
            iconPictureBox15.ForeColor = SystemColors.AppWorkspace;
            iconPictureBox15.IconChar = FontAwesome.Sharp.IconChar.Search;
            iconPictureBox15.IconColor = SystemColors.AppWorkspace;
            iconPictureBox15.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconPictureBox15.Location = new Point(471, 39);
            iconPictureBox15.Name = "iconPictureBox15";
            iconPictureBox15.Size = new Size(32, 32);
            iconPictureBox15.TabIndex = 111;
            iconPictureBox15.TabStop = false;
            iconPictureBox15.Click += iconPictureBox15_Click;
            // 
            // iconPictureBox6
            // 
            iconPictureBox6.BackColor = Color.FromArgb(51, 51, 76);
            iconPictureBox6.ForeColor = SystemColors.AppWorkspace;
            iconPictureBox6.IconChar = FontAwesome.Sharp.IconChar.BoxOpen;
            iconPictureBox6.IconColor = SystemColors.AppWorkspace;
            iconPictureBox6.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconPictureBox6.IconSize = 36;
            iconPictureBox6.Location = new Point(5, 2);
            iconPictureBox6.Name = "iconPictureBox6";
            iconPictureBox6.Size = new Size(39, 36);
            iconPictureBox6.TabIndex = 100;
            iconPictureBox6.TabStop = false;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Sitka Banner", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label8.ForeColor = Color.FromArgb(204, 204, 204);
            label8.Location = new Point(41, 2);
            label8.Name = "label8";
            label8.Size = new Size(144, 35);
            label8.TabIndex = 99;
            label8.Text = "Search Room";
            // 
            // iconPictureBox5
            // 
            iconPictureBox5.BackColor = Color.FromArgb(51, 51, 76);
            iconPictureBox5.ForeColor = SystemColors.AppWorkspace;
            iconPictureBox5.IconChar = FontAwesome.Sharp.IconChar.BedPulse;
            iconPictureBox5.IconColor = SystemColors.AppWorkspace;
            iconPictureBox5.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconPictureBox5.Location = new Point(30, 44);
            iconPictureBox5.Name = "iconPictureBox5";
            iconPictureBox5.Size = new Size(32, 32);
            iconPictureBox5.TabIndex = 98;
            iconPictureBox5.TabStop = false;
            // 
            // label13
            // 
            label13.Font = new Font("Sitka Banner", 14.2499981F, FontStyle.Bold);
            label13.ForeColor = SystemColors.AppWorkspace;
            label13.Location = new Point(58, 43);
            label13.Name = "label13";
            label13.Size = new Size(85, 32);
            label13.TabIndex = 97;
            label13.Text = "Room ID";
            // 
            // button3
            // 
            button3.BackColor = Color.FromArgb(51, 51, 76);
            button3.FlatStyle = FlatStyle.Flat;
            button3.Font = new Font("Sitka Banner", 14.2499981F, FontStyle.Bold);
            button3.ForeColor = SystemColors.AppWorkspace;
            button3.Location = new Point(622, 34);
            button3.Margin = new Padding(3, 4, 3, 4);
            button3.Name = "button3";
            button3.Size = new Size(242, 37);
            button3.TabIndex = 50;
            button3.Text = "DIisplay RoomInfo";
            button3.UseVisualStyleBackColor = false;
            button3.Click += button3_Click;
            // 
            // searchtxt
            // 
            searchtxt.BackColor = Color.FromArgb(51, 51, 76);
            searchtxt.BorderStyle = BorderStyle.None;
            searchtxt.Font = new Font("Sitka Banner", 14.2499981F, FontStyle.Bold);
            searchtxt.ForeColor = SystemColors.AppWorkspace;
            searchtxt.Location = new Point(166, 41);
            searchtxt.Margin = new Padding(3, 4, 3, 4);
            searchtxt.Name = "searchtxt";
            searchtxt.Size = new Size(313, 24);
            searchtxt.TabIndex = 32;
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Columns.AddRange(new DataGridViewColumn[] { Column1, Column2, Column3, Column4, Charges, Column5 });
            dataGridView1.Dock = DockStyle.Bottom;
            dataGridView1.Location = new Point(2, 150);
            dataGridView1.Margin = new Padding(2);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 62;
            dataGridView1.RowTemplate.Height = 33;
            dataGridView1.Size = new Size(868, 240);
            dataGridView1.TabIndex = 30;
            // 
            // Column1
            // 
            Column1.DataPropertyName = "Room_ID";
            Column1.HeaderText = "ID";
            Column1.MinimumWidth = 8;
            Column1.Name = "Column1";
            Column1.Width = 150;
            // 
            // Column2
            // 
            Column2.DataPropertyName = "Room_No";
            Column2.HeaderText = "Room Number";
            Column2.MinimumWidth = 8;
            Column2.Name = "Column2";
            Column2.Width = 150;
            // 
            // Column3
            // 
            Column3.DataPropertyName = "Room_Type";
            Column3.HeaderText = "Type";
            Column3.MinimumWidth = 8;
            Column3.Name = "Column3";
            Column3.Width = 150;
            // 
            // Column4
            // 
            Column4.DataPropertyName = "Occupancy_Limit";
            Column4.HeaderText = "Limit";
            Column4.MinimumWidth = 8;
            Column4.Name = "Column4";
            Column4.Width = 150;
            // 
            // Charges
            // 
            Charges.DataPropertyName = "Charges";
            Charges.HeaderText = "Charges";
            Charges.MinimumWidth = 8;
            Charges.Name = "Charges";
            Charges.Width = 150;
            // 
            // Column5
            // 
            Column5.DataPropertyName = "Room_Status";
            Column5.HeaderText = "Status";
            Column5.MinimumWidth = 8;
            Column5.Name = "Column5";
            Column5.Width = 150;
            // 
            // Admin_Room
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(51, 51, 76);
            ClientSize = new Size(880, 420);
            Controls.Add(tabControl1);
            FormBorderStyle = FormBorderStyle.None;
            Margin = new Padding(3, 4, 3, 4);
            Name = "Admin_Room";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Admin_Room";
            Load += Admin_Room_Load;
            tabPage3.ResumeLayout(false);
            tabPage3.PerformLayout();
            panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)iconPictureBox14).EndInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox11).EndInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox12).EndInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox13).EndInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox10).EndInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox9).EndInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox7).EndInit();
            tabControl1.ResumeLayout(false);
            tabPage1.ResumeLayout(false);
            tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox8).EndInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox4).EndInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox3).EndInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox1).EndInit();
            tabPage2.ResumeLayout(false);
            tabPage2.PerformLayout();
            panel6.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)iconPictureBox15).EndInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox6).EndInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox5).EndInit();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
        }

        #endregion
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TextBox IDtxt;
        private System.Windows.Forms.TextBox roomtxt;
        private System.Windows.Forms.Button updatebtn;
        private System.Windows.Forms.Button delbtn;
        private System.Windows.Forms.TextBox prtxt;
        private System.Windows.Forms.TextBox limtxt;
        private System.Windows.Forms.ComboBox comboBox;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TextBox RoomNotxt;
        private System.Windows.Forms.TextBox Pricetxt;
        private System.Windows.Forms.TextBox Limittxt;
        private System.Windows.Forms.ComboBox RoomTypecomboBox;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TextBox searchtxt;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Charges;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column5;
        private System.Windows.Forms.TextBox Status;
        private System.Windows.Forms.Button button3;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox1;
        private Label label2;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox3;
        private Label label3;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox2;
        private Label label1;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox4;
        private Label label4;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox8;
        private Label label7;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox9;
        private Label label12;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox7;
        private Label label11;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox6;
        private Label label8;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox5;
        private Label label13;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox11;
        private Label label14;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox12;
        private Label label16;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox13;
        private Label label17;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox10;
        private Label label6;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox14;
        private Label label5;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox15;
        private Panel panel6;
        private Panel panel11;
        private Panel panel5;
        private Panel panel4;
        private Panel panel3;
        private Panel panel1;
        private Panel panel2;
        private Panel panel7;
        private Panel panel10;
        private Panel panel9;
        private Panel panel8;
    }
}
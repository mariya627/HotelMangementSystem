﻿
namespace DBMS_HMS
{
    partial class LOGIN
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label3 = new Label();
            Passwordtxt = new TextBox();
            UserNametxt = new TextBox();
            label1 = new Label();
            loginbtn = new Button();
            label = new Label();
            iconPictureBox1 = new FontAwesome.Sharp.IconPictureBox();
            iconPictureBox2 = new FontAwesome.Sharp.IconPictureBox();
            iconPictureBox3 = new FontAwesome.Sharp.IconPictureBox();
            panel1 = new Panel();
            panel2 = new Panel();
            button1 = new Button();
            iconPictureBox4 = new FontAwesome.Sharp.IconPictureBox();
            label2 = new Label();
            iconPictureBox5 = new FontAwesome.Sharp.IconPictureBox();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox5).BeginInit();
            SuspendLayout();
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Sitka Banner", 14.2499981F, FontStyle.Bold);
            label3.ForeColor = Color.FromArgb(204, 204, 204);
            label3.Location = new Point(56, 267);
            label3.Name = "label3";
            label3.Size = new Size(103, 28);
            label3.TabIndex = 48;
            label3.Text = "PASSWORD";
            // 
            // Passwordtxt
            // 
            Passwordtxt.BackColor = Color.FromArgb(39, 39, 58);
            Passwordtxt.BorderStyle = BorderStyle.None;
            Passwordtxt.Font = new Font("Sitka Banner", 14.2499981F, FontStyle.Bold);
            Passwordtxt.ForeColor = SystemColors.WindowFrame;
            Passwordtxt.Location = new Point(185, 267);
            Passwordtxt.MaxLength = 10;
            Passwordtxt.Name = "Passwordtxt";
            Passwordtxt.PasswordChar = '*';
            Passwordtxt.Size = new Size(232, 24);
            Passwordtxt.TabIndex = 47;
            Passwordtxt.Text = "Enter Password";
            Passwordtxt.TextChanged += Passwordtxt_TextChanged;
            // 
            // UserNametxt
            // 
            UserNametxt.BackColor = Color.FromArgb(39, 39, 58);
            UserNametxt.BorderStyle = BorderStyle.None;
            UserNametxt.Font = new Font("Sitka Banner", 14.2499981F, FontStyle.Bold);
            UserNametxt.ForeColor = SystemColors.WindowFrame;
            UserNametxt.Location = new Point(185, 195);
            UserNametxt.Name = "UserNametxt";
            UserNametxt.Size = new Size(232, 24);
            UserNametxt.TabIndex = 46;
            UserNametxt.Text = "Enter username";
            UserNametxt.TextChanged += pictureBox3_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Sitka Banner", 14.2499981F, FontStyle.Bold);
            label1.ForeColor = Color.FromArgb(204, 204, 204);
            label1.Location = new Point(53, 194);
            label1.Name = "label1";
            label1.Size = new Size(106, 28);
            label1.TabIndex = 45;
            label1.Text = "USERNAME";
            label1.Click += label1_Click;
            // 
            // loginbtn
            // 
            loginbtn.BackColor = Color.FromArgb(39, 39, 58);
            loginbtn.FlatStyle = FlatStyle.Flat;
            loginbtn.Font = new Font("Perpetua Titling MT", 15.75F, FontStyle.Bold);
            loginbtn.ForeColor = Color.FromArgb(204, 204, 204);
            loginbtn.Location = new Point(28, 417);
            loginbtn.Name = "loginbtn";
            loginbtn.Size = new Size(389, 40);
            loginbtn.TabIndex = 44;
            loginbtn.Text = "Login";
            loginbtn.UseVisualStyleBackColor = false;
            loginbtn.Click += loginbtn_Click;
            // 
            // label
            // 
            label.AutoSize = true;
            label.Font = new Font("Microsoft Sans Serif", 10F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label.ForeColor = Color.FromArgb(192, 0, 0);
            label.Location = new Point(188, 303);
            label.Name = "label";
            label.Size = new Size(229, 17);
            label.TabIndex = 56;
            label.Text = "Wrong UserName or Password";
            label.Visible = false;
            // 
            // iconPictureBox1
            // 
            iconPictureBox1.BackColor = Color.FromArgb(39, 39, 58);
            iconPictureBox1.ForeColor = SystemColors.AppWorkspace;
            iconPictureBox1.IconChar = FontAwesome.Sharp.IconChar.UserLarge;
            iconPictureBox1.IconColor = SystemColors.AppWorkspace;
            iconPictureBox1.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconPictureBox1.IconSize = 117;
            iconPictureBox1.Location = new Point(164, 57);
            iconPictureBox1.Name = "iconPictureBox1";
            iconPictureBox1.Size = new Size(118, 117);
            iconPictureBox1.TabIndex = 57;
            iconPictureBox1.TabStop = false;
            // 
            // iconPictureBox2
            // 
            iconPictureBox2.BackColor = Color.FromArgb(39, 39, 58);
            iconPictureBox2.ForeColor = SystemColors.AppWorkspace;
            iconPictureBox2.IconChar = FontAwesome.Sharp.IconChar.UserEdit;
            iconPictureBox2.IconColor = SystemColors.AppWorkspace;
            iconPictureBox2.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconPictureBox2.Location = new Point(28, 194);
            iconPictureBox2.Name = "iconPictureBox2";
            iconPictureBox2.Size = new Size(32, 32);
            iconPictureBox2.TabIndex = 58;
            iconPictureBox2.TabStop = false;
            // 
            // iconPictureBox3
            // 
            iconPictureBox3.BackColor = Color.FromArgb(39, 39, 58);
            iconPictureBox3.ForeColor = SystemColors.AppWorkspace;
            iconPictureBox3.IconChar = FontAwesome.Sharp.IconChar.Lock;
            iconPictureBox3.IconColor = SystemColors.AppWorkspace;
            iconPictureBox3.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconPictureBox3.Location = new Point(28, 267);
            iconPictureBox3.Name = "iconPictureBox3";
            iconPictureBox3.Size = new Size(32, 32);
            iconPictureBox3.TabIndex = 59;
            iconPictureBox3.TabStop = false;
            // 
            // panel1
            // 
            panel1.BackColor = Color.Gray;
            panel1.Location = new Point(185, 221);
            panel1.Name = "panel1";
            panel1.Size = new Size(232, 1);
            panel1.TabIndex = 60;
            // 
            // panel2
            // 
            panel2.BackColor = Color.Gray;
            panel2.Location = new Point(185, 290);
            panel2.Name = "panel2";
            panel2.Size = new Size(232, 1);
            panel2.TabIndex = 61;
            // 
            // button1
            // 
            button1.BackColor = Color.FromArgb(39, 39, 58);
            button1.Dock = DockStyle.Bottom;
            button1.FlatAppearance.BorderSize = 0;
            button1.FlatStyle = FlatStyle.Flat;
            button1.Font = new Font("Sitka Banner", 14.2499981F, FontStyle.Bold);
            button1.ForeColor = SystemColors.AppWorkspace;
            button1.Location = new Point(0, 605);
            button1.Name = "button1";
            button1.Size = new Size(457, 37);
            button1.TabIndex = 62;
            button1.Text = "Login as Admin";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // iconPictureBox4
            // 
            iconPictureBox4.BackColor = Color.FromArgb(39, 39, 58);
            iconPictureBox4.ForeColor = SystemColors.AppWorkspace;
            iconPictureBox4.IconChar = FontAwesome.Sharp.IconChar.X;
            iconPictureBox4.IconColor = SystemColors.AppWorkspace;
            iconPictureBox4.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconPictureBox4.IconSize = 28;
            iconPictureBox4.Location = new Point(429, 2);
            iconPictureBox4.Name = "iconPictureBox4";
            iconPictureBox4.Size = new Size(28, 28);
            iconPictureBox4.TabIndex = 63;
            iconPictureBox4.TabStop = false;
            iconPictureBox4.Click += iconPictureBox4_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Sitka Banner", 14.2499981F, FontStyle.Bold);
            label2.ForeColor = SystemColors.AppWorkspace;
            label2.Location = new Point(117, 9);
            label2.Name = "label2";
            label2.Size = new Size(216, 28);
            label2.TabIndex = 64;
            label2.Text = "Hotel Management System";
            // 
            // iconPictureBox5
            // 
            iconPictureBox5.BackColor = Color.FromArgb(39, 39, 58);
            iconPictureBox5.ForeColor = SystemColors.AppWorkspace;
            iconPictureBox5.IconChar = FontAwesome.Sharp.IconChar.Hotel;
            iconPictureBox5.IconColor = SystemColors.AppWorkspace;
            iconPictureBox5.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconPictureBox5.Location = new Point(89, 9);
            iconPictureBox5.Name = "iconPictureBox5";
            iconPictureBox5.Size = new Size(32, 32);
            iconPictureBox5.TabIndex = 65;
            iconPictureBox5.TabStop = false;
            // 
            // LOGIN
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(39, 39, 58);
            ClientSize = new Size(457, 642);
            Controls.Add(iconPictureBox5);
            Controls.Add(label2);
            Controls.Add(iconPictureBox4);
            Controls.Add(button1);
            Controls.Add(panel2);
            Controls.Add(panel1);
            Controls.Add(iconPictureBox3);
            Controls.Add(iconPictureBox2);
            Controls.Add(iconPictureBox1);
            Controls.Add(label);
            Controls.Add(label3);
            Controls.Add(Passwordtxt);
            Controls.Add(UserNametxt);
            Controls.Add(label1);
            Controls.Add(loginbtn);
            FormBorderStyle = FormBorderStyle.None;
            Margin = new Padding(2);
            Name = "LOGIN";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Form1";
            Load += LOGIN_Load;
            ((System.ComponentModel.ISupportInitialize)iconPictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox3).EndInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox4).EndInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox5).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox Passwordtxt;
        private System.Windows.Forms.TextBox UserNametxt;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button loginbtn;
        private System.Windows.Forms.Label label;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox1;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox2;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox3;
        private Panel panel1;
        private Panel panel2;
        private Button button1;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox4;
        private Label label2;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox5;
    }
}


﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace hotalMS.forms
{
    public partial class Membership : Form
    {
        public Membership()
        {
            InitializeComponent();
        }
        SqlConnection con = new SqlConnection("Data Source=DESKTOP-KFDUOB5\\MSSQLSERVER2022;Initial Catalog=HotelManagementSystem;Integrated Security=True;Encrypt=True;TrustServerCertificate=True;");

        private void addmembtn_Click(object sender, EventArgs e)
        {
            if (FirstName.Text.Trim() == string.Empty || LastName.Text.Trim() == string.Empty || Cnic.Text.Trim() == string.Empty || Mtypecombo.Text == string.Empty)
            {
                MessageBox.Show("Please fill all fields.", "Require all fields", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            string firstName = FirstName.Text;
            string lastName = LastName.Text;
            string cnic = Cnic.Text;
            string duration = Durationtxt.Text;
            string status = "Active";

            // Create the connection string for your database
            string connectionString = "Data Source=DESKTOP-KFDUOB5\\MSSQLSERVER2022;Initial Catalog=HotelManagementSystem;Integrated Security=True;Encrypt=True;TrustServerCertificate=True;";

            // Create a SqlConnection and SqlCommand objects
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    // Open the connection
                    connection.Open();

                    // Check if the guest already has an active membership
                    string checkMembershipQuery = "SELECT Membership_Status FROM Guests WHERE CNIC = @CNIC";
                    using (SqlCommand checkMembershipCommand = new SqlCommand(checkMembershipQuery, connection))
                    {
                        checkMembershipCommand.Parameters.AddWithValue("@CNIC", cnic);
                        object existingMembershipStatus = checkMembershipCommand.ExecuteScalar();
                        if (existingMembershipStatus != null && existingMembershipStatus.ToString() == "Active")
                        {
                            MessageBox.Show("Error: The guest already has an active membership.");
                            return;
                        }
                    }

                    // Create a SqlCommand for adding a new membership
                    using (SqlCommand command = new SqlCommand("insertMembership1", connection))
                    {
                        DateTime endDate = startdate.Value; ;
                        if (Mtypecombo.SelectedItem != null)
                        {
                            string membershipType = Mtypecombo.SelectedItem.ToString();
                            DateTime startDate = startdate.Value;

                            //DateTime endDate;

                            switch (membershipType)
                            {
                                case "Basic":
                                    endDate = startDate.AddYears(3);
                                    break;
                                case "Standard":
                                    endDate = startDate.AddYears(5);
                                    break;
                                case "Premium":
                                    endDate = startDate.AddYears(10);
                                    break;
                                default:
                                    MessageBox.Show("Invalid membership type. Please select a valid membership type.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                    return;
                            }

                            //enddate.Value = endDate;
                        }
                        // Set the command type to Stored Procedure
                        command.CommandType = CommandType.StoredProcedure;

                        // Add the input parameters to the command
                        command.Parameters.AddWithValue("@First_Name", firstName);
                        command.Parameters.AddWithValue("@Last_Name", lastName);
                        command.Parameters.AddWithValue("@CNIC", cnic);
                        command.Parameters.AddWithValue("@Membership_Type", Mtypecombo.Text);
                        command.Parameters.AddWithValue("@Duration", duration);
                        command.Parameters.AddWithValue("@Price", pricetxt.Text);
                        command.Parameters.AddWithValue("@Start_Date", startdate.Value);
                        command.Parameters.AddWithValue("@End_Date", endDate);
                        command.Parameters.AddWithValue("@Status", status);

                        // Execute the command
                        command.ExecuteNonQuery();

                        // Update the Membership_Status of the guest in the Guests table
                        string updateGuestQuery = "UPDATE Guests SET Membership_Status = @Status WHERE CNIC = @CNIC";
                        using (SqlCommand updateGuestCommand = new SqlCommand(updateGuestQuery, connection))
                        {
                            updateGuestCommand.Parameters.AddWithValue("@Status", status);
                            updateGuestCommand.Parameters.AddWithValue("@CNIC", cnic);
                            updateGuestCommand.ExecuteNonQuery();
                        }

                        // Display a success message or redirect to another page
                        MessageBox.Show("Membership added successfully!");
                    }
                }
                catch (Exception ex)
                {
                    // Handle any exceptions that may occur
                    MessageBox.Show("Error: " + ex.Message);
                }
            }
        }

        private void searchbtn_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection("Data Source=DESKTOP-KFDUOB5\\MSSQLSERVER2022;Initial Catalog=HotelManagementSystem;Integrated Security=True;Encrypt=True;TrustServerCertificate=True;");

                string searchTerm = searchtxt.Text.Trim();
                con.Open();
                SqlDataAdapter adapter = new SqlDataAdapter();
                SqlCommand command;

                if (int.TryParse(searchTerm, out int Membership_ID))
                {
                    command = new SqlCommand("EXEC SearchByMembershipIDD @MembershipID", con);
                    command.Parameters.AddWithValue("@MembershipID", searchTerm);
                }
                else
                {
                    command = new SqlCommand("EXEC SearchMembershipByGuestNamee @Name", con);
                    command.Parameters.AddWithValue("@Name", searchTerm);
                }

                adapter.SelectCommand = command;
                DataTable dataTable = new DataTable();
                adapter.Fill(dataTable);
                salgrid.DataSource = dataTable;
                if (dataTable.Rows.Count == 0)
                {
                    MessageBox.Show("Membership not found.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                con.Close();
            }
            catch (FormatException)
            {
                MessageBox.Show("Invalid membership ID. Please enter a valid integer value.");
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
            finally
            {
                SqlConnection con = new SqlConnection("Data Source=DESKTOP-KFDUOB5\\MSSQLSERVER2022;Initial Catalog=HotelManagementSystem;Integrated Security=True;Encrypt=True;TrustServerCertificate=True;");

                con.Close();
            }
        }

        private void Disbtn_Click(object sender, EventArgs e)
        {
            Display();
        }

        public void Display()
        {
            SqlConnection con = new SqlConnection("Data Source=DESKTOP-KFDUOB5\\MSSQLSERVER2022;Initial Catalog=HotelManagementSystem;Integrated Security=True;Encrypt=True;TrustServerCertificate=True;");
            con.Open();
            SqlCommand cmd = new SqlCommand("select * from MembershipVeiw", con);
            cmd.ExecuteNonQuery();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            salgrid.DataSource = dt;
            con.Close();
        }

        private void updatebtn_Click(object sender, EventArgs e)
        {
            int membershipID;
            int guestID;
            string membershipType = MembershipTypeTextBox.Text;
            string price = PriceTextBox.Text;
            string duration = DurationTextBox.Text;
            DateTime startDate = StartdateTime.Value;
            //DateTime endDate = EnddateTime.Value;
            string status = "";

            // Validate and parse Membership ID
            if (int.TryParse(Midtxt.Text, out membershipID) == false)
            {
                MessageBox.Show("Invalid Membership ID.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Validate and parse Guest ID
            if (int.TryParse(GuestID.Text, out guestID) == false)
            {
                MessageBox.Show("Invalid Guest ID.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Validate text box inputs
            if (string.IsNullOrEmpty(membershipType) ||
                string.IsNullOrEmpty(price) ||
                string.IsNullOrEmpty(duration))
            {
                MessageBox.Show("Please fill in all the required fields.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Check radio button selection for status
            if (Active.Checked)
            {
                status = "Active";
            }
            else if (Inactive.Checked)
            {
                status = "Inactive";
            }
            else
            {
                MessageBox.Show("Please select a membership status.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }


            try
            {
                // Create a SqlConnection object and open the connection
                using (SqlConnection connection = new SqlConnection("Data Source=DESKTOP-KFDUOB5\\MSSQLSERVER2022;Initial Catalog=HotelManagementSystem;Integrated Security=True;Encrypt=True;TrustServerCertificate=True;"))
                {
                    connection.Open();

                    // Create a SqlCommand object with the stored procedure name and connection
                    using (SqlCommand command = new SqlCommand("UpdateMembership", connection))
                    {
                        DateTime EndDate = startdate.Value; ;
                        if (MembershipTypeTextBox.SelectedItem != null)
                        {
                            string MembershipType = MembershipTypeTextBox.SelectedItem.ToString();
                            DateTime StartDate = startdate.Value;



                            switch (MembershipType)
                            {
                                case "Basic":
                                    EndDate = StartDate.AddYears(3);
                                    break;
                                case "Standard":
                                    EndDate = StartDate.AddYears(5);
                                    break;
                                case "Premium":
                                    EndDate = StartDate.AddYears(10);
                                    break;
                                default:
                                    MessageBox.Show("Invalid membership type. Please select a valid membership type.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                    return;
                            }

                            //enddate.Value = endDate;
                        }
                        command.CommandType = CommandType.StoredProcedure;

                        // Add parameters to the command
                        command.Parameters.AddWithValue("@Membership_ID", membershipID);
                        command.Parameters.AddWithValue("@Guest_ID", guestID);
                        command.Parameters.AddWithValue("@Membership_Type", membershipType);
                        command.Parameters.AddWithValue("@Price", price);
                        command.Parameters.AddWithValue("@Duration", duration);
                        command.Parameters.AddWithValue("@Start_Date", startDate);
                        command.Parameters.AddWithValue("@End_Date", EndDate);
                        command.Parameters.AddWithValue("@Status", status);

                        // Execute the command and get the number of affected rows
                        int rowsAffected = command.ExecuteNonQuery();

                        if (rowsAffected == 0)
                        {
                            // Display a message box if the membership ID is not found
                            MessageBox.Show("Membership ID not found.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                        else
                        {
                            // Display a success message
                            MessageBox.Show("Membership updated successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                // Display an error message
                MessageBox.Show("An error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            GuestID.Clear();
            Midtxt.Clear();
            // Clear the items and selected value in the ComboBox
            MembershipTypeTextBox.Items.Clear();
            MembershipTypeTextBox.Text = string.Empty;
            PriceTextBox.Clear();
            DurationTextBox.Clear();
            StartdateTime.Value = DateTime.Now;
            //EnddateTime.Value = DateTime.Now;
            FName.Clear();
            LstName.Clear();
            Active.Checked = false;
            Inactive.Checked = false;
        }

        private void MembershipTypeTextBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            string type = MembershipTypeTextBox.SelectedItem.ToString();
            if (type == "Basic")
            {
                DurationTextBox.Text = "3 years";
                PriceTextBox.Text = "30,000";
            }
            else if (type == "Standard")
            {
                DurationTextBox.Text = "5 years";
                PriceTextBox.Text = "50,000";
            }
            else if (type == "Premium")
            {
                DurationTextBox.Text = "10 years";
                PriceTextBox.Text = "70,000";
            }
        }

        private void Mtypecombo_SelectedIndexChanged(object sender, EventArgs e)
        {
            string type = Mtypecombo.SelectedItem.ToString();
            if (type == "Basic")
            {
                Durationtxt.Text = "3 years";
                pricetxt.Text = "30,000";
            }
            else if (type == "Standard")
            {
                Durationtxt.Text = "5 years";
                pricetxt.Text = "50,000";
            }
            else if (type == "Premium")
            {
                Durationtxt.Text = "10 years";
                pricetxt.Text = "70,000";
            }
        }

        private void Midtxt_TextChanged(object sender, EventArgs e)
        {
            int membershipID;
            if (int.TryParse(Midtxt.Text, out membershipID))
            {
                try
                {
                    // Create a SqlConnection object and open the connection
                    using (SqlConnection connection = new SqlConnection("Data Source=DESKTOP-KFDUOB5\\MSSQLSERVER2022;Initial Catalog=HotelManagementSystem;Integrated Security=True;Encrypt=True;TrustServerCertificate=True;"))
                    {
                        connection.Open();

                        // Create a SqlCommand object with the query to retrieve the membership details
                        using (SqlCommand command = new SqlCommand("SELECT m.*, g.First_Name, g.Last_Name FROM Memberships m INNER JOIN Guests g ON m.Guest_ID = g.Guest_ID WHERE m.Membership_ID = @MembershipID", connection))
                        {
                            command.Parameters.AddWithValue("@MembershipID", membershipID);

                            // Execute the command and get the SqlDataReader
                            SqlDataReader reader = command.ExecuteReader();

                            if (reader.Read())
                            {
                                // Retrieve the values from the SqlDataReader
                                int guestID = Convert.ToInt32(reader["Guest_ID"]);
                                string membershipType = reader["Membership_Type"].ToString();
                                string price = reader["Price"].ToString();
                                string duration = reader["Duration"].ToString();
                                DateTime startDate = Convert.ToDateTime(reader["Start_Date"]);
                                DateTime endDate = Convert.ToDateTime(reader["End_Date"]);
                                string firstName = reader["First_Name"].ToString();
                                string lastName = reader["Last_Name"].ToString();
                                string status = reader["Status"].ToString();
                                // Set the retrieved values to the corresponding text boxes
                                GuestID.Text = guestID.ToString();
                                MembershipTypeTextBox.Text = membershipType;
                                PriceTextBox.Text = price;
                                DurationTextBox.Text = duration;
                                StartdateTime.Value = startDate;
                                //EnddateTime.Value = endDate;
                                FName.Text = firstName;
                                LstName.Text = lastName;
                                if (status == "Active")
                                {
                                    Active.Checked = true;
                                }
                                else if (status == "Inactive")
                                {
                                    Inactive.Checked = true;
                                }
                            }
                            else
                            {
                                // Display a message box if the Membership_ID is not found
                                MessageBox.Show("Membership ID not found.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }

                            reader.Close();
                        }
                    }
                }
                catch (Exception ex)
                {
                    // Display an error message
                    MessageBox.Show("An error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            else
            {
                // Clear the text boxes if the Membership_ID is not a valid integer
                GuestID.Clear();
                Midtxt.Clear();
                MembershipTypeTextBox.Items.Clear();
                MembershipTypeTextBox.Text = string.Empty;
                PriceTextBox.Clear();
                DurationTextBox.Clear();
                StartdateTime.Value = DateTime.Now;
                //EnddateTime.Value = DateTime.Now;
                FName.Clear();
                LstName.Clear();
                Active.Checked = false;
                Inactive.Checked = false;
            }


        }
        private bool ValidateCNIC(string cnic)
        {
            // Remove any spaces and hyphens from the CNIC number
            cnic = cnic.Replace(" ", "").Replace("-", "");

            // Use regular expression pattern to check for the specified format
            string pattern = @"^\d{5}[- ]?\d{7}[- ]?\d$";

            return Regex.IsMatch(cnic, pattern);
        }

        private void tabPage3_Click(object sender, EventArgs e)
        {

        }

        private void iconPictureBox19_Click(object sender, EventArgs e)
        {

        }
    }
}

﻿
namespace DBMS_HMS
{
    partial class ADMINLOGIN
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            button2 = new Button();
            Passwordtxt = new TextBox();
            label = new Label();
            iconPictureBox3 = new FontAwesome.Sharp.IconPictureBox();
            label1 = new Label();
            iconPictureBox1 = new FontAwesome.Sharp.IconPictureBox();
            panel1 = new Panel();
            iconPictureBox4 = new FontAwesome.Sharp.IconPictureBox();
            iconPictureBox2 = new FontAwesome.Sharp.IconPictureBox();
            iconPictureBox5 = new FontAwesome.Sharp.IconPictureBox();
            label2 = new Label();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox5).BeginInit();
            SuspendLayout();
            // 
            // button2
            // 
            button2.BackColor = Color.FromArgb(39, 39, 58);
            button2.FlatStyle = FlatStyle.Flat;
            button2.Font = new Font("Sitka Banner", 14.2499981F, FontStyle.Bold);
            button2.ForeColor = Color.Gainsboro;
            button2.Location = new Point(37, 413);
            button2.Margin = new Padding(4, 3, 4, 3);
            button2.Name = "button2";
            button2.Size = new Size(377, 44);
            button2.TabIndex = 63;
            button2.Text = "LOGIN";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // Passwordtxt
            // 
            Passwordtxt.BackColor = Color.FromArgb(39, 39, 58);
            Passwordtxt.BorderStyle = BorderStyle.None;
            Passwordtxt.Font = new Font("Sitka Banner", 14.2499981F, FontStyle.Bold);
            Passwordtxt.ForeColor = SystemColors.AppWorkspace;
            Passwordtxt.Location = new Point(185, 214);
            Passwordtxt.MaxLength = 10;
            Passwordtxt.Name = "Passwordtxt";
            Passwordtxt.PasswordChar = '*';
            Passwordtxt.Size = new Size(229, 24);
            Passwordtxt.TabIndex = 57;
            Passwordtxt.TextChanged += Passwordtxt_TextChanged;
            // 
            // label
            // 
            label.AutoSize = true;
            label.Font = new Font("Microsoft Sans Serif", 10F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label.ForeColor = Color.FromArgb(192, 0, 0);
            label.Location = new Point(273, 254);
            label.Name = "label";
            label.Size = new Size(128, 17);
            label.TabIndex = 67;
            label.Text = "wrong password!";
            label.Visible = false;
            // 
            // iconPictureBox3
            // 
            iconPictureBox3.BackColor = Color.FromArgb(39, 39, 58);
            iconPictureBox3.ForeColor = SystemColors.AppWorkspace;
            iconPictureBox3.IconChar = FontAwesome.Sharp.IconChar.Lock;
            iconPictureBox3.IconColor = SystemColors.AppWorkspace;
            iconPictureBox3.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconPictureBox3.Location = new Point(37, 210);
            iconPictureBox3.Name = "iconPictureBox3";
            iconPictureBox3.Size = new Size(32, 32);
            iconPictureBox3.TabIndex = 69;
            iconPictureBox3.TabStop = false;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Sitka Banner", 14.2499981F, FontStyle.Bold);
            label1.ForeColor = Color.FromArgb(204, 204, 204);
            label1.Location = new Point(66, 214);
            label1.Name = "label1";
            label1.Size = new Size(103, 28);
            label1.TabIndex = 68;
            label1.Text = "PASSWORD";
            // 
            // iconPictureBox1
            // 
            iconPictureBox1.BackColor = Color.FromArgb(39, 39, 58);
            iconPictureBox1.ForeColor = SystemColors.AppWorkspace;
            iconPictureBox1.IconChar = FontAwesome.Sharp.IconChar.UserLarge;
            iconPictureBox1.IconColor = SystemColors.AppWorkspace;
            iconPictureBox1.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconPictureBox1.IconSize = 117;
            iconPictureBox1.Location = new Point(161, 76);
            iconPictureBox1.Name = "iconPictureBox1";
            iconPictureBox1.Size = new Size(118, 117);
            iconPictureBox1.TabIndex = 70;
            iconPictureBox1.TabStop = false;
            // 
            // panel1
            // 
            panel1.BackColor = Color.Gray;
            panel1.Location = new Point(185, 240);
            panel1.Name = "panel1";
            panel1.Size = new Size(232, 1);
            panel1.TabIndex = 71;
            // 
            // iconPictureBox4
            // 
            iconPictureBox4.BackColor = Color.FromArgb(39, 39, 58);
            iconPictureBox4.ForeColor = SystemColors.AppWorkspace;
            iconPictureBox4.IconChar = FontAwesome.Sharp.IconChar.X;
            iconPictureBox4.IconColor = SystemColors.AppWorkspace;
            iconPictureBox4.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconPictureBox4.IconSize = 28;
            iconPictureBox4.Location = new Point(429, 1);
            iconPictureBox4.Name = "iconPictureBox4";
            iconPictureBox4.Size = new Size(28, 28);
            iconPictureBox4.TabIndex = 72;
            iconPictureBox4.TabStop = false;
            iconPictureBox4.Click += iconPictureBox4_Click;
            // 
            // iconPictureBox2
            // 
            iconPictureBox2.BackColor = Color.FromArgb(39, 39, 58);
            iconPictureBox2.ForeColor = SystemColors.AppWorkspace;
            iconPictureBox2.IconChar = FontAwesome.Sharp.IconChar.ArrowLeft;
            iconPictureBox2.IconColor = SystemColors.AppWorkspace;
            iconPictureBox2.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconPictureBox2.Location = new Point(0, 2);
            iconPictureBox2.Name = "iconPictureBox2";
            iconPictureBox2.Size = new Size(32, 32);
            iconPictureBox2.TabIndex = 73;
            iconPictureBox2.TabStop = false;
            iconPictureBox2.Click += iconPictureBox2_Click;
            // 
            // iconPictureBox5
            // 
            iconPictureBox5.BackColor = Color.FromArgb(39, 39, 58);
            iconPictureBox5.ForeColor = SystemColors.AppWorkspace;
            iconPictureBox5.IconChar = FontAwesome.Sharp.IconChar.Hotel;
            iconPictureBox5.IconColor = SystemColors.AppWorkspace;
            iconPictureBox5.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconPictureBox5.Location = new Point(105, 9);
            iconPictureBox5.Name = "iconPictureBox5";
            iconPictureBox5.Size = new Size(32, 32);
            iconPictureBox5.TabIndex = 75;
            iconPictureBox5.TabStop = false;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Sitka Banner", 14.2499981F, FontStyle.Bold);
            label2.ForeColor = SystemColors.AppWorkspace;
            label2.Location = new Point(133, 9);
            label2.Name = "label2";
            label2.Size = new Size(216, 28);
            label2.TabIndex = 74;
            label2.Text = "Hotel Management System";
            // 
            // ADMINLOGIN
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(39, 39, 58);
            ClientSize = new Size(457, 642);
            Controls.Add(iconPictureBox5);
            Controls.Add(label2);
            Controls.Add(iconPictureBox2);
            Controls.Add(iconPictureBox4);
            Controls.Add(panel1);
            Controls.Add(iconPictureBox1);
            Controls.Add(iconPictureBox3);
            Controls.Add(label1);
            Controls.Add(label);
            Controls.Add(button2);
            Controls.Add(Passwordtxt);
            FormBorderStyle = FormBorderStyle.None;
            Margin = new Padding(2);
            Name = "ADMINLOGIN";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "ADMINLOGIN";
            ((System.ComponentModel.ISupportInitialize)iconPictureBox3).EndInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox4).EndInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox5).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox Passwordtxt;
        private System.Windows.Forms.Label label;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox3;
        private Label label1;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox1;
        private Panel panel1;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox4;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox2;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox5;
        private Label label2;
    }
}
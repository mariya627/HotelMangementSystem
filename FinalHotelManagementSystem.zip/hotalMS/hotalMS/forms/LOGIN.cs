﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using hotalMS;

namespace DBMS_HMS
{

    public partial class LOGIN : Form
    {
        private string defaultText = " Enter Username";
        private string defaultText1 = "Enter Password";
        private Button currentButton;
        private Random random;
        private int tempIndex;
        private Form activeForm;
        private Button previousButton;
        private PictureBox previousBtn;
        private Color originalIconBoxColor;

        public Color ColorList { get; private set; }



        // SqlConnection con = new SqlConnection("Data Source=MAHAD-PC;Initial Catalog=HotelManagementSystem;Integrated Security=True");
        SqlConnection con = new SqlConnection("Data Source=MARIYA;Initial Catalog=HostelManagementSystem;Integrated Security=True");
        public LOGIN()
        {
            InitializeComponent();

            UserNametxt.Text = defaultText;
            UserNametxt.Click += UserNametxt_TextChanged;
            Passwordtxt.Click+= Passwordtxt_TextChanged;

        }

        private void UserNametxt_TextChanged(object sender, EventArgs e)
        {
            if (UserNametxt.Text == defaultText)
            {
                UserNametxt.Text = string.Empty;
            }
        }

        private void loginbtn_Click(object sender, EventArgs e)
        {
            // ActivateButton(sender, ColorList);
            if (UserNametxt.Text == "")
            {
                MessageBox.Show("Enter username");
            }
            else if (Passwordtxt.Text == "")
            {
                MessageBox.Show("Enter password");
            }
            else
            {
                try
                {
                    SqlConnection con = new SqlConnection("Data Source=DESKTOP-KFDUOB5\\MSSQLSERVER2022;Initial Catalog=HotelManagementSystem;Integrated Security=True");
                    con.Open();
                    SqlCommand cmd = new SqlCommand("select * from Users where UserName=@UserName and UserPassword=@Password", con);
                    cmd.Parameters.AddWithValue("@UserName", UserNametxt.Text);
                    cmd.Parameters.AddWithValue("@Password", Passwordtxt.Text);
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    if (dt.Rows.Count > 0)
                    {

                        hotalMS.Form1 h = new hotalMS.Form1();
                        this.Hide();
                        h.Show();


                    }
                    else
                    {
                        label.Visible = true;
                        Passwordtxt.Clear();
                        //MessageBox.Show("Invalid username or password");
                    }
                    con.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("" + ex);

                }
                finally
                {
                    // con.Close();
                }
            }
            //LOGIN l = new LOGIN();
            //Visible = false;



        }

        private void label6_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void label2_Click(object sender, EventArgs e)
        {
            ActivateButton(sender, ColorList);
            //this.Hide();
            //ADMINLOGIN h = new ADMINLOGIN();
            //h.Show();


        }

        private void guna2CirclePictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            // UserNametxt.Clear();
        }
        private void LOGIN_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void ActivateButton(object btnSender, Color color)
        {
            if (btnSender != null)
            {
                if (currentButton != (Button)btnSender)
                {
                    DisableButton();
                    currentButton = (Button)btnSender;
                    currentButton.BackColor = Color.FromArgb(56, 39, 58);
                    currentButton.ForeColor = color;
                }
            }
        }

        private void DisableButton()
        {
            if (previousButton != null && previousBtn != null)
            {
                previousButton.BackColor = Color.FromArgb(51, 51, 76);
                previousButton.ForeColor = Color.Gainsboro;
                previousButton.Font = new Font("Segoe UI", 10F, FontStyle.Bold, GraphicsUnit.Point, 0);
                previousBtn.BackColor = originalIconBoxColor;
            }
        }

        private void iconPictureBox4_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ADMINLOGIN ad = new ADMINLOGIN();
            this.Hide();
            ad.Show();
        }

        private void Passwordtxt_TextChanged(object sender, EventArgs e)
        {
            if (Passwordtxt.Text == defaultText1)
            {
                Passwordtxt.Text = string.Empty;
            }
        }
    }
}

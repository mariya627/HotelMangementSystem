﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using hotalMS;

namespace DBMS_HMS
{
    public partial class ADMINLOGIN : Form
    {
        
         SqlConnection con = new SqlConnection("Data Source=DESKTOP-KFDUOB5\\MSSQLSERVER2022;Initial Catalog=HotelManagementSystem;Integrated Security=True;Encrypt=True;TrustServerCertificate=True");

        public ADMINLOGIN()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string username = "admin"; // Replace with the desired username
            string enteredPassword = Passwordtxt.Text;

            try
            {
                using (SqlConnection connection = new SqlConnection("Data Source=DESKTOP-KFDUOB5\\MSSQLSERVER2022;Initial Catalog=HotelManagementSystem;Integrated Security=True;Encrypt=True;TrustServerCertificate=True"))
                {
                    con.Open();

                    string query = "SELECT UserPassword FROM Users WHERE UserName = @UserName";

                    SqlCommand command = new SqlCommand(query, con);
                    {
                        command.Parameters.AddWithValue("@UserName", username);

                        string storedPassword = (string)command.ExecuteScalar();

                        if (storedPassword != null && storedPassword.Equals(enteredPassword))
                        {
                            // Successful login
                            //MessageBox.Show("Login successful!");
                            Form2 a = new Form2();
                            //a.Show();
                            this.Hide();
                            a.Show();
                            //ADMINLOGIN g = new ADMINLOGIN();
                            //g.Hide();
                        }
                        else
                        {
                            // Invalid credentials
                            //MessageBox.Show("Invalid username or password!");
                            label.Visible = true;
                            Passwordtxt.Clear();
                        }
                        con.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error connecting to the database: " + ex.Message);
            }
        }

        private void E_close_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void Passwordtxt_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            LOGIN l = new LOGIN();
            this.Hide();
            l.Show();

        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button4_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            LOGIN l = new LOGIN();
            this.Hide();
            l.Show();
        }

        private void iconPictureBox2_Click(object sender, EventArgs e)
        {
            LOGIN l = new LOGIN();
            this.Hide();
            l.Show();
        }

        private void iconPictureBox4_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}

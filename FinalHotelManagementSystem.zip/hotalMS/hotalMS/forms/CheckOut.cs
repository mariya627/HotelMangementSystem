﻿using FontAwesome.Sharp;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace hotalMS.forms
{
    public partial class CheckOut : Form
    {
        public CheckOut()
        {
            InitializeComponent();
        }
        SqlConnection con = new SqlConnection("Data Source=DESKTOP-KFDUOB5\\MSSQLSERVER2022;Initial Catalog=HotelManagementSystem;Integrated Security=True;Encrypt=True;TrustServerCertificate=True");

        private void Displaybtn_Click(object sender, EventArgs e)
        {
            populate();
        }

        public void populate()
        {
           // SqlConnection connection = new SqlConnection("Data Source=DESKTOP-KFDUOB5\\MSSQLSERVER2022;Initial Catalog=HotelManagementSystem;Integrated Security=True;Encrypt=True;TrustServerCertificate=True");
            con.Open();
            string query = "select * from Room";
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.ExecuteNonQuery();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            SqlCommandBuilder cb = new SqlCommandBuilder(da);
            var ds = new DataSet();
            da.Fill(ds);
            R_datagrid.DataSource = ds.Tables[0];
            con.Close();
        }

        private void Upbtn_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(R_idsearch.Text))
            {
                MessageBox.Show("Please enter a Room ID.");
                return;
            }

            if (!int.TryParse(R_idsearch.Text, out int roomID))
            {
                MessageBox.Show("Invalid Room ID. Please enter a valid numeric value.");
                return;
            }
            if (!int.TryParse(R_idsearch.Text, out int roomNO))
            {
                MessageBox.Show("Invalid Room NO. Please enter a valid numeric value.");
                return;
            }

            string newStatus = "";

            if (OccupiedRadioButton.Checked)
            {
                newStatus = "Occupied";
            }
            else if (VacantRadioButton.Checked)
            {
                newStatus = "Vacant";
            }
            else
            {
                MessageBox.Show("Please select a room status (Occupied or Vacant).");
                return;
            }

            using (SqlConnection connection = new SqlConnection("Data Source=DESKTOP-KFDUOB5\\MSSQLSERVER2022;Initial Catalog=HotelManagementSystem;Integrated Security=True;Encrypt=True;TrustServerCertificate=True"))
            {
                try
                {
                    connection.Open();

                    SqlCommand cmd = new SqlCommand("UPDATE Room SET Room_Status = @Room_Status WHERE Room_ID = @Room_ID OR Room_No = @Room_No ", connection);

                    cmd.Parameters.AddWithValue("@Room_Status", newStatus);
                    cmd.Parameters.AddWithValue("@Room_ID", roomID);
                    cmd.Parameters.AddWithValue("@Room_No", roomNO);
                    int rowsAffected = cmd.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        bool columnFound = false;
                        int columnIndex = 0;
                        foreach (DataGridViewColumn column in R_datagrid.Columns)
                        {
                            if (column.HeaderText == "Room_ID") // Replace with the actual column header for Room ID
                            {
                                columnFound = true;
                                columnIndex = column.Index;
                                break;
                            }
                        }

                        if (columnFound)
                        {
                            foreach (DataGridViewRow row in R_datagrid.Rows)
                            {
                                if (Convert.ToInt32(row.Cells[columnIndex].Value) == roomID)
                                {
                                    row.Cells["Room_Status"].Value = newStatus;
                                    break;
                                }
                            }

                            MessageBox.Show("Room status updated successfully!");
                        }
                        else
                        {
                            MessageBox.Show("Column for Room ID not found in the DataGridView.");
                        }
                    }
                    else
                    {
                        MessageBox.Show("Room ID not found.");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
            }
        }

        private void R_idsearch_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void searchbtn_Click(object sender, EventArgs e)
        {
            //try
            //{
            //    int roomID;
            //    if (!int.TryParse(R_idsearch.Text, out roomID))
            //    {
            //        MessageBox.Show("Invalid room ID. Please enter a valid integer value.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            //        R_idsearch.Clear();
            //        return;
            //    }

            //    con.Open();

            //    using (SqlCommand command = new SqlCommand("Exec SearchRoom '" + roomID + "'", con))
            //    {
            //        SqlDataAdapter adapter = new SqlDataAdapter(command);
            //        DataTable dataTable = new DataTable();
            //        adapter.Fill(dataTable);

            //        if (dataTable.Rows.Count > 0)
            //        {
            //            R_datagrid.DataSource = dataTable;

            //            // Retrieve the room status from the DataTable
            //            string status = dataTable.Rows[0]["Room_Status"].ToString();

            //            // Set the appropriate radio button based on the room status
            //            if (status == "Occupied")
            //            {
            //                OccupiedRadioButton.Checked = true;
            //            }
            //            else if (status == "Vacant")
            //            {
            //                VacantRadioButton.Checked = true;
            //            }
            //        }
            //        else
            //        {
            //            MessageBox.Show("Room ID not found in the database.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            //            R_idsearch.Clear();
            //        }
            //    }
            //}
            //catch (Exception ex)
            //{
            //    MessageBox.Show("An error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            //    R_idsearch.Clear();
            //}
            //finally
            //{
            //    con.Close();
            //}

            /////////////////////////////

            //try
            //{

            //    if (checktext.SelectedItem == null)
            //    {
            //        MessageBox.Show("Please select a search option (SearchByRoomID or SearchByRoomNo).");
            //        return;
            //    }
            //    using (SqlConnection con = new SqlConnection("Data Source=DESKTOP-KFDUOB5\\MSSQLSERVER2022;Initial Catalog=HotelManagementSystem;Integrated Security=True;Encrypt=True;TrustServerCertificate=True"))
            //    {
            //        con.Open();
            //        SqlDataAdapter adapter = new SqlDataAdapter();
            //        SqlCommand command;

            //        string searchTerm = R_idsearch.Text.Trim();

            //        if (checktext.SelectedItem.ToString() == "SearchByRoomID")
            //        {
            //            // Search by ID
            //            if (int.TryParse(searchTerm, out int serviceID))
            //            {
            //                command = new SqlCommand("SearchRoom", con);
            //                command.CommandType = CommandType.StoredProcedure;
            //                command.Parameters.AddWithValue("@roomID", serviceID);
            //            }
            //            else
            //            {
            //                MessageBox.Show("Invalid Service ID. Please enter a valid integer value.");
            //                return;
            //            }
            //        }
            //        else if (checktext.SelectedItem.ToString() == "SearchByRoomNo")
            //        {
            //            // Search by Room No
            //            if (int.TryParse(searchTerm, out int roomNo))
            //            {
            //                command = new SqlCommand("SearchRoomByRoomNoCheckout", con);
            //                command.CommandType = CommandType.StoredProcedure;
            //                command.Parameters.AddWithValue("@RoomNo", roomNo);
            //            }
            //            else
            //            {
            //                MessageBox.Show("Invalid Room No. Please enter a valid integer value.");
            //                return;
            //            }
            //        }
            //        else
            //        {
            //            MessageBox.Show("Invalid search type selected.");
            //            return;
            //        }

            //        DataTable dataTable = new DataTable();
            //        adapter.SelectCommand = command;

            //        adapter.Fill(dataTable);

            //        if (dataTable.Rows.Count == 0)
            //        {
            //            MessageBox.Show("No matching records found.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            //        }
            //        else
            //        {
            //        R_datagrid.DataSource = dataTable;
            //        }
            //    }
            //}
            //catch (Exception ex)
            //{
            //    MessageBox.Show("An error occurred: " + ex.Message);
            //}








            //////////////////////////////////////////////////

            try
            {
                string selectedSearchType = checktext.SelectedItem?.ToString();

                if (string.IsNullOrEmpty(selectedSearchType))
                {
                    MessageBox.Show("Please select a search option (SearchByRoomID or SearchByRoomNo).", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                int roomID;
                if (!int.TryParse(R_idsearch.Text, out roomID))
                {
                    MessageBox.Show("Invalid room ID. Please enter a valid integer value.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    R_idsearch.Clear();
                    return;
                }

                con.Open();

                using (SqlCommand command = new SqlCommand())
                {
                    command.Connection = con;
                    SqlDataAdapter adapter = new SqlDataAdapter(command);
                    DataTable dataTable = new DataTable();

                    if (selectedSearchType == "SearchByRoomID")
                    {
                        command.CommandText = "Exec SearchRoom '" + roomID + "'";
                    }
                    else if (selectedSearchType == "SearchByRoomNo")
                    {
                        command.CommandText = "Exec SearchRoombyRoomNoCheckout '" + roomID + "'";
                    }
                    else
                    {
                        // Handle invalid selection if necessary
                        MessageBox.Show("Please select a valid search type.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }

                    adapter.Fill(dataTable);

                    if (dataTable.Rows.Count > 0)
                    {
                        R_datagrid.DataSource = dataTable;

                        // Retrieve the room status from the DataTable
                        string status = dataTable.Rows[0]["Room_Status"].ToString();

                        // Set the appropriate radio button based on the room status
                        if (status == "Occupied")
                        {
                            OccupiedRadioButton.Checked = true;
                        }
                        else if (status == "Vacant")
                        {
                            VacantRadioButton.Checked = true;
                        }
                    }
                    else
                    {
                        MessageBox.Show("Room ID not found in the database.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        R_idsearch.Clear();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                R_idsearch.Clear();
            }
            finally
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }

        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using hotalMS;

namespace DBMS_HMS
{
    public partial class Receipt : Form
    {
        public Receipt(string receipt)
        {

            InitializeComponent();
            txtReceipt.Width = 383;
            txtReceipt.Height = 481;
            txtReceipt.Text = receipt;
        }
        public TextBox TxtReciept
        {
            get { return txtReceipt; }
            set { txtReceipt = value; }
        }

        // Other members of the Reciept form

        private string receiptFilePath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Desktop), "Receipt.txt");
        private void txtReceipt_TextChanged(object sender, EventArgs e)
        {

        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            printPreviewDialog1.Document = printDocument1;
            printPreviewDialog1.ShowDialog();

        }

        private void label2_Click(object sender, EventArgs e)
        {
            //Application.Exit();
            Form1 f = new Form1();
            this.Hide();
            f.Show();
        }

        private void Receipt_Load(object sender, EventArgs e)
        {

        }

        private void Displaybtn_Click(object sender, EventArgs e)
        {
            //printPreviewDialog1.Document = printDocument1;
            //printPreviewDialog1.ShowDialog();



            string receiptContent = File.ReadAllText(receiptFilePath);

            // Check if the file is not empty before printing
            if (!string.IsNullOrEmpty(receiptContent))
            {
                // Set the PrintDocument to the PrintPreviewDialog
                printPreviewDialog1.Document = printDocument1;

                // Show the PrintPreviewDialog
                printPreviewDialog1.ShowDialog();

                // Clear the content of the receipt file
                File.WriteAllText(receiptFilePath, string.Empty);

               // MessageBox.Show("Printing successful. Receipt file has been cleared.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("The receipt file is empty. Nothing to print.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            string receiptContent = File.ReadAllText(receiptFilePath);

            // Create a Font and Brush for the text
            Font font = new Font("Arial", 12);
            Brush brush = Brushes.Black;

            // Set the print area
            RectangleF printArea = new RectangleF(e.MarginBounds.Left, e.MarginBounds.Top, e.MarginBounds.Width, e.MarginBounds.Height);

            // Draw the receipt content on the PrintDocument
            e.Graphics.DrawString(receiptContent, font, brush, printArea);

        }
    }
}

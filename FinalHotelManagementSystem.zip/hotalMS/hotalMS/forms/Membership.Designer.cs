﻿namespace hotalMS.forms
{
    partial class Membership
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Inactive = new RadioButton();
            iconPictureBox5 = new FontAwesome.Sharp.IconPictureBox();
            Midtxt = new TextBox();
            tabControl1 = new TabControl();
            tabPage1 = new TabPage();
            panel5 = new Panel();
            panel7 = new Panel();
            panel3 = new Panel();
            panel4 = new Panel();
            panel2 = new Panel();
            panel1 = new Panel();
            panel6 = new Panel();
            panel11 = new Panel();
            iconPictureBox8 = new FontAwesome.Sharp.IconPictureBox();
            label3 = new Label();
            iconPictureBox6 = new FontAwesome.Sharp.IconPictureBox();
            label2 = new Label();
            label12 = new Label();
            iconPictureBox4 = new FontAwesome.Sharp.IconPictureBox();
            label10 = new Label();
            iconPictureBox7 = new FontAwesome.Sharp.IconPictureBox();
            label7 = new Label();
            iconPictureBox3 = new FontAwesome.Sharp.IconPictureBox();
            label6 = new Label();
            iconPictureBox2 = new FontAwesome.Sharp.IconPictureBox();
            label1 = new Label();
            label4 = new Label();
            iconPictureBox1 = new FontAwesome.Sharp.IconPictureBox();
            Cnic = new TextBox();
            startdate = new DateTimePicker();
            Durationtxt = new TextBox();
            LastName = new TextBox();
            FirstName = new TextBox();
            pricetxt = new TextBox();
            Mtypecombo = new ComboBox();
            addmembtn = new Button();
            tabPage2 = new TabPage();
            panel8 = new Panel();
            iconPictureBox10 = new FontAwesome.Sharp.IconPictureBox();
            label13 = new Label();
            label8 = new Label();
            iconPictureBox9 = new FontAwesome.Sharp.IconPictureBox();
            Disbtn = new Button();
            searchbtn = new Button();
            searchtxt = new TextBox();
            salgrid = new DataGridView();
            tabPage3 = new TabPage();
            panel15 = new Panel();
            panel14 = new Panel();
            panel13 = new Panel();
            label21 = new Label();
            panel12 = new Panel();
            panel10 = new Panel();
            iconPictureBox20 = new FontAwesome.Sharp.IconPictureBox();
            label20 = new Label();
            iconPictureBox19 = new FontAwesome.Sharp.IconPictureBox();
            label19 = new Label();
            iconPictureBox18 = new FontAwesome.Sharp.IconPictureBox();
            label18 = new Label();
            iconPictureBox17 = new FontAwesome.Sharp.IconPictureBox();
            label17 = new Label();
            iconPictureBox16 = new FontAwesome.Sharp.IconPictureBox();
            label5 = new Label();
            iconPictureBox15 = new FontAwesome.Sharp.IconPictureBox();
            label16 = new Label();
            iconPictureBox14 = new FontAwesome.Sharp.IconPictureBox();
            label15 = new Label();
            iconPictureBox13 = new FontAwesome.Sharp.IconPictureBox();
            label14 = new Label();
            panel9 = new Panel();
            iconPictureBox12 = new FontAwesome.Sharp.IconPictureBox();
            label9 = new Label();
            label11 = new Label();
            iconPictureBox11 = new FontAwesome.Sharp.IconPictureBox();
            GuestID = new TextBox();
            StartdateTime = new DateTimePicker();
            Active = new RadioButton();
            DurationTextBox = new TextBox();
            LstName = new TextBox();
            FName = new TextBox();
            PriceTextBox = new TextBox();
            MembershipTypeTextBox = new ComboBox();
            updatebtn = new Button();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox5).BeginInit();
            tabControl1.SuspendLayout();
            tabPage1.SuspendLayout();
            panel5.SuspendLayout();
            panel3.SuspendLayout();
            panel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox8).BeginInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox6).BeginInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox7).BeginInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox1).BeginInit();
            tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox10).BeginInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox9).BeginInit();
            ((System.ComponentModel.ISupportInitialize)salgrid).BeginInit();
            tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox20).BeginInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox19).BeginInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox18).BeginInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox17).BeginInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox16).BeginInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox15).BeginInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox14).BeginInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox13).BeginInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox12).BeginInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox11).BeginInit();
            SuspendLayout();
            // 
            // Inactive
            // 
            Inactive.AutoSize = true;
            Inactive.Font = new Font("Sitka Banner", 12.2499981F, FontStyle.Bold);
            Inactive.ForeColor = SystemColors.AppWorkspace;
            Inactive.Location = new Point(768, 296);
            Inactive.Margin = new Padding(2);
            Inactive.Name = "Inactive";
            Inactive.Size = new Size(84, 28);
            Inactive.TabIndex = 79;
            Inactive.TabStop = true;
            Inactive.Text = "Inactive";
            Inactive.UseVisualStyleBackColor = true;
            // 
            // iconPictureBox5
            // 
            iconPictureBox5.BackColor = Color.FromArgb(51, 51, 76);
            iconPictureBox5.ForeColor = SystemColors.AppWorkspace;
            iconPictureBox5.IconChar = FontAwesome.Sharp.IconChar.CalendarAlt;
            iconPictureBox5.IconColor = SystemColors.AppWorkspace;
            iconPictureBox5.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconPictureBox5.Location = new Point(14, 251);
            iconPictureBox5.Name = "iconPictureBox5";
            iconPictureBox5.Size = new Size(32, 32);
            iconPictureBox5.TabIndex = 79;
            iconPictureBox5.TabStop = false;
            // 
            // Midtxt
            // 
            Midtxt.BackColor = Color.FromArgb(51, 51, 76);
            Midtxt.BorderStyle = BorderStyle.None;
            Midtxt.Font = new Font("Sitka Banner", 12.2499981F, FontStyle.Bold);
            Midtxt.ForeColor = SystemColors.AppWorkspace;
            Midtxt.Location = new Point(209, 59);
            Midtxt.Margin = new Padding(3, 4, 3, 4);
            Midtxt.Name = "Midtxt";
            Midtxt.Size = new Size(643, 21);
            Midtxt.TabIndex = 58;
            Midtxt.TextChanged += Midtxt_TextChanged;
            // 
            // tabControl1
            // 
            tabControl1.Alignment = TabAlignment.Bottom;
            tabControl1.Controls.Add(tabPage1);
            tabControl1.Controls.Add(tabPage2);
            tabControl1.Controls.Add(tabPage3);
            tabControl1.Dock = DockStyle.Fill;
            tabControl1.Location = new Point(0, 0);
            tabControl1.Margin = new Padding(2);
            tabControl1.Name = "tabControl1";
            tabControl1.SelectedIndex = 0;
            tabControl1.Size = new Size(880, 420);
            tabControl1.TabIndex = 62;
            // 
            // tabPage1
            // 
            tabPage1.BackColor = Color.FromArgb(51, 51, 76);
            tabPage1.Controls.Add(panel5);
            tabPage1.Controls.Add(panel3);
            tabPage1.Controls.Add(panel2);
            tabPage1.Controls.Add(panel1);
            tabPage1.Controls.Add(panel6);
            tabPage1.Controls.Add(iconPictureBox8);
            tabPage1.Controls.Add(label3);
            tabPage1.Controls.Add(iconPictureBox6);
            tabPage1.Controls.Add(label2);
            tabPage1.Controls.Add(iconPictureBox5);
            tabPage1.Controls.Add(label12);
            tabPage1.Controls.Add(iconPictureBox4);
            tabPage1.Controls.Add(label10);
            tabPage1.Controls.Add(iconPictureBox7);
            tabPage1.Controls.Add(label7);
            tabPage1.Controls.Add(iconPictureBox3);
            tabPage1.Controls.Add(label6);
            tabPage1.Controls.Add(iconPictureBox2);
            tabPage1.Controls.Add(label1);
            tabPage1.Controls.Add(label4);
            tabPage1.Controls.Add(iconPictureBox1);
            tabPage1.Controls.Add(Cnic);
            tabPage1.Controls.Add(startdate);
            tabPage1.Controls.Add(Durationtxt);
            tabPage1.Controls.Add(LastName);
            tabPage1.Controls.Add(FirstName);
            tabPage1.Controls.Add(pricetxt);
            tabPage1.Controls.Add(Mtypecombo);
            tabPage1.Controls.Add(addmembtn);
            tabPage1.Font = new Font("Microsoft Sans Serif", 11F, FontStyle.Bold, GraphicsUnit.Point, 0);
            tabPage1.Location = new Point(4, 4);
            tabPage1.Margin = new Padding(2);
            tabPage1.Name = "tabPage1";
            tabPage1.Padding = new Padding(2);
            tabPage1.Size = new Size(872, 392);
            tabPage1.TabIndex = 0;
            tabPage1.Text = "Add Membership";
            // 
            // panel5
            // 
            panel5.BackColor = Color.Gray;
            panel5.Controls.Add(panel7);
            panel5.Location = new Point(611, 279);
            panel5.Name = "panel5";
            panel5.Size = new Size(233, 1);
            panel5.TabIndex = 88;
            // 
            // panel7
            // 
            panel7.BackColor = Color.Gray;
            panel7.Location = new Point(0, 0);
            panel7.Name = "panel7";
            panel7.Size = new Size(263, 1);
            panel7.TabIndex = 64;
            // 
            // panel3
            // 
            panel3.BackColor = Color.Gray;
            panel3.Controls.Add(panel4);
            panel3.Location = new Point(611, 120);
            panel3.Name = "panel3";
            panel3.Size = new Size(233, 1);
            panel3.TabIndex = 87;
            // 
            // panel4
            // 
            panel4.BackColor = Color.Gray;
            panel4.Location = new Point(0, 0);
            panel4.Name = "panel4";
            panel4.Size = new Size(263, 1);
            panel4.TabIndex = 64;
            // 
            // panel2
            // 
            panel2.BackColor = Color.Gray;
            panel2.Location = new Point(170, 227);
            panel2.Name = "panel2";
            panel2.Size = new Size(236, 1);
            panel2.TabIndex = 86;
            // 
            // panel1
            // 
            panel1.BackColor = Color.Gray;
            panel1.Location = new Point(171, 165);
            panel1.Name = "panel1";
            panel1.Size = new Size(235, 1);
            panel1.TabIndex = 85;
            // 
            // panel6
            // 
            panel6.BackColor = Color.Gray;
            panel6.Controls.Add(panel11);
            panel6.Location = new Point(171, 120);
            panel6.Name = "panel6";
            panel6.Size = new Size(233, 1);
            panel6.TabIndex = 84;
            // 
            // panel11
            // 
            panel11.BackColor = Color.Gray;
            panel11.Location = new Point(0, 0);
            panel11.Name = "panel11";
            panel11.Size = new Size(263, 1);
            panel11.TabIndex = 64;
            // 
            // iconPictureBox8
            // 
            iconPictureBox8.BackColor = Color.FromArgb(51, 51, 76);
            iconPictureBox8.ForeColor = SystemColors.AppWorkspace;
            iconPictureBox8.IconChar = FontAwesome.Sharp.IconChar.MoneyBillWaveAlt;
            iconPictureBox8.IconColor = SystemColors.AppWorkspace;
            iconPictureBox8.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconPictureBox8.Location = new Point(421, 249);
            iconPictureBox8.Name = "iconPictureBox8";
            iconPictureBox8.Size = new Size(32, 32);
            iconPictureBox8.TabIndex = 83;
            iconPictureBox8.TabStop = false;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Sitka Banner", 14.2499981F, FontStyle.Bold);
            label3.ForeColor = SystemColors.AppWorkspace;
            label3.Location = new Point(456, 251);
            label3.Margin = new Padding(4, 0, 4, 0);
            label3.Name = "label3";
            label3.Size = new Size(73, 28);
            label3.TabIndex = 82;
            label3.Text = "Amount";
            // 
            // iconPictureBox6
            // 
            iconPictureBox6.BackColor = Color.FromArgb(51, 51, 76);
            iconPictureBox6.ForeColor = SystemColors.AppWorkspace;
            iconPictureBox6.IconChar = FontAwesome.Sharp.IconChar.UserPlus;
            iconPictureBox6.IconColor = SystemColors.AppWorkspace;
            iconPictureBox6.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconPictureBox6.Location = new Point(423, 165);
            iconPictureBox6.Name = "iconPictureBox6";
            iconPictureBox6.Size = new Size(32, 32);
            iconPictureBox6.TabIndex = 81;
            iconPictureBox6.TabStop = false;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Sitka Banner", 14.2499981F, FontStyle.Bold);
            label2.ForeColor = SystemColors.AppWorkspace;
            label2.Location = new Point(456, 168);
            label2.Margin = new Padding(4, 0, 4, 0);
            label2.Name = "label2";
            label2.Size = new Size(151, 28);
            label2.TabIndex = 80;
            label2.Text = "Membership Type";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Font = new Font("Sitka Banner", 14.2499981F, FontStyle.Bold);
            label12.ForeColor = SystemColors.AppWorkspace;
            label12.Location = new Point(49, 252);
            label12.Margin = new Padding(4, 0, 4, 0);
            label12.Name = "label12";
            label12.Size = new Size(90, 28);
            label12.TabIndex = 78;
            label12.Text = "Start Date";
            // 
            // iconPictureBox4
            // 
            iconPictureBox4.BackColor = Color.FromArgb(51, 51, 76);
            iconPictureBox4.ForeColor = SystemColors.AppWorkspace;
            iconPictureBox4.IconChar = FontAwesome.Sharp.IconChar.Clock;
            iconPictureBox4.IconColor = SystemColors.AppWorkspace;
            iconPictureBox4.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconPictureBox4.Location = new Point(14, 197);
            iconPictureBox4.Name = "iconPictureBox4";
            iconPictureBox4.Size = new Size(32, 32);
            iconPictureBox4.TabIndex = 77;
            iconPictureBox4.TabStop = false;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Sitka Banner", 14.2499981F, FontStyle.Bold);
            label10.ForeColor = SystemColors.AppWorkspace;
            label10.Location = new Point(49, 200);
            label10.Margin = new Padding(4, 0, 4, 0);
            label10.Name = "label10";
            label10.Size = new Size(81, 28);
            label10.TabIndex = 76;
            label10.Text = "Duration";
            // 
            // iconPictureBox7
            // 
            iconPictureBox7.BackColor = Color.FromArgb(51, 51, 76);
            iconPictureBox7.ForeColor = SystemColors.AppWorkspace;
            iconPictureBox7.IconChar = FontAwesome.Sharp.IconChar.IdCard;
            iconPictureBox7.IconColor = SystemColors.AppWorkspace;
            iconPictureBox7.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconPictureBox7.Location = new Point(14, 143);
            iconPictureBox7.Name = "iconPictureBox7";
            iconPictureBox7.Size = new Size(32, 32);
            iconPictureBox7.TabIndex = 75;
            iconPictureBox7.TabStop = false;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Sitka Banner", 14.2499981F, FontStyle.Bold);
            label7.ForeColor = SystemColors.AppWorkspace;
            label7.Location = new Point(49, 147);
            label7.Margin = new Padding(4, 0, 4, 0);
            label7.Name = "label7";
            label7.Size = new Size(51, 28);
            label7.TabIndex = 74;
            label7.Text = "CNIC";
            // 
            // iconPictureBox3
            // 
            iconPictureBox3.BackColor = Color.FromArgb(51, 51, 76);
            iconPictureBox3.ForeColor = SystemColors.AppWorkspace;
            iconPictureBox3.IconChar = FontAwesome.Sharp.IconChar.UserEdit;
            iconPictureBox3.IconColor = SystemColors.AppWorkspace;
            iconPictureBox3.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconPictureBox3.Location = new Point(423, 89);
            iconPictureBox3.Name = "iconPictureBox3";
            iconPictureBox3.Size = new Size(32, 32);
            iconPictureBox3.TabIndex = 73;
            iconPictureBox3.TabStop = false;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Sitka Banner", 14.2499981F, FontStyle.Bold);
            label6.ForeColor = SystemColors.AppWorkspace;
            label6.Location = new Point(456, 93);
            label6.Margin = new Padding(4, 0, 4, 0);
            label6.Name = "label6";
            label6.Size = new Size(94, 28);
            label6.TabIndex = 72;
            label6.Text = "Last Name";
            // 
            // iconPictureBox2
            // 
            iconPictureBox2.BackColor = Color.FromArgb(51, 51, 76);
            iconPictureBox2.ForeColor = SystemColors.AppWorkspace;
            iconPictureBox2.IconChar = FontAwesome.Sharp.IconChar.UserEdit;
            iconPictureBox2.IconColor = SystemColors.AppWorkspace;
            iconPictureBox2.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconPictureBox2.Location = new Point(14, 85);
            iconPictureBox2.Name = "iconPictureBox2";
            iconPictureBox2.Size = new Size(32, 32);
            iconPictureBox2.TabIndex = 71;
            iconPictureBox2.TabStop = false;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Sitka Banner", 14.2499981F, FontStyle.Bold);
            label1.ForeColor = SystemColors.AppWorkspace;
            label1.Location = new Point(49, 89);
            label1.Margin = new Padding(4, 0, 4, 0);
            label1.Name = "label1";
            label1.Size = new Size(98, 28);
            label1.TabIndex = 70;
            label1.Text = "First Name";
            // 
            // label4
            // 
            label4.Font = new Font("Sitka Banner", 17F, FontStyle.Bold);
            label4.ForeColor = SystemColors.AppWorkspace;
            label4.Location = new Point(74, 16);
            label4.Name = "label4";
            label4.Size = new Size(801, 39);
            label4.TabIndex = 69;
            label4.Text = "\"This club is for members only.But once you join membership lasts an eternity.\"";
            // 
            // iconPictureBox1
            // 
            iconPictureBox1.BackColor = Color.FromArgb(51, 51, 76);
            iconPictureBox1.ForeColor = SystemColors.AppWorkspace;
            iconPictureBox1.IconChar = FontAwesome.Sharp.IconChar.UserTie;
            iconPictureBox1.IconColor = SystemColors.AppWorkspace;
            iconPictureBox1.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconPictureBox1.IconSize = 57;
            iconPictureBox1.Location = new Point(11, 5);
            iconPictureBox1.Name = "iconPictureBox1";
            iconPictureBox1.Size = new Size(57, 59);
            iconPictureBox1.TabIndex = 68;
            iconPictureBox1.TabStop = false;
            // 
            // Cnic
            // 
            Cnic.BackColor = Color.FromArgb(51, 51, 76);
            Cnic.BorderStyle = BorderStyle.None;
            Cnic.Font = new Font("Sitka Banner", 12.2499981F, FontStyle.Bold);
            Cnic.ForeColor = SystemColors.AppWorkspace;
            Cnic.Location = new Point(170, 143);
            Cnic.Margin = new Padding(2);
            Cnic.Name = "Cnic";
            Cnic.Size = new Size(234, 21);
            Cnic.TabIndex = 66;
            // 
            // startdate
            // 
            startdate.Location = new Point(170, 254);
            startdate.Margin = new Padding(2);
            startdate.Name = "startdate";
            startdate.Size = new Size(234, 24);
            startdate.TabIndex = 63;
            // 
            // Durationtxt
            // 
            Durationtxt.BackColor = Color.FromArgb(51, 51, 76);
            Durationtxt.BorderStyle = BorderStyle.None;
            Durationtxt.Font = new Font("Sitka Banner", 12.2499981F, FontStyle.Bold);
            Durationtxt.ForeColor = SystemColors.AppWorkspace;
            Durationtxt.Location = new Point(170, 201);
            Durationtxt.Margin = new Padding(2);
            Durationtxt.Name = "Durationtxt";
            Durationtxt.Size = new Size(236, 21);
            Durationtxt.TabIndex = 57;
            // 
            // LastName
            // 
            LastName.BackColor = Color.FromArgb(51, 51, 76);
            LastName.BorderStyle = BorderStyle.None;
            LastName.Font = new Font("Sitka Banner", 12.2499981F, FontStyle.Bold);
            LastName.ForeColor = SystemColors.AppWorkspace;
            LastName.Location = new Point(609, 97);
            LastName.Margin = new Padding(2);
            LastName.Name = "LastName";
            LastName.Size = new Size(234, 21);
            LastName.TabIndex = 55;
            // 
            // FirstName
            // 
            FirstName.BackColor = Color.FromArgb(51, 51, 76);
            FirstName.BorderStyle = BorderStyle.None;
            FirstName.Font = new Font("Sitka Banner", 12.2499981F, FontStyle.Bold);
            FirstName.ForeColor = SystemColors.AppWorkspace;
            FirstName.Location = new Point(170, 97);
            FirstName.Margin = new Padding(2);
            FirstName.Name = "FirstName";
            FirstName.Size = new Size(234, 21);
            FirstName.TabIndex = 53;
            // 
            // pricetxt
            // 
            pricetxt.BackColor = Color.FromArgb(51, 51, 76);
            pricetxt.BorderStyle = BorderStyle.None;
            pricetxt.Font = new Font("Sitka Banner", 12.2499981F, FontStyle.Bold);
            pricetxt.ForeColor = SystemColors.AppWorkspace;
            pricetxt.Location = new Point(611, 256);
            pricetxt.Margin = new Padding(2);
            pricetxt.Name = "pricetxt";
            pricetxt.Size = new Size(234, 21);
            pricetxt.TabIndex = 52;
            // 
            // Mtypecombo
            // 
            Mtypecombo.BackColor = Color.FromArgb(51, 51, 76);
            Mtypecombo.FlatStyle = FlatStyle.Flat;
            Mtypecombo.Font = new Font("Sitka Banner", 12.2499981F, FontStyle.Bold);
            Mtypecombo.ForeColor = SystemColors.AppWorkspace;
            Mtypecombo.FormattingEnabled = true;
            Mtypecombo.Items.AddRange(new object[] { "Basic", "Standard", "Premium" });
            Mtypecombo.Location = new Point(610, 169);
            Mtypecombo.Name = "Mtypecombo";
            Mtypecombo.Size = new Size(234, 31);
            Mtypecombo.TabIndex = 50;
            Mtypecombo.SelectedIndexChanged += Mtypecombo_SelectedIndexChanged;
            // 
            // addmembtn
            // 
            addmembtn.BackColor = Color.FromArgb(51, 51, 76);
            addmembtn.FlatStyle = FlatStyle.Flat;
            addmembtn.Font = new Font("Sitka Banner", 18F, FontStyle.Bold);
            addmembtn.ForeColor = SystemColors.AppWorkspace;
            addmembtn.Location = new Point(549, 329);
            addmembtn.Margin = new Padding(3, 4, 3, 4);
            addmembtn.Name = "addmembtn";
            addmembtn.Size = new Size(315, 45);
            addmembtn.TabIndex = 35;
            addmembtn.Text = "Add Membership";
            addmembtn.UseVisualStyleBackColor = false;
            addmembtn.Click += addmembtn_Click;
            // 
            // tabPage2
            // 
            tabPage2.BackColor = Color.FromArgb(51, 51, 76);
            tabPage2.Controls.Add(panel8);
            tabPage2.Controls.Add(iconPictureBox10);
            tabPage2.Controls.Add(label13);
            tabPage2.Controls.Add(label8);
            tabPage2.Controls.Add(iconPictureBox9);
            tabPage2.Controls.Add(Disbtn);
            tabPage2.Controls.Add(searchbtn);
            tabPage2.Controls.Add(searchtxt);
            tabPage2.Controls.Add(salgrid);
            tabPage2.Font = new Font("Microsoft Sans Serif", 11F, FontStyle.Bold);
            tabPage2.Location = new Point(4, 4);
            tabPage2.Margin = new Padding(2);
            tabPage2.Name = "tabPage2";
            tabPage2.Padding = new Padding(2);
            tabPage2.Size = new Size(872, 392);
            tabPage2.TabIndex = 1;
            tabPage2.Text = "Search ";
            // 
            // panel8
            // 
            panel8.BackColor = Color.Gray;
            panel8.Location = new Point(254, 70);
            panel8.Name = "panel8";
            panel8.Size = new Size(591, 1);
            panel8.TabIndex = 73;
            // 
            // iconPictureBox10
            // 
            iconPictureBox10.BackColor = Color.FromArgb(51, 51, 76);
            iconPictureBox10.ForeColor = SystemColors.AppWorkspace;
            iconPictureBox10.IconChar = FontAwesome.Sharp.IconChar.Search;
            iconPictureBox10.IconColor = SystemColors.AppWorkspace;
            iconPictureBox10.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconPictureBox10.IconSize = 28;
            iconPictureBox10.Location = new Point(16, 51);
            iconPictureBox10.Name = "iconPictureBox10";
            iconPictureBox10.Size = new Size(29, 28);
            iconPictureBox10.TabIndex = 72;
            iconPictureBox10.TabStop = false;
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Font = new Font("Sitka Banner", 12.2499981F, FontStyle.Bold);
            label13.ForeColor = SystemColors.AppWorkspace;
            label13.Location = new Point(42, 50);
            label13.Margin = new Padding(4, 0, 4, 0);
            label13.Name = "label13";
            label13.Size = new Size(205, 24);
            label13.TabIndex = 71;
            label13.Text = "MembershipID/GuestName";
            // 
            // label8
            // 
            label8.Font = new Font("Sitka Banner", 17F, FontStyle.Bold);
            label8.ForeColor = SystemColors.AppWorkspace;
            label8.Location = new Point(52, 3);
            label8.Name = "label8";
            label8.Size = new Size(232, 38);
            label8.TabIndex = 70;
            label8.Text = "Search Membership";
            // 
            // iconPictureBox9
            // 
            iconPictureBox9.BackColor = Color.FromArgb(51, 51, 76);
            iconPictureBox9.ForeColor = SystemColors.AppWorkspace;
            iconPictureBox9.IconChar = FontAwesome.Sharp.IconChar.UserTie;
            iconPictureBox9.IconColor = SystemColors.AppWorkspace;
            iconPictureBox9.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconPictureBox9.IconSize = 41;
            iconPictureBox9.Location = new Point(5, 3);
            iconPictureBox9.Name = "iconPictureBox9";
            iconPictureBox9.Size = new Size(41, 42);
            iconPictureBox9.TabIndex = 69;
            iconPictureBox9.TabStop = false;
            // 
            // Disbtn
            // 
            Disbtn.BackColor = Color.FromArgb(51, 51, 76);
            Disbtn.Font = new Font("Sitka Banner", 14F, FontStyle.Bold);
            Disbtn.ForeColor = SystemColors.AppWorkspace;
            Disbtn.Location = new Point(630, 88);
            Disbtn.Margin = new Padding(3, 4, 3, 4);
            Disbtn.Name = "Disbtn";
            Disbtn.Size = new Size(215, 37);
            Disbtn.TabIndex = 50;
            Disbtn.Text = "Display all Membership";
            Disbtn.UseVisualStyleBackColor = false;
            Disbtn.Click += Disbtn_Click;
            // 
            // searchbtn
            // 
            searchbtn.BackColor = Color.FromArgb(51, 51, 76);
            searchbtn.Font = new Font("Sitka Banner", 14F, FontStyle.Bold);
            searchbtn.ForeColor = SystemColors.AppWorkspace;
            searchbtn.Location = new Point(366, 88);
            searchbtn.Margin = new Padding(3, 4, 3, 4);
            searchbtn.Name = "searchbtn";
            searchbtn.Size = new Size(222, 37);
            searchbtn.TabIndex = 33;
            searchbtn.Text = "Search Membership";
            searchbtn.UseVisualStyleBackColor = false;
            searchbtn.Click += searchbtn_Click;
            // 
            // searchtxt
            // 
            searchtxt.BackColor = Color.FromArgb(51, 51, 76);
            searchtxt.BorderStyle = BorderStyle.None;
            searchtxt.Font = new Font("Sitka Banner", 12.2499981F, FontStyle.Bold);
            searchtxt.Location = new Point(254, 46);
            searchtxt.Margin = new Padding(3, 4, 3, 4);
            searchtxt.Name = "searchtxt";
            searchtxt.Size = new Size(591, 21);
            searchtxt.TabIndex = 32;
            // 
            // salgrid
            // 
            salgrid.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            salgrid.Dock = DockStyle.Bottom;
            salgrid.Location = new Point(2, 169);
            salgrid.Margin = new Padding(2);
            salgrid.Name = "salgrid";
            salgrid.RowHeadersWidth = 62;
            salgrid.RowTemplate.Height = 33;
            salgrid.ShowCellToolTips = false;
            salgrid.Size = new Size(868, 221);
            salgrid.TabIndex = 30;
            // 
            // tabPage3
            // 
            tabPage3.BackColor = Color.FromArgb(51, 51, 76);
            tabPage3.Controls.Add(panel15);
            tabPage3.Controls.Add(panel14);
            tabPage3.Controls.Add(panel13);
            tabPage3.Controls.Add(label21);
            tabPage3.Controls.Add(panel12);
            tabPage3.Controls.Add(panel10);
            tabPage3.Controls.Add(iconPictureBox20);
            tabPage3.Controls.Add(label20);
            tabPage3.Controls.Add(iconPictureBox19);
            tabPage3.Controls.Add(label19);
            tabPage3.Controls.Add(iconPictureBox18);
            tabPage3.Controls.Add(label18);
            tabPage3.Controls.Add(iconPictureBox17);
            tabPage3.Controls.Add(label17);
            tabPage3.Controls.Add(iconPictureBox16);
            tabPage3.Controls.Add(label5);
            tabPage3.Controls.Add(iconPictureBox15);
            tabPage3.Controls.Add(label16);
            tabPage3.Controls.Add(iconPictureBox14);
            tabPage3.Controls.Add(label15);
            tabPage3.Controls.Add(iconPictureBox13);
            tabPage3.Controls.Add(label14);
            tabPage3.Controls.Add(panel9);
            tabPage3.Controls.Add(iconPictureBox12);
            tabPage3.Controls.Add(label9);
            tabPage3.Controls.Add(label11);
            tabPage3.Controls.Add(iconPictureBox11);
            tabPage3.Controls.Add(GuestID);
            tabPage3.Controls.Add(StartdateTime);
            tabPage3.Controls.Add(Inactive);
            tabPage3.Controls.Add(Active);
            tabPage3.Controls.Add(DurationTextBox);
            tabPage3.Controls.Add(LstName);
            tabPage3.Controls.Add(FName);
            tabPage3.Controls.Add(PriceTextBox);
            tabPage3.Controls.Add(MembershipTypeTextBox);
            tabPage3.Controls.Add(Midtxt);
            tabPage3.Controls.Add(updatebtn);
            tabPage3.Font = new Font("Microsoft Sans Serif", 11F, FontStyle.Bold);
            tabPage3.Location = new Point(4, 4);
            tabPage3.Margin = new Padding(2);
            tabPage3.Name = "tabPage3";
            tabPage3.Size = new Size(872, 392);
            tabPage3.TabIndex = 2;
            tabPage3.Text = "Update Membership";
            tabPage3.Click += tabPage3_Click;
            // 
            // panel15
            // 
            panel15.BackColor = Color.Gray;
            panel15.Location = new Point(630, 258);
            panel15.Name = "panel15";
            panel15.Size = new Size(222, 1);
            panel15.TabIndex = 109;
            // 
            // panel14
            // 
            panel14.BackColor = Color.Gray;
            panel14.Location = new Point(630, 202);
            panel14.Name = "panel14";
            panel14.Size = new Size(222, 1);
            panel14.TabIndex = 108;
            // 
            // panel13
            // 
            panel13.BackColor = Color.Gray;
            panel13.Location = new Point(630, 153);
            panel13.Name = "panel13";
            panel13.Size = new Size(222, 1);
            panel13.TabIndex = 107;
            // 
            // label21
            // 
            label21.Font = new Font("Sitka Banner", 14.2499981F, FontStyle.Bold);
            label21.ForeColor = SystemColors.AppWorkspace;
            label21.Location = new Point(533, 321);
            label21.Margin = new Padding(4, 0, 4, 0);
            label21.Name = "label21";
            label21.Size = new Size(115, 30);
            label21.TabIndex = 106;
            label21.Text = "Status";
            // 
            // panel12
            // 
            panel12.BackColor = Color.Gray;
            panel12.Location = new Point(209, 262);
            panel12.Name = "panel12";
            panel12.Size = new Size(255, 1);
            panel12.TabIndex = 64;
            // 
            // panel10
            // 
            panel10.BackColor = Color.Gray;
            panel10.Location = new Point(209, 154);
            panel10.Name = "panel10";
            panel10.Size = new Size(255, 1);
            panel10.TabIndex = 105;
            // 
            // iconPictureBox20
            // 
            iconPictureBox20.BackColor = Color.FromArgb(51, 51, 76);
            iconPictureBox20.ForeColor = SystemColors.AppWorkspace;
            iconPictureBox20.IconChar = FontAwesome.Sharp.IconChar.Comment;
            iconPictureBox20.IconColor = SystemColors.AppWorkspace;
            iconPictureBox20.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconPictureBox20.IconSize = 53;
            iconPictureBox20.Location = new Point(482, 291);
            iconPictureBox20.Name = "iconPictureBox20";
            iconPictureBox20.Size = new Size(53, 60);
            iconPictureBox20.TabIndex = 104;
            iconPictureBox20.TabStop = false;
            // 
            // label20
            // 
            label20.Font = new Font("Sitka Banner", 14.2499981F, FontStyle.Bold);
            label20.ForeColor = SystemColors.AppWorkspace;
            label20.Location = new Point(533, 291);
            label20.Margin = new Padding(4, 0, 4, 0);
            label20.Name = "label20";
            label20.Size = new Size(115, 30);
            label20.TabIndex = 103;
            label20.Text = "Membership";
            // 
            // iconPictureBox19
            // 
            iconPictureBox19.BackColor = Color.FromArgb(51, 51, 76);
            iconPictureBox19.ForeColor = SystemColors.AppWorkspace;
            iconPictureBox19.IconChar = FontAwesome.Sharp.IconChar.Clock;
            iconPictureBox19.IconColor = SystemColors.AppWorkspace;
            iconPictureBox19.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconPictureBox19.Location = new Point(482, 231);
            iconPictureBox19.Name = "iconPictureBox19";
            iconPictureBox19.Size = new Size(32, 32);
            iconPictureBox19.TabIndex = 102;
            iconPictureBox19.TabStop = false;
            iconPictureBox19.Click += iconPictureBox19_Click;
            // 
            // label19
            // 
            label19.AutoSize = true;
            label19.Font = new Font("Sitka Banner", 14.2499981F, FontStyle.Bold);
            label19.ForeColor = SystemColors.AppWorkspace;
            label19.Location = new Point(508, 231);
            label19.Margin = new Padding(4, 0, 4, 0);
            label19.Name = "label19";
            label19.Size = new Size(81, 28);
            label19.TabIndex = 101;
            label19.Text = "Duration";
            // 
            // iconPictureBox18
            // 
            iconPictureBox18.BackColor = Color.FromArgb(51, 51, 76);
            iconPictureBox18.ForeColor = SystemColors.AppWorkspace;
            iconPictureBox18.IconChar = FontAwesome.Sharp.IconChar.UserEdit;
            iconPictureBox18.IconColor = SystemColors.AppWorkspace;
            iconPictureBox18.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconPictureBox18.Location = new Point(483, 127);
            iconPictureBox18.Name = "iconPictureBox18";
            iconPictureBox18.Size = new Size(32, 32);
            iconPictureBox18.TabIndex = 100;
            iconPictureBox18.TabStop = false;
            // 
            // label18
            // 
            label18.AutoSize = true;
            label18.Font = new Font("Sitka Banner", 14.2499981F, FontStyle.Bold);
            label18.ForeColor = SystemColors.AppWorkspace;
            label18.Location = new Point(511, 127);
            label18.Margin = new Padding(4, 0, 4, 0);
            label18.Name = "label18";
            label18.Size = new Size(94, 28);
            label18.TabIndex = 99;
            label18.Text = "Last Name";
            // 
            // iconPictureBox17
            // 
            iconPictureBox17.BackColor = Color.FromArgb(51, 51, 76);
            iconPictureBox17.ForeColor = SystemColors.AppWorkspace;
            iconPictureBox17.IconChar = FontAwesome.Sharp.IconChar.Search;
            iconPictureBox17.IconColor = SystemColors.AppWorkspace;
            iconPictureBox17.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconPictureBox17.IconSize = 29;
            iconPictureBox17.Location = new Point(485, 181);
            iconPictureBox17.Name = "iconPictureBox17";
            iconPictureBox17.Size = new Size(29, 29);
            iconPictureBox17.TabIndex = 98;
            iconPictureBox17.TabStop = false;
            // 
            // label17
            // 
            label17.AutoSize = true;
            label17.Font = new Font("Sitka Banner", 14.2499981F, FontStyle.Bold);
            label17.ForeColor = SystemColors.AppWorkspace;
            label17.Location = new Point(511, 179);
            label17.Margin = new Padding(4, 0, 4, 0);
            label17.Name = "label17";
            label17.Size = new Size(78, 28);
            label17.TabIndex = 97;
            label17.Text = "Guest ID";
            // 
            // iconPictureBox16
            // 
            iconPictureBox16.BackColor = Color.FromArgb(51, 51, 76);
            iconPictureBox16.ForeColor = SystemColors.AppWorkspace;
            iconPictureBox16.IconChar = FontAwesome.Sharp.IconChar.CalendarAlt;
            iconPictureBox16.IconColor = SystemColors.AppWorkspace;
            iconPictureBox16.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconPictureBox16.Location = new Point(7, 294);
            iconPictureBox16.Name = "iconPictureBox16";
            iconPictureBox16.Size = new Size(32, 32);
            iconPictureBox16.TabIndex = 96;
            iconPictureBox16.TabStop = false;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Sitka Banner", 14.2499981F, FontStyle.Bold);
            label5.ForeColor = SystemColors.AppWorkspace;
            label5.Location = new Point(42, 301);
            label5.Margin = new Padding(4, 0, 4, 0);
            label5.Name = "label5";
            label5.Size = new Size(90, 28);
            label5.TabIndex = 95;
            label5.Text = "Start Date";
            // 
            // iconPictureBox15
            // 
            iconPictureBox15.BackColor = Color.FromArgb(51, 51, 76);
            iconPictureBox15.ForeColor = SystemColors.AppWorkspace;
            iconPictureBox15.IconChar = FontAwesome.Sharp.IconChar.MoneyBillWaveAlt;
            iconPictureBox15.IconColor = SystemColors.AppWorkspace;
            iconPictureBox15.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconPictureBox15.Location = new Point(7, 235);
            iconPictureBox15.Name = "iconPictureBox15";
            iconPictureBox15.Size = new Size(32, 32);
            iconPictureBox15.TabIndex = 94;
            iconPictureBox15.TabStop = false;
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.Font = new Font("Sitka Banner", 14.2499981F, FontStyle.Bold);
            label16.ForeColor = SystemColors.AppWorkspace;
            label16.Location = new Point(42, 237);
            label16.Margin = new Padding(4, 0, 4, 0);
            label16.Name = "label16";
            label16.Size = new Size(73, 28);
            label16.TabIndex = 93;
            label16.Text = "Amount";
            // 
            // iconPictureBox14
            // 
            iconPictureBox14.BackColor = Color.FromArgb(51, 51, 76);
            iconPictureBox14.ForeColor = SystemColors.AppWorkspace;
            iconPictureBox14.IconChar = FontAwesome.Sharp.IconChar.UserPlus;
            iconPictureBox14.IconColor = SystemColors.AppWorkspace;
            iconPictureBox14.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconPictureBox14.Location = new Point(9, 175);
            iconPictureBox14.Name = "iconPictureBox14";
            iconPictureBox14.Size = new Size(32, 32);
            iconPictureBox14.TabIndex = 92;
            iconPictureBox14.TabStop = false;
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.Font = new Font("Sitka Banner", 14.2499981F, FontStyle.Bold);
            label15.ForeColor = SystemColors.AppWorkspace;
            label15.Location = new Point(42, 179);
            label15.Margin = new Padding(4, 0, 4, 0);
            label15.Name = "label15";
            label15.Size = new Size(151, 28);
            label15.TabIndex = 91;
            label15.Text = "Membership Type";
            // 
            // iconPictureBox13
            // 
            iconPictureBox13.BackColor = Color.FromArgb(51, 51, 76);
            iconPictureBox13.ForeColor = SystemColors.AppWorkspace;
            iconPictureBox13.IconChar = FontAwesome.Sharp.IconChar.UserEdit;
            iconPictureBox13.IconColor = SystemColors.AppWorkspace;
            iconPictureBox13.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconPictureBox13.Location = new Point(7, 123);
            iconPictureBox13.Name = "iconPictureBox13";
            iconPictureBox13.Size = new Size(32, 32);
            iconPictureBox13.TabIndex = 90;
            iconPictureBox13.TabStop = false;
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Font = new Font("Sitka Banner", 14.2499981F, FontStyle.Bold);
            label14.ForeColor = SystemColors.AppWorkspace;
            label14.Location = new Point(42, 130);
            label14.Margin = new Padding(4, 0, 4, 0);
            label14.Name = "label14";
            label14.Size = new Size(98, 28);
            label14.TabIndex = 89;
            label14.Text = "First Name";
            // 
            // panel9
            // 
            panel9.BackColor = Color.Gray;
            panel9.Location = new Point(209, 83);
            panel9.Name = "panel9";
            panel9.Size = new Size(645, 1);
            panel9.TabIndex = 88;
            // 
            // iconPictureBox12
            // 
            iconPictureBox12.BackColor = Color.FromArgb(51, 51, 76);
            iconPictureBox12.ForeColor = SystemColors.AppWorkspace;
            iconPictureBox12.IconChar = FontAwesome.Sharp.IconChar.Search;
            iconPictureBox12.IconColor = SystemColors.AppWorkspace;
            iconPictureBox12.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconPictureBox12.IconSize = 28;
            iconPictureBox12.Location = new Point(42, 60);
            iconPictureBox12.Name = "iconPictureBox12";
            iconPictureBox12.Size = new Size(29, 28);
            iconPictureBox12.TabIndex = 87;
            iconPictureBox12.TabStop = false;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Sitka Banner", 12.2499981F, FontStyle.Bold);
            label9.ForeColor = SystemColors.AppWorkspace;
            label9.Location = new Point(68, 60);
            label9.Margin = new Padding(4, 0, 4, 0);
            label9.Name = "label9";
            label9.Size = new Size(116, 24);
            label9.TabIndex = 86;
            label9.Text = "MembershipID";
            // 
            // label11
            // 
            label11.Font = new Font("Sitka Banner", 17F, FontStyle.Bold);
            label11.ForeColor = SystemColors.AppWorkspace;
            label11.Location = new Point(53, 5);
            label11.Name = "label11";
            label11.Size = new Size(232, 38);
            label11.TabIndex = 85;
            label11.Text = "Update Membership";
            // 
            // iconPictureBox11
            // 
            iconPictureBox11.BackColor = Color.FromArgb(51, 51, 76);
            iconPictureBox11.ForeColor = SystemColors.AppWorkspace;
            iconPictureBox11.IconChar = FontAwesome.Sharp.IconChar.UserTie;
            iconPictureBox11.IconColor = SystemColors.AppWorkspace;
            iconPictureBox11.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconPictureBox11.IconSize = 41;
            iconPictureBox11.Location = new Point(6, 5);
            iconPictureBox11.Name = "iconPictureBox11";
            iconPictureBox11.Size = new Size(41, 42);
            iconPictureBox11.TabIndex = 84;
            iconPictureBox11.TabStop = false;
            // 
            // GuestID
            // 
            GuestID.BackColor = Color.FromArgb(51, 51, 76);
            GuestID.BorderStyle = BorderStyle.None;
            GuestID.Font = new Font("Sitka Banner", 12.2499981F, FontStyle.Bold);
            GuestID.ForeColor = SystemColors.AppWorkspace;
            GuestID.Location = new Point(629, 179);
            GuestID.Margin = new Padding(3, 4, 3, 4);
            GuestID.Name = "GuestID";
            GuestID.Size = new Size(225, 21);
            GuestID.TabIndex = 83;
            // 
            // StartdateTime
            // 
            StartdateTime.Location = new Point(209, 303);
            StartdateTime.Margin = new Padding(2);
            StartdateTime.Name = "StartdateTime";
            StartdateTime.Size = new Size(257, 24);
            StartdateTime.TabIndex = 80;
            // 
            // Active
            // 
            Active.AutoSize = true;
            Active.Font = new Font("Sitka Banner", 12.2499981F, FontStyle.Bold);
            Active.ForeColor = SystemColors.AppWorkspace;
            Active.Location = new Point(693, 296);
            Active.Margin = new Padding(2);
            Active.Name = "Active";
            Active.Size = new Size(72, 28);
            Active.TabIndex = 78;
            Active.TabStop = true;
            Active.Text = "Active";
            Active.UseVisualStyleBackColor = true;
            // 
            // DurationTextBox
            // 
            DurationTextBox.BackColor = Color.FromArgb(51, 51, 76);
            DurationTextBox.BorderStyle = BorderStyle.None;
            DurationTextBox.Font = new Font("Sitka Banner", 12.2499981F, FontStyle.Bold);
            DurationTextBox.ForeColor = SystemColors.AppWorkspace;
            DurationTextBox.Location = new Point(630, 236);
            DurationTextBox.Margin = new Padding(2);
            DurationTextBox.Name = "DurationTextBox";
            DurationTextBox.Size = new Size(222, 21);
            DurationTextBox.TabIndex = 74;
            // 
            // LstName
            // 
            LstName.BackColor = Color.FromArgb(51, 51, 76);
            LstName.BorderStyle = BorderStyle.None;
            LstName.Font = new Font("Sitka Banner", 12.2499981F, FontStyle.Bold);
            LstName.ForeColor = SystemColors.AppWorkspace;
            LstName.Location = new Point(630, 131);
            LstName.Margin = new Padding(2);
            LstName.Name = "LstName";
            LstName.Size = new Size(222, 21);
            LstName.TabIndex = 72;
            // 
            // FName
            // 
            FName.BackColor = Color.FromArgb(51, 51, 76);
            FName.BorderStyle = BorderStyle.None;
            FName.Font = new Font("Sitka Banner", 12.2499981F, FontStyle.Bold);
            FName.ForeColor = SystemColors.AppWorkspace;
            FName.Location = new Point(209, 131);
            FName.Margin = new Padding(2);
            FName.Name = "FName";
            FName.Size = new Size(257, 21);
            FName.TabIndex = 70;
            // 
            // PriceTextBox
            // 
            PriceTextBox.BackColor = Color.FromArgb(51, 51, 76);
            PriceTextBox.BorderStyle = BorderStyle.None;
            PriceTextBox.Font = new Font("Sitka Banner", 12.2499981F, FontStyle.Bold);
            PriceTextBox.ForeColor = SystemColors.AppWorkspace;
            PriceTextBox.Location = new Point(209, 240);
            PriceTextBox.Margin = new Padding(2);
            PriceTextBox.Name = "PriceTextBox";
            PriceTextBox.Size = new Size(257, 21);
            PriceTextBox.TabIndex = 69;
            // 
            // MembershipTypeTextBox
            // 
            MembershipTypeTextBox.BackColor = Color.FromArgb(51, 51, 76);
            MembershipTypeTextBox.FlatStyle = FlatStyle.Flat;
            MembershipTypeTextBox.Font = new Font("Sitka Banner", 12.2499981F, FontStyle.Bold);
            MembershipTypeTextBox.ForeColor = SystemColors.AppWorkspace;
            MembershipTypeTextBox.FormattingEnabled = true;
            MembershipTypeTextBox.Items.AddRange(new object[] { "Basic", "Standard", "Premium" });
            MembershipTypeTextBox.Location = new Point(209, 181);
            MembershipTypeTextBox.Name = "MembershipTypeTextBox";
            MembershipTypeTextBox.Size = new Size(257, 31);
            MembershipTypeTextBox.TabIndex = 67;
            MembershipTypeTextBox.SelectedIndexChanged += MembershipTypeTextBox_SelectedIndexChanged;
            // 
            // updatebtn
            // 
            updatebtn.BackColor = Color.FromArgb(51, 51, 76);
            updatebtn.Font = new Font("Sitka Banner", 14F, FontStyle.Bold);
            updatebtn.ForeColor = SystemColors.AppWorkspace;
            updatebtn.Location = new Point(655, 339);
            updatebtn.Margin = new Padding(3, 4, 3, 4);
            updatebtn.Name = "updatebtn";
            updatebtn.Size = new Size(209, 38);
            updatebtn.TabIndex = 46;
            updatebtn.Text = "Update Membership";
            updatebtn.UseVisualStyleBackColor = false;
            updatebtn.Click += updatebtn_Click;
            // 
            // Membership
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(51, 51, 76);
            ClientSize = new Size(880, 420);
            Controls.Add(tabControl1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "Membership";
            Text = "Membership";
            ((System.ComponentModel.ISupportInitialize)iconPictureBox5).EndInit();
            tabControl1.ResumeLayout(false);
            tabPage1.ResumeLayout(false);
            tabPage1.PerformLayout();
            panel5.ResumeLayout(false);
            panel3.ResumeLayout(false);
            panel6.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)iconPictureBox8).EndInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox6).EndInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox4).EndInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox7).EndInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox3).EndInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox1).EndInit();
            tabPage2.ResumeLayout(false);
            tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox10).EndInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox9).EndInit();
            ((System.ComponentModel.ISupportInitialize)salgrid).EndInit();
            tabPage3.ResumeLayout(false);
            tabPage3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox20).EndInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox19).EndInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox18).EndInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox17).EndInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox16).EndInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox15).EndInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox14).EndInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox13).EndInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox12).EndInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox11).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private RadioButton Inactive;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox5;
        private TextBox Midtxt;
        private TabControl tabControl1;
        private TabPage tabPage1;
        private Panel panel5;
        private Panel panel7;
        private Panel panel3;
        private Panel panel4;
        private Panel panel2;
        private Panel panel1;
        private Panel panel6;
        private Panel panel11;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox8;
        private Label label3;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox6;
        private Label label2;
        private Label label12;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox4;
        private Label label10;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox7;
        private Label label7;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox3;
        private Label label6;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox2;
        private Label label1;
        private Label label4;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox1;
        private TextBox Cnic;
        private DateTimePicker startdate;
        private TextBox Durationtxt;
        private TextBox LastName;
        private TextBox FirstName;
        private TextBox pricetxt;
        private ComboBox Mtypecombo;
        private Button addmembtn;
        private TabPage tabPage2;
        private Button Disbtn;
        private Button searchbtn;
        private TextBox searchtxt;
        private DataGridView salgrid;
        private TabPage tabPage3;
        private TextBox GuestID;
        private DateTimePicker StartdateTime;
        private RadioButton Active;
        private TextBox DurationTextBox;
        private TextBox LstName;
        private TextBox FName;
        private TextBox PriceTextBox;
        private ComboBox MembershipTypeTextBox;
        private Button updatebtn;
        private Label label13;
        private Label label8;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox9;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox10;
        private Panel panel8;
        private Label label11;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox11;
        private Panel panel9;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox12;
        private Label label9;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox16;
        private Label label5;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox15;
        private Label label16;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox14;
        private Label label15;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox13;
        private Label label14;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox17;
        private Label label17;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox19;
        private Label label19;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox18;
        private Label label18;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox20;
        private Label label20;
        private Panel panel12;
        private Panel panel10;
        private Label label21;
        private Panel panel13;
        private Panel panel15;
        private Panel panel14;
    }
}
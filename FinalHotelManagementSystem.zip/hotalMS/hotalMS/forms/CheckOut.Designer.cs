﻿namespace hotalMS.forms
{
    partial class CheckOut
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Upbtn = new Button();
            Displaybtn = new Button();
            VacantRadioButton = new RadioButton();
            OccupiedRadioButton = new RadioButton();
            R_idsearch = new TextBox();
            R_datagrid = new DataGridView();
            iconPictureBox1 = new FontAwesome.Sharp.IconPictureBox();
            label2 = new Label();
            searchbtn = new Button();
            checktext = new ComboBox();
            iconPictureBox10 = new FontAwesome.Sharp.IconPictureBox();
            panel17 = new Panel();
            panel1 = new Panel();
            panel2 = new Panel();
            panel3 = new Panel();
            panel4 = new Panel();
            ((System.ComponentModel.ISupportInitialize)R_datagrid).BeginInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox10).BeginInit();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // Upbtn
            // 
            Upbtn.BackColor = Color.FromArgb(51, 51, 76);
            Upbtn.Font = new Font("Sitka Banner", 11F, FontStyle.Bold);
            Upbtn.ForeColor = SystemColors.AppWorkspace;
            Upbtn.Location = new Point(530, 129);
            Upbtn.Margin = new Padding(3, 4, 3, 4);
            Upbtn.Name = "Upbtn";
            Upbtn.RightToLeft = RightToLeft.No;
            Upbtn.Size = new Size(156, 44);
            Upbtn.TabIndex = 80;
            Upbtn.Text = "Update Room Status";
            Upbtn.UseVisualStyleBackColor = false;
            Upbtn.Click += Upbtn_Click;
            // 
            // Displaybtn
            // 
            Displaybtn.BackColor = Color.FromArgb(51, 51, 76);
            Displaybtn.Font = new Font("Sitka Banner", 14F, FontStyle.Bold);
            Displaybtn.ForeColor = SystemColors.AppWorkspace;
            Displaybtn.Location = new Point(705, 129);
            Displaybtn.Margin = new Padding(3, 4, 3, 4);
            Displaybtn.Name = "Displaybtn";
            Displaybtn.RightToLeft = RightToLeft.No;
            Displaybtn.Size = new Size(163, 44);
            Displaybtn.TabIndex = 79;
            Displaybtn.Text = "Display RoomInfo";
            Displaybtn.UseVisualStyleBackColor = false;
            Displaybtn.Click += Displaybtn_Click;
            // 
            // VacantRadioButton
            // 
            VacantRadioButton.AutoSize = true;
            VacantRadioButton.Font = new Font("Sitka Banner", 14.2499981F, FontStyle.Bold);
            VacantRadioButton.ForeColor = SystemColors.AppWorkspace;
            VacantRadioButton.Location = new Point(53, 129);
            VacantRadioButton.Margin = new Padding(3, 4, 3, 4);
            VacantRadioButton.Name = "VacantRadioButton";
            VacantRadioButton.Size = new Size(82, 32);
            VacantRadioButton.TabIndex = 78;
            VacantRadioButton.TabStop = true;
            VacantRadioButton.Text = "Vacant";
            VacantRadioButton.UseVisualStyleBackColor = true;
            // 
            // OccupiedRadioButton
            // 
            OccupiedRadioButton.AutoSize = true;
            OccupiedRadioButton.Font = new Font("Sitka Banner", 14.2499981F, FontStyle.Bold);
            OccupiedRadioButton.ForeColor = SystemColors.AppWorkspace;
            OccupiedRadioButton.Location = new Point(173, 129);
            OccupiedRadioButton.Margin = new Padding(3, 4, 3, 4);
            OccupiedRadioButton.Name = "OccupiedRadioButton";
            OccupiedRadioButton.Size = new Size(101, 32);
            OccupiedRadioButton.TabIndex = 77;
            OccupiedRadioButton.TabStop = true;
            OccupiedRadioButton.Text = "Occupied";
            OccupiedRadioButton.UseVisualStyleBackColor = true;
            // 
            // R_idsearch
            // 
            R_idsearch.BackColor = Color.FromArgb(51, 51, 76);
            R_idsearch.BorderStyle = BorderStyle.None;
            R_idsearch.Font = new Font("Sitka Banner", 14.2499981F, FontStyle.Bold);
            R_idsearch.ForeColor = SystemColors.AppWorkspace;
            R_idsearch.Location = new Point(324, 80);
            R_idsearch.Margin = new Padding(3, 4, 3, 4);
            R_idsearch.Multiline = true;
            R_idsearch.Name = "R_idsearch";
            R_idsearch.Size = new Size(409, 28);
            R_idsearch.TabIndex = 76;
            R_idsearch.TextChanged += R_idsearch_TextChanged;
            // 
            // R_datagrid
            // 
            R_datagrid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            R_datagrid.BackgroundColor = Color.FromArgb(204, 204, 204);
            R_datagrid.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            R_datagrid.Dock = DockStyle.Bottom;
            R_datagrid.Location = new Point(0, 212);
            R_datagrid.Margin = new Padding(3, 4, 3, 4);
            R_datagrid.Name = "R_datagrid";
            R_datagrid.RowHeadersWidth = 62;
            R_datagrid.Size = new Size(880, 208);
            R_datagrid.TabIndex = 74;
            // 
            // iconPictureBox1
            // 
            iconPictureBox1.BackColor = Color.FromArgb(51, 51, 76);
            iconPictureBox1.ForeColor = SystemColors.AppWorkspace;
            iconPictureBox1.IconChar = FontAwesome.Sharp.IconChar.SignLanguage;
            iconPictureBox1.IconColor = SystemColors.AppWorkspace;
            iconPictureBox1.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconPictureBox1.IconSize = 39;
            iconPictureBox1.Location = new Point(8, 12);
            iconPictureBox1.Name = "iconPictureBox1";
            iconPictureBox1.Size = new Size(39, 46);
            iconPictureBox1.TabIndex = 83;
            iconPictureBox1.TabStop = false;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Sitka Banner", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.ForeColor = Color.FromArgb(204, 204, 204);
            label2.Location = new Point(53, 12);
            label2.Name = "label2";
            label2.Size = new Size(490, 35);
            label2.TabIndex = 82;
            label2.Text = "\"Checking out from the hotel, memories in tow.\"";
            // 
            // searchbtn
            // 
            searchbtn.BackColor = Color.FromArgb(51, 51, 76);
            searchbtn.Font = new Font("Sitka Banner", 14F, FontStyle.Bold);
            searchbtn.ForeColor = SystemColors.AppWorkspace;
            searchbtn.Location = new Point(338, 129);
            searchbtn.Margin = new Padding(3, 4, 3, 4);
            searchbtn.Name = "searchbtn";
            searchbtn.RightToLeft = RightToLeft.No;
            searchbtn.Size = new Size(176, 44);
            searchbtn.TabIndex = 84;
            searchbtn.Text = "Search Room";
            searchbtn.UseVisualStyleBackColor = false;
            searchbtn.Click += searchbtn_Click;
            // 
            // checktext
            // 
            checktext.BackColor = Color.FromArgb(51, 51, 76);
            checktext.FlatStyle = FlatStyle.Flat;
            checktext.Font = new Font("Sitka Banner", 11F, FontStyle.Bold);
            checktext.ForeColor = SystemColors.AppWorkspace;
            checktext.FormattingEnabled = true;
            checktext.Items.AddRange(new object[] { "SearchByRoomID", "SearchByRoomNo" });
            checktext.Location = new Point(53, 80);
            checktext.Name = "checktext";
            checktext.Size = new Size(229, 29);
            checktext.TabIndex = 86;
            checktext.Text = "Select the service search criteria";
            // 
            // iconPictureBox10
            // 
            iconPictureBox10.BackColor = Color.FromArgb(51, 51, 76);
            iconPictureBox10.ForeColor = SystemColors.AppWorkspace;
            iconPictureBox10.IconChar = FontAwesome.Sharp.IconChar.Search;
            iconPictureBox10.IconColor = SystemColors.AppWorkspace;
            iconPictureBox10.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconPictureBox10.IconSize = 28;
            iconPictureBox10.Location = new Point(13, 80);
            iconPictureBox10.Name = "iconPictureBox10";
            iconPictureBox10.Size = new Size(29, 28);
            iconPictureBox10.TabIndex = 85;
            iconPictureBox10.TabStop = false;
            // 
            // panel17
            // 
            panel17.BackColor = Color.Gray;
            panel17.Location = new Point(324, 108);
            panel17.Name = "panel17";
            panel17.Size = new Size(409, 1);
            panel17.TabIndex = 88;
            // 
            // panel1
            // 
            panel1.BackColor = SystemColors.ButtonFace;
            panel1.Controls.Add(panel2);
            panel1.Location = new Point(0, -4);
            panel1.Name = "panel1";
            panel1.Size = new Size(880, 10);
            panel1.TabIndex = 89;
            // 
            // panel2
            // 
            panel2.BackColor = SystemColors.ButtonFace;
            panel2.Location = new Point(0, 0);
            panel2.Name = "panel2";
            panel2.Size = new Size(880, 5);
            panel2.TabIndex = 90;
            // 
            // panel3
            // 
            panel3.BackColor = SystemColors.ButtonFace;
            panel3.Dock = DockStyle.Left;
            panel3.Location = new Point(0, 0);
            panel3.Name = "panel3";
            panel3.Size = new Size(5, 212);
            panel3.TabIndex = 90;
            // 
            // panel4
            // 
            panel4.BackColor = SystemColors.ButtonFace;
            panel4.Dock = DockStyle.Right;
            panel4.Location = new Point(875, 0);
            panel4.Name = "panel4";
            panel4.Size = new Size(5, 212);
            panel4.TabIndex = 91;
            // 
            // CheckOut
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(51, 51, 76);
            ClientSize = new Size(880, 420);
            Controls.Add(panel4);
            Controls.Add(panel3);
            Controls.Add(panel1);
            Controls.Add(panel17);
            Controls.Add(checktext);
            Controls.Add(iconPictureBox10);
            Controls.Add(searchbtn);
            Controls.Add(iconPictureBox1);
            Controls.Add(label2);
            Controls.Add(Upbtn);
            Controls.Add(Displaybtn);
            Controls.Add(VacantRadioButton);
            Controls.Add(OccupiedRadioButton);
            Controls.Add(R_idsearch);
            Controls.Add(R_datagrid);
            FormBorderStyle = FormBorderStyle.None;
            Name = "CheckOut";
            Text = "CheckOut";
            ((System.ComponentModel.ISupportInitialize)R_datagrid).EndInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox10).EndInit();
            panel1.ResumeLayout(false);
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Button Upbtn;
        private Button Displaybtn;
        private RadioButton VacantRadioButton;
        private RadioButton OccupiedRadioButton;
        private TextBox R_idsearch;
        private DataGridView R_datagrid;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox1;
        private Label label2;
        private Button searchbtn;
        private ComboBox checktext;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox10;
        private Panel panel17;
        private Panel panel1;
        private Panel panel2;
        private Panel panel3;
        private Panel panel4;
    }
}
﻿namespace hotalMS.forms
{
    partial class ViewDetails
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            checktext = new ComboBox();
            iconPictureBox10 = new FontAwesome.Sharp.IconPictureBox();
            detailgrid = new DataGridView();
            iconPictureBox1 = new FontAwesome.Sharp.IconPictureBox();
            label2 = new Label();
            panel4 = new Panel();
            panel1 = new Panel();
            panel3 = new Panel();
            panel2 = new Panel();
            searchbtn = new Button();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox10).BeginInit();
            ((System.ComponentModel.ISupportInitialize)detailgrid).BeginInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox1).BeginInit();
            panel4.SuspendLayout();
            SuspendLayout();
            // 
            // checktext
            // 
            checktext.BackColor = Color.FromArgb(51, 51, 76);
            checktext.FlatStyle = FlatStyle.Flat;
            checktext.Font = new Font("Sitka Banner", 11F, FontStyle.Bold);
            checktext.ForeColor = SystemColors.AppWorkspace;
            checktext.FormattingEnabled = true;
            checktext.Items.AddRange(new object[] { "GuestInfo", "ReservationInfo", "RoomInfo", "MembershipInfo" });
            checktext.Location = new Point(54, 82);
            checktext.Name = "checktext";
            checktext.Size = new Size(518, 29);
            checktext.TabIndex = 88;
            checktext.Text = "Select the Info ,wants to View";
            // 
            // iconPictureBox10
            // 
            iconPictureBox10.BackColor = Color.FromArgb(51, 51, 76);
            iconPictureBox10.ForeColor = SystemColors.AppWorkspace;
            iconPictureBox10.IconChar = FontAwesome.Sharp.IconChar.Search;
            iconPictureBox10.IconColor = SystemColors.AppWorkspace;
            iconPictureBox10.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconPictureBox10.IconSize = 28;
            iconPictureBox10.Location = new Point(14, 82);
            iconPictureBox10.Name = "iconPictureBox10";
            iconPictureBox10.Size = new Size(29, 28);
            iconPictureBox10.TabIndex = 87;
            iconPictureBox10.TabStop = false;
            // 
            // detailgrid
            // 
            detailgrid.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            detailgrid.Dock = DockStyle.Bottom;
            detailgrid.Location = new Point(0, 149);
            detailgrid.Name = "detailgrid";
            detailgrid.Size = new Size(880, 271);
            detailgrid.TabIndex = 91;
            // 
            // iconPictureBox1
            // 
            iconPictureBox1.BackColor = Color.FromArgb(51, 51, 76);
            iconPictureBox1.ForeColor = SystemColors.AppWorkspace;
            iconPictureBox1.IconChar = FontAwesome.Sharp.IconChar.Sketch;
            iconPictureBox1.IconColor = SystemColors.AppWorkspace;
            iconPictureBox1.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconPictureBox1.IconSize = 39;
            iconPictureBox1.Location = new Point(19, 19);
            iconPictureBox1.Name = "iconPictureBox1";
            iconPictureBox1.Size = new Size(39, 46);
            iconPictureBox1.TabIndex = 93;
            iconPictureBox1.TabStop = false;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Sitka Banner", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.ForeColor = Color.FromArgb(204, 204, 204);
            label2.Location = new Point(54, 19);
            label2.Name = "label2";
            label2.Size = new Size(185, 35);
            label2.TabIndex = 92;
            label2.Text = "ViewInfromation";
            // 
            // panel4
            // 
            panel4.BackColor = SystemColors.ButtonFace;
            panel4.Controls.Add(panel1);
            panel4.Dock = DockStyle.Right;
            panel4.Location = new Point(875, 0);
            panel4.Name = "panel4";
            panel4.Size = new Size(5, 149);
            panel4.TabIndex = 94;
            // 
            // panel1
            // 
            panel1.BackColor = SystemColors.ButtonFace;
            panel1.Dock = DockStyle.Right;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(5, 149);
            panel1.TabIndex = 92;
            // 
            // panel3
            // 
            panel3.BackColor = SystemColors.ButtonFace;
            panel3.Dock = DockStyle.Left;
            panel3.Location = new Point(0, 0);
            panel3.Name = "panel3";
            panel3.Size = new Size(5, 149);
            panel3.TabIndex = 95;
            // 
            // panel2
            // 
            panel2.BackColor = SystemColors.ButtonFace;
            panel2.Dock = DockStyle.Top;
            panel2.Location = new Point(5, 0);
            panel2.Name = "panel2";
            panel2.Size = new Size(870, 5);
            panel2.TabIndex = 96;
            // 
            // searchbtn
            // 
            searchbtn.BackColor = Color.FromArgb(51, 51, 76);
            searchbtn.FlatStyle = FlatStyle.Flat;
            searchbtn.Font = new Font("Sitka Banner", 14F, FontStyle.Bold);
            searchbtn.ForeColor = SystemColors.AppWorkspace;
            searchbtn.Location = new Point(629, 82);
            searchbtn.Margin = new Padding(3, 4, 3, 4);
            searchbtn.Name = "searchbtn";
            searchbtn.RightToLeft = RightToLeft.No;
            searchbtn.Size = new Size(222, 39);
            searchbtn.TabIndex = 97;
            searchbtn.Text = "Search Info";
            searchbtn.UseVisualStyleBackColor = false;
            searchbtn.Click += searchbtn_Click;
            // 
            // ViewDetails
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(51, 51, 76);
            ClientSize = new Size(880, 420);
            Controls.Add(searchbtn);
            Controls.Add(panel2);
            Controls.Add(panel3);
            Controls.Add(panel4);
            Controls.Add(iconPictureBox1);
            Controls.Add(label2);
            Controls.Add(detailgrid);
            Controls.Add(checktext);
            Controls.Add(iconPictureBox10);
            FormBorderStyle = FormBorderStyle.None;
            Name = "ViewDetails";
            Text = "ViewDetails";
            ((System.ComponentModel.ISupportInitialize)iconPictureBox10).EndInit();
            ((System.ComponentModel.ISupportInitialize)detailgrid).EndInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox1).EndInit();
            panel4.ResumeLayout(false);
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private ComboBox checktext;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox10;
        private DataGridView detailgrid;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox1;
        private Label label2;
        private Panel panel4;
        private Panel panel1;
        private Panel panel3;
        private Panel panel2;
        private Button searchbtn;
    }
}
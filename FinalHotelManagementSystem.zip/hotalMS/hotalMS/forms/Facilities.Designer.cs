﻿
namespace DBMS_HMS
{
    partial class Facilities
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel1 = new Panel();
            iconPictureBox1 = new FontAwesome.Sharp.IconPictureBox();
            groupBoxFacilities = new GroupBox();
            HorseRiding = new CheckBox();
            GameRoom = new CheckBox();
            Spa = new CheckBox();
            Gym = new CheckBox();
            Lobby = new CheckBox();
            SwimmingPool = new CheckBox();
            Res_addGbtn = new Button();
            label1 = new Label();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox1).BeginInit();
            groupBoxFacilities.SuspendLayout();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.FromArgb(51, 51, 76);
            panel1.Controls.Add(iconPictureBox1);
            panel1.Controls.Add(groupBoxFacilities);
            panel1.Controls.Add(Res_addGbtn);
            panel1.Controls.Add(label1);
            panel1.Location = new Point(9, 9);
            panel1.Margin = new Padding(2);
            panel1.Name = "panel1";
            panel1.Size = new Size(368, 442);
            panel1.TabIndex = 0;
            // 
            // iconPictureBox1
            // 
            iconPictureBox1.BackColor = Color.FromArgb(51, 51, 76);
            iconPictureBox1.ForeColor = SystemColors.ControlText;
            iconPictureBox1.IconChar = FontAwesome.Sharp.IconChar.None;
            iconPictureBox1.IconColor = SystemColors.ControlText;
            iconPictureBox1.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconPictureBox1.Location = new Point(23, 26);
            iconPictureBox1.Name = "iconPictureBox1";
            iconPictureBox1.Size = new Size(32, 32);
            iconPictureBox1.TabIndex = 85;
            iconPictureBox1.TabStop = false;
            iconPictureBox1.Click += iconPictureBox1_Click;
            // 
            // groupBoxFacilities
            // 
            groupBoxFacilities.Controls.Add(HorseRiding);
            groupBoxFacilities.Controls.Add(GameRoom);
            groupBoxFacilities.Controls.Add(Spa);
            groupBoxFacilities.Controls.Add(Gym);
            groupBoxFacilities.Controls.Add(Lobby);
            groupBoxFacilities.Controls.Add(SwimmingPool);
            groupBoxFacilities.ForeColor = SystemColors.ActiveBorder;
            groupBoxFacilities.Location = new Point(39, 81);
            groupBoxFacilities.Margin = new Padding(2);
            groupBoxFacilities.Name = "groupBoxFacilities";
            groupBoxFacilities.Padding = new Padding(2);
            groupBoxFacilities.Size = new Size(271, 255);
            groupBoxFacilities.TabIndex = 84;
            groupBoxFacilities.TabStop = false;
            groupBoxFacilities.Text = "AVAILABLE FACILITIES";
            // 
            // HorseRiding
            // 
            HorseRiding.AutoSize = true;
            HorseRiding.ForeColor = SystemColors.ActiveBorder;
            HorseRiding.Location = new Point(15, 206);
            HorseRiding.Margin = new Padding(2);
            HorseRiding.Name = "HorseRiding";
            HorseRiding.Size = new Size(104, 19);
            HorseRiding.TabIndex = 90;
            HorseRiding.Text = "HORSE RIDING";
            HorseRiding.UseVisualStyleBackColor = true;
            // 
            // GameRoom
            // 
            GameRoom.AutoSize = true;
            GameRoom.ForeColor = SystemColors.ActiveBorder;
            GameRoom.Location = new Point(15, 172);
            GameRoom.Margin = new Padding(2);
            GameRoom.Name = "GameRoom";
            GameRoom.Size = new Size(98, 19);
            GameRoom.TabIndex = 89;
            GameRoom.Text = "GAME ROOM";
            GameRoom.UseVisualStyleBackColor = true;
            // 
            // Spa
            // 
            Spa.AutoSize = true;
            Spa.ForeColor = SystemColors.ActiveBorder;
            Spa.Location = new Point(15, 136);
            Spa.Margin = new Padding(2);
            Spa.Name = "Spa";
            Spa.Size = new Size(46, 19);
            Spa.TabIndex = 88;
            Spa.Text = "SPA";
            Spa.UseVisualStyleBackColor = true;
            // 
            // Gym
            // 
            Gym.AutoSize = true;
            Gym.ForeColor = SystemColors.ActiveBorder;
            Gym.Location = new Point(15, 99);
            Gym.Margin = new Padding(2);
            Gym.Name = "Gym";
            Gym.Size = new Size(113, 19);
            Gym.TabIndex = 87;
            Gym.Text = "FITNESS CENTRE";
            Gym.UseVisualStyleBackColor = true;
            // 
            // Lobby
            // 
            Lobby.AutoSize = true;
            Lobby.ForeColor = SystemColors.ActiveBorder;
            Lobby.Location = new Point(15, 65);
            Lobby.Margin = new Padding(2);
            Lobby.Name = "Lobby";
            Lobby.Size = new Size(62, 19);
            Lobby.TabIndex = 86;
            Lobby.Text = "LOBBY";
            Lobby.UseVisualStyleBackColor = true;
            // 
            // SwimmingPool
            // 
            SwimmingPool.AutoSize = true;
            SwimmingPool.ForeColor = SystemColors.ActiveBorder;
            SwimmingPool.Location = new Point(15, 31);
            SwimmingPool.Margin = new Padding(2);
            SwimmingPool.Name = "SwimmingPool";
            SwimmingPool.Size = new Size(122, 19);
            SwimmingPool.TabIndex = 85;
            SwimmingPool.Text = "SWIMMING POOL";
            SwimmingPool.UseVisualStyleBackColor = true;
            // 
            // Res_addGbtn
            // 
            Res_addGbtn.BackColor = Color.DimGray;
            Res_addGbtn.Font = new Font("Microsoft Tai Le", 15.75F, FontStyle.Bold);
            Res_addGbtn.Location = new Point(224, 373);
            Res_addGbtn.Margin = new Padding(4, 3, 4, 3);
            Res_addGbtn.Name = "Res_addGbtn";
            Res_addGbtn.Size = new Size(121, 44);
            Res_addGbtn.TabIndex = 83;
            Res_addGbtn.Text = "ADD";
            Res_addGbtn.UseVisualStyleBackColor = false;
            Res_addGbtn.Click += Res_addGbtn_Click;
            // 
            // label1
            // 
            label1.Font = new Font("Sitka Banner", 18F, FontStyle.Bold);
            label1.ForeColor = SystemColors.AppWorkspace;
            label1.Location = new Point(63, 18);
            label1.Margin = new Padding(2, 0, 2, 0);
            label1.Name = "label1";
            label1.Size = new Size(247, 32);
            label1.TabIndex = 75;
            label1.Text = "SELECT FACILITIES";
            // 
            // Facilities
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.AppWorkspace;
            ClientSize = new Size(387, 460);
            Controls.Add(panel1);
            FormBorderStyle = FormBorderStyle.None;
            Margin = new Padding(2);
            Name = "Facilities";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Transaction";
            panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)iconPictureBox1).EndInit();
            groupBoxFacilities.ResumeLayout(false);
            groupBoxFacilities.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button Res_addGbtn;
        private System.Windows.Forms.GroupBox groupBoxFacilities;
        private System.Windows.Forms.CheckBox HorseRiding;
        private System.Windows.Forms.CheckBox GameRoom;
        private System.Windows.Forms.CheckBox Spa;
        private System.Windows.Forms.CheckBox Gym;
        private System.Windows.Forms.CheckBox Lobby;
        private System.Windows.Forms.CheckBox SwimmingPool;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox1;
    }
}
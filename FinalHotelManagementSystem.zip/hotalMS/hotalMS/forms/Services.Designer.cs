﻿namespace hotalMS.forms
{
    partial class Services
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            tabPage3 = new TabPage();
            iconPictureBox12 = new FontAwesome.Sharp.IconPictureBox();
            label9 = new Label();
            iconPictureBox11 = new FontAwesome.Sharp.IconPictureBox();
            label10 = new Label();
            iconPictureBox8 = new FontAwesome.Sharp.IconPictureBox();
            label12 = new Label();
            iconPictureBox7 = new FontAwesome.Sharp.IconPictureBox();
            label5 = new Label();
            iconPictureBox6 = new FontAwesome.Sharp.IconPictureBox();
            label4 = new Label();
            iconPictureBox5 = new FontAwesome.Sharp.IconPictureBox();
            label11 = new Label();
            label13 = new Label();
            uRtxt = new TextBox();
            Usnametxt = new TextBox();
            Udestxt = new RichTextBox();
            Upritxt = new TextBox();
            Upidtxt = new TextBox();
            updatebtn = new Button();
            tabPage2 = new TabPage();
            sertext = new ComboBox();
            panel5 = new Panel();
            iconPictureBox10 = new FontAwesome.Sharp.IconPictureBox();
            iconPictureBox9 = new FontAwesome.Sharp.IconPictureBox();
            label18 = new Label();
            label2 = new Label();
            button1 = new Button();
            Disbtn = new Button();
            searchbtn = new Button();
            searchtxt = new TextBox();
            salgrid = new DataGridView();
            tabPage1 = new TabPage();
            panel3 = new Panel();
            panel2 = new Panel();
            panel1 = new Panel();
            panel6 = new Panel();
            panel11 = new Panel();
            iconPictureBox4 = new FontAwesome.Sharp.IconPictureBox();
            iconPictureBox3 = new FontAwesome.Sharp.IconPictureBox();
            iconPictureBox1 = new FontAwesome.Sharp.IconPictureBox();
            iconguest = new FontAwesome.Sharp.IconPictureBox();
            label14 = new Label();
            label3 = new Label();
            label1 = new Label();
            label6 = new Label();
            iconPictureBox2 = new FontAwesome.Sharp.IconPictureBox();
            label7 = new Label();
            RNotxt = new TextBox();
            snametxt = new TextBox();
            destxt = new RichTextBox();
            pritxt = new TextBox();
            Addsalbtn = new Button();
            tabControl1 = new TabControl();
            tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox12).BeginInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox11).BeginInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox8).BeginInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox7).BeginInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox6).BeginInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox5).BeginInit();
            tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox10).BeginInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox9).BeginInit();
            ((System.ComponentModel.ISupportInitialize)salgrid).BeginInit();
            tabPage1.SuspendLayout();
            panel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)iconguest).BeginInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox2).BeginInit();
            tabControl1.SuspendLayout();
            SuspendLayout();
            // 
            // tabPage3
            // 
            tabPage3.BackColor = Color.FromArgb(51, 51, 76);
            tabPage3.Controls.Add(iconPictureBox12);
            tabPage3.Controls.Add(label9);
            tabPage3.Controls.Add(iconPictureBox11);
            tabPage3.Controls.Add(label10);
            tabPage3.Controls.Add(iconPictureBox8);
            tabPage3.Controls.Add(label12);
            tabPage3.Controls.Add(iconPictureBox7);
            tabPage3.Controls.Add(label5);
            tabPage3.Controls.Add(iconPictureBox6);
            tabPage3.Controls.Add(label4);
            tabPage3.Controls.Add(iconPictureBox5);
            tabPage3.Controls.Add(label11);
            tabPage3.Controls.Add(label13);
            tabPage3.Controls.Add(uRtxt);
            tabPage3.Controls.Add(Usnametxt);
            tabPage3.Controls.Add(Udestxt);
            tabPage3.Controls.Add(Upritxt);
            tabPage3.Controls.Add(Upidtxt);
            tabPage3.Controls.Add(updatebtn);
            tabPage3.Location = new Point(4, 4);
            tabPage3.Margin = new Padding(2);
            tabPage3.Name = "tabPage3";
            tabPage3.Size = new Size(872, 392);
            tabPage3.TabIndex = 2;
            tabPage3.Text = "Update Services";
            // 
            // iconPictureBox12
            // 
            iconPictureBox12.BackColor = Color.FromArgb(51, 51, 76);
            iconPictureBox12.ForeColor = Color.Gainsboro;
            iconPictureBox12.IconChar = FontAwesome.Sharp.IconChar.HandHoldingDollar;
            iconPictureBox12.IconColor = Color.Gainsboro;
            iconPictureBox12.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconPictureBox12.IconSize = 40;
            iconPictureBox12.Location = new Point(14, 303);
            iconPictureBox12.Name = "iconPictureBox12";
            iconPictureBox12.Size = new Size(40, 42);
            iconPictureBox12.TabIndex = 85;
            iconPictureBox12.TabStop = false;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Sitka Banner", 14.2499981F, FontStyle.Bold);
            label9.ForeColor = SystemColors.AppWorkspace;
            label9.Location = new Point(58, 307);
            label9.Margin = new Padding(4, 0, 4, 0);
            label9.Name = "label9";
            label9.Size = new Size(111, 28);
            label9.TabIndex = 84;
            label9.Text = "Service Price";
            // 
            // iconPictureBox11
            // 
            iconPictureBox11.BackColor = Color.FromArgb(51, 51, 76);
            iconPictureBox11.ForeColor = Color.Gainsboro;
            iconPictureBox11.IconChar = FontAwesome.Sharp.IconChar.HandsHelping;
            iconPictureBox11.IconColor = Color.Gainsboro;
            iconPictureBox11.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconPictureBox11.IconSize = 40;
            iconPictureBox11.Location = new Point(16, 237);
            iconPictureBox11.Name = "iconPictureBox11";
            iconPictureBox11.Size = new Size(40, 42);
            iconPictureBox11.TabIndex = 83;
            iconPictureBox11.TabStop = false;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Sitka Banner", 14.2499981F, FontStyle.Bold);
            label10.ForeColor = SystemColors.AppWorkspace;
            label10.Location = new Point(58, 251);
            label10.Margin = new Padding(4, 0, 4, 0);
            label10.Name = "label10";
            label10.Size = new Size(161, 28);
            label10.TabIndex = 82;
            label10.Text = "Service Description";
            // 
            // iconPictureBox8
            // 
            iconPictureBox8.BackColor = Color.FromArgb(51, 51, 76);
            iconPictureBox8.ForeColor = Color.Gainsboro;
            iconPictureBox8.IconChar = FontAwesome.Sharp.IconChar.Handshake;
            iconPictureBox8.IconColor = Color.Gainsboro;
            iconPictureBox8.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconPictureBox8.IconSize = 40;
            iconPictureBox8.Location = new Point(21, 166);
            iconPictureBox8.Name = "iconPictureBox8";
            iconPictureBox8.Size = new Size(40, 42);
            iconPictureBox8.TabIndex = 81;
            iconPictureBox8.TabStop = false;
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Font = new Font("Sitka Banner", 14.2499981F, FontStyle.Bold);
            label12.ForeColor = SystemColors.AppWorkspace;
            label12.Location = new Point(65, 178);
            label12.Margin = new Padding(4, 0, 4, 0);
            label12.Name = "label12";
            label12.Size = new Size(117, 28);
            label12.TabIndex = 80;
            label12.Text = "Service Name";
            // 
            // iconPictureBox7
            // 
            iconPictureBox7.BackColor = Color.FromArgb(51, 51, 76);
            iconPictureBox7.ForeColor = Color.Gainsboro;
            iconPictureBox7.IconChar = FontAwesome.Sharp.IconChar.Bed;
            iconPictureBox7.IconColor = Color.Gainsboro;
            iconPictureBox7.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconPictureBox7.IconSize = 40;
            iconPictureBox7.Location = new Point(21, 108);
            iconPictureBox7.Name = "iconPictureBox7";
            iconPictureBox7.Size = new Size(40, 42);
            iconPictureBox7.TabIndex = 79;
            iconPictureBox7.TabStop = false;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Sitka Banner", 14.2499981F, FontStyle.Bold);
            label5.ForeColor = SystemColors.AppWorkspace;
            label5.Location = new Point(58, 117);
            label5.Margin = new Padding(4, 0, 4, 0);
            label5.Name = "label5";
            label5.Size = new Size(124, 28);
            label5.TabIndex = 78;
            label5.Text = "Room Number";
            // 
            // iconPictureBox6
            // 
            iconPictureBox6.BackColor = Color.FromArgb(51, 51, 76);
            iconPictureBox6.ForeColor = SystemColors.AppWorkspace;
            iconPictureBox6.IconChar = FontAwesome.Sharp.IconChar.Search;
            iconPictureBox6.IconColor = SystemColors.AppWorkspace;
            iconPictureBox6.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconPictureBox6.IconSize = 28;
            iconPictureBox6.Location = new Point(24, 68);
            iconPictureBox6.Name = "iconPictureBox6";
            iconPictureBox6.Size = new Size(29, 28);
            iconPictureBox6.TabIndex = 68;
            iconPictureBox6.TabStop = false;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Sitka Banner", 14F, FontStyle.Bold);
            label4.ForeColor = Color.FromArgb(204, 204, 204);
            label4.Location = new Point(48, 68);
            label4.Name = "label4";
            label4.Size = new Size(84, 28);
            label4.TabIndex = 67;
            label4.Text = "ServiceId";
            // 
            // iconPictureBox5
            // 
            iconPictureBox5.BackColor = Color.FromArgb(51, 51, 76);
            iconPictureBox5.ForeColor = SystemColors.AppWorkspace;
            iconPictureBox5.IconChar = FontAwesome.Sharp.IconChar.HandHoldingHand;
            iconPictureBox5.IconColor = SystemColors.AppWorkspace;
            iconPictureBox5.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconPictureBox5.IconSize = 39;
            iconPictureBox5.Location = new Point(10, 5);
            iconPictureBox5.Name = "iconPictureBox5";
            iconPictureBox5.Size = new Size(39, 46);
            iconPictureBox5.TabIndex = 62;
            iconPictureBox5.TabStop = false;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new Font("Sitka Banner", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label11.ForeColor = Color.FromArgb(204, 204, 204);
            label11.Location = new Point(46, 5);
            label11.Name = "label11";
            label11.Size = new Size(171, 35);
            label11.TabIndex = 61;
            label11.Text = "Update Services";
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Font = new Font("Microsoft Tai Le", 15.75F);
            label13.Location = new Point(28, 22);
            label13.Margin = new Padding(4, 0, 4, 0);
            label13.Name = "label13";
            label13.Size = new Size(0, 26);
            label13.TabIndex = 60;
            // 
            // uRtxt
            // 
            uRtxt.Location = new Point(244, 122);
            uRtxt.Name = "uRtxt";
            uRtxt.Size = new Size(391, 23);
            uRtxt.TabIndex = 59;
            // 
            // Usnametxt
            // 
            Usnametxt.Location = new Point(244, 183);
            Usnametxt.Margin = new Padding(3, 4, 3, 4);
            Usnametxt.Name = "Usnametxt";
            Usnametxt.Size = new Size(391, 23);
            Usnametxt.TabIndex = 57;
            // 
            // Udestxt
            // 
            Udestxt.Location = new Point(244, 229);
            Udestxt.Name = "Udestxt";
            Udestxt.Size = new Size(391, 50);
            Udestxt.TabIndex = 56;
            Udestxt.Text = "";
            // 
            // Upritxt
            // 
            Upritxt.Location = new Point(244, 307);
            Upritxt.Margin = new Padding(3, 4, 3, 4);
            Upritxt.Name = "Upritxt";
            Upritxt.Size = new Size(391, 23);
            Upritxt.TabIndex = 54;
            // 
            // Upidtxt
            // 
            Upidtxt.Location = new Point(244, 75);
            Upidtxt.Name = "Upidtxt";
            Upidtxt.Size = new Size(391, 23);
            Upidtxt.TabIndex = 48;
            Upidtxt.TextChanged += Upidtxt_TextChanged;
            // 
            // updatebtn
            // 
            updatebtn.BackColor = Color.FromArgb(51, 51, 76);
            updatebtn.Font = new Font("Sitka Banner", 18F, FontStyle.Bold);
            updatebtn.ForeColor = SystemColors.AppWorkspace;
            updatebtn.Location = new Point(625, 340);
            updatebtn.Margin = new Padding(3, 4, 3, 4);
            updatebtn.Name = "updatebtn";
            updatebtn.Size = new Size(239, 48);
            updatebtn.TabIndex = 46;
            updatebtn.Text = "Update Services";
            updatebtn.UseVisualStyleBackColor = false;
            updatebtn.Click += updatebtn_Click;
            // 
            // tabPage2
            // 
            tabPage2.BackColor = Color.FromArgb(51, 51, 76);
            tabPage2.Controls.Add(sertext);
            tabPage2.Controls.Add(panel5);
            tabPage2.Controls.Add(iconPictureBox10);
            tabPage2.Controls.Add(iconPictureBox9);
            tabPage2.Controls.Add(label18);
            tabPage2.Controls.Add(label2);
            tabPage2.Controls.Add(button1);
            tabPage2.Controls.Add(Disbtn);
            tabPage2.Controls.Add(searchbtn);
            tabPage2.Controls.Add(searchtxt);
            tabPage2.Controls.Add(salgrid);
            tabPage2.Location = new Point(4, 4);
            tabPage2.Margin = new Padding(2);
            tabPage2.Name = "tabPage2";
            tabPage2.Padding = new Padding(2);
            tabPage2.Size = new Size(872, 392);
            tabPage2.TabIndex = 1;
            tabPage2.Text = "Search and delete  Services";
            // 
            // sertext
            // 
            sertext.BackColor = Color.FromArgb(51, 51, 76);
            sertext.FlatStyle = FlatStyle.Flat;
            sertext.Font = new Font("Sitka Banner", 11F, FontStyle.Bold);
            sertext.ForeColor = SystemColors.AppWorkspace;
            sertext.FormattingEnabled = true;
            sertext.Items.AddRange(new object[] { "SearchByServiceID", "SearchByRoomNo" });
            sertext.Location = new Point(58, 57);
            sertext.Name = "sertext";
            sertext.Size = new Size(229, 29);
            sertext.TabIndex = 68;
            sertext.Text = "Select the service search criteria";
            // 
            // panel5
            // 
            panel5.BackColor = Color.Gray;
            panel5.Location = new Point(320, 84);
            panel5.Name = "panel5";
            panel5.Size = new Size(524, 1);
            panel5.TabIndex = 67;
            // 
            // iconPictureBox10
            // 
            iconPictureBox10.BackColor = Color.FromArgb(51, 51, 76);
            iconPictureBox10.ForeColor = SystemColors.AppWorkspace;
            iconPictureBox10.IconChar = FontAwesome.Sharp.IconChar.Search;
            iconPictureBox10.IconColor = SystemColors.AppWorkspace;
            iconPictureBox10.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconPictureBox10.IconSize = 28;
            iconPictureBox10.Location = new Point(18, 57);
            iconPictureBox10.Name = "iconPictureBox10";
            iconPictureBox10.Size = new Size(29, 28);
            iconPictureBox10.TabIndex = 66;
            iconPictureBox10.TabStop = false;
            // 
            // iconPictureBox9
            // 
            iconPictureBox9.BackColor = Color.FromArgb(51, 51, 76);
            iconPictureBox9.ForeColor = SystemColors.AppWorkspace;
            iconPictureBox9.IconChar = FontAwesome.Sharp.IconChar.HandHoldingHand;
            iconPictureBox9.IconColor = SystemColors.AppWorkspace;
            iconPictureBox9.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconPictureBox9.IconSize = 39;
            iconPictureBox9.Location = new Point(8, 5);
            iconPictureBox9.Name = "iconPictureBox9";
            iconPictureBox9.Size = new Size(39, 46);
            iconPictureBox9.TabIndex = 54;
            iconPictureBox9.TabStop = false;
            // 
            // label18
            // 
            label18.AutoSize = true;
            label18.Font = new Font("Sitka Banner", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label18.ForeColor = Color.FromArgb(204, 204, 204);
            label18.Location = new Point(44, 5);
            label18.Name = "label18";
            label18.Size = new Size(169, 35);
            label18.TabIndex = 53;
            label18.Text = "Search Services";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Microsoft Tai Le", 15.75F);
            label2.Location = new Point(26, 22);
            label2.Margin = new Padding(4, 0, 4, 0);
            label2.Name = "label2";
            label2.Size = new Size(0, 26);
            label2.TabIndex = 52;
            // 
            // button1
            // 
            button1.BackColor = Color.SlateGray;
            button1.Font = new Font("Microsoft Tai Le", 15.75F, FontStyle.Bold);
            button1.Location = new Point(26, 101);
            button1.Margin = new Padding(3, 4, 3, 4);
            button1.Name = "button1";
            button1.Size = new Size(123, 39);
            button1.TabIndex = 51;
            button1.Text = "DELETE";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // Disbtn
            // 
            Disbtn.BackColor = Color.FromArgb(51, 51, 76);
            Disbtn.Font = new Font("Sitka Banner", 14F, FontStyle.Bold);
            Disbtn.ForeColor = SystemColors.AppWorkspace;
            Disbtn.Location = new Point(622, 101);
            Disbtn.Margin = new Padding(3, 4, 3, 4);
            Disbtn.Name = "Disbtn";
            Disbtn.Size = new Size(223, 39);
            Disbtn.TabIndex = 50;
            Disbtn.Text = "Display services";
            Disbtn.UseVisualStyleBackColor = false;
            Disbtn.Click += Disbtn_Click;
            // 
            // searchbtn
            // 
            searchbtn.BackColor = Color.FromArgb(51, 51, 76);
            searchbtn.Font = new Font("Sitka Banner", 14F, FontStyle.Bold);
            searchbtn.ForeColor = SystemColors.AppWorkspace;
            searchbtn.Location = new Point(367, 101);
            searchbtn.Margin = new Padding(3, 4, 3, 4);
            searchbtn.Name = "searchbtn";
            searchbtn.Size = new Size(210, 39);
            searchbtn.TabIndex = 33;
            searchbtn.Text = "Search Services";
            searchbtn.UseVisualStyleBackColor = false;
            searchbtn.Click += searchbtn_Click;
            // 
            // searchtxt
            // 
            searchtxt.BackColor = Color.FromArgb(51, 51, 76);
            searchtxt.BorderStyle = BorderStyle.None;
            searchtxt.Font = new Font("Sitka Banner", 18F, FontStyle.Bold);
            searchtxt.ForeColor = SystemColors.AppWorkspace;
            searchtxt.Location = new Point(320, 49);
            searchtxt.Margin = new Padding(3, 4, 3, 4);
            searchtxt.Name = "searchtxt";
            searchtxt.Size = new Size(525, 31);
            searchtxt.TabIndex = 32;
            // 
            // salgrid
            // 
            salgrid.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            salgrid.Dock = DockStyle.Bottom;
            salgrid.Location = new Point(2, 164);
            salgrid.Margin = new Padding(2);
            salgrid.Name = "salgrid";
            salgrid.RowHeadersWidth = 62;
            salgrid.RowTemplate.Height = 33;
            salgrid.ShowCellToolTips = false;
            salgrid.Size = new Size(868, 226);
            salgrid.TabIndex = 30;
            // 
            // tabPage1
            // 
            tabPage1.BackColor = Color.FromArgb(51, 51, 76);
            tabPage1.Controls.Add(panel3);
            tabPage1.Controls.Add(panel2);
            tabPage1.Controls.Add(panel1);
            tabPage1.Controls.Add(panel6);
            tabPage1.Controls.Add(iconPictureBox4);
            tabPage1.Controls.Add(iconPictureBox3);
            tabPage1.Controls.Add(iconPictureBox1);
            tabPage1.Controls.Add(iconguest);
            tabPage1.Controls.Add(label14);
            tabPage1.Controls.Add(label3);
            tabPage1.Controls.Add(label1);
            tabPage1.Controls.Add(label6);
            tabPage1.Controls.Add(iconPictureBox2);
            tabPage1.Controls.Add(label7);
            tabPage1.Controls.Add(RNotxt);
            tabPage1.Controls.Add(snametxt);
            tabPage1.Controls.Add(destxt);
            tabPage1.Controls.Add(pritxt);
            tabPage1.Controls.Add(Addsalbtn);
            tabPage1.Location = new Point(4, 4);
            tabPage1.Margin = new Padding(2);
            tabPage1.Name = "tabPage1";
            tabPage1.Padding = new Padding(2);
            tabPage1.Size = new Size(872, 392);
            tabPage1.TabIndex = 0;
            tabPage1.Text = "Add Services";
            // 
            // panel3
            // 
            panel3.BackColor = Color.Gray;
            panel3.Location = new Point(279, 325);
            panel3.Name = "panel3";
            panel3.Size = new Size(327, 1);
            panel3.TabIndex = 87;
            // 
            // panel2
            // 
            panel2.BackColor = Color.Gray;
            panel2.Location = new Point(278, 267);
            panel2.Name = "panel2";
            panel2.Size = new Size(327, 1);
            panel2.TabIndex = 86;
            // 
            // panel1
            // 
            panel1.BackColor = Color.Gray;
            panel1.Location = new Point(278, 175);
            panel1.Name = "panel1";
            panel1.Size = new Size(327, 1);
            panel1.TabIndex = 65;
            // 
            // panel6
            // 
            panel6.BackColor = Color.Gray;
            panel6.Controls.Add(panel11);
            panel6.Location = new Point(278, 122);
            panel6.Name = "panel6";
            panel6.Size = new Size(326, 1);
            panel6.TabIndex = 85;
            // 
            // panel11
            // 
            panel11.BackColor = Color.Gray;
            panel11.Location = new Point(0, 0);
            panel11.Name = "panel11";
            panel11.Size = new Size(263, 1);
            panel11.TabIndex = 64;
            // 
            // iconPictureBox4
            // 
            iconPictureBox4.BackColor = Color.FromArgb(51, 51, 76);
            iconPictureBox4.ForeColor = Color.Gainsboro;
            iconPictureBox4.IconChar = FontAwesome.Sharp.IconChar.HandHoldingDollar;
            iconPictureBox4.IconColor = Color.Gainsboro;
            iconPictureBox4.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconPictureBox4.IconSize = 40;
            iconPictureBox4.Location = new Point(34, 294);
            iconPictureBox4.Name = "iconPictureBox4";
            iconPictureBox4.Size = new Size(40, 42);
            iconPictureBox4.TabIndex = 80;
            iconPictureBox4.TabStop = false;
            // 
            // iconPictureBox3
            // 
            iconPictureBox3.BackColor = Color.FromArgb(51, 51, 76);
            iconPictureBox3.ForeColor = Color.Gainsboro;
            iconPictureBox3.IconChar = FontAwesome.Sharp.IconChar.HandsHelping;
            iconPictureBox3.IconColor = Color.Gainsboro;
            iconPictureBox3.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconPictureBox3.IconSize = 40;
            iconPictureBox3.Location = new Point(34, 218);
            iconPictureBox3.Name = "iconPictureBox3";
            iconPictureBox3.Size = new Size(40, 42);
            iconPictureBox3.TabIndex = 79;
            iconPictureBox3.TabStop = false;
            // 
            // iconPictureBox1
            // 
            iconPictureBox1.BackColor = Color.FromArgb(51, 51, 76);
            iconPictureBox1.ForeColor = Color.Gainsboro;
            iconPictureBox1.IconChar = FontAwesome.Sharp.IconChar.Handshake;
            iconPictureBox1.IconColor = Color.Gainsboro;
            iconPictureBox1.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconPictureBox1.IconSize = 40;
            iconPictureBox1.Location = new Point(34, 138);
            iconPictureBox1.Name = "iconPictureBox1";
            iconPictureBox1.Size = new Size(40, 42);
            iconPictureBox1.TabIndex = 78;
            iconPictureBox1.TabStop = false;
            // 
            // iconguest
            // 
            iconguest.BackColor = Color.FromArgb(51, 51, 76);
            iconguest.ForeColor = Color.Gainsboro;
            iconguest.IconChar = FontAwesome.Sharp.IconChar.Bed;
            iconguest.IconColor = Color.Gainsboro;
            iconguest.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconguest.IconSize = 40;
            iconguest.Location = new Point(34, 81);
            iconguest.Name = "iconguest";
            iconguest.Size = new Size(40, 42);
            iconguest.TabIndex = 77;
            iconguest.TabStop = false;
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Font = new Font("Sitka Banner", 14.2499981F, FontStyle.Bold);
            label14.ForeColor = SystemColors.AppWorkspace;
            label14.Location = new Point(78, 298);
            label14.Margin = new Padding(4, 0, 4, 0);
            label14.Name = "label14";
            label14.Size = new Size(111, 28);
            label14.TabIndex = 76;
            label14.Text = "Service Price";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Sitka Banner", 14.2499981F, FontStyle.Bold);
            label3.ForeColor = SystemColors.AppWorkspace;
            label3.Location = new Point(76, 232);
            label3.Margin = new Padding(4, 0, 4, 0);
            label3.Name = "label3";
            label3.Size = new Size(161, 28);
            label3.TabIndex = 75;
            label3.Text = "Service Description";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Sitka Banner", 14.2499981F, FontStyle.Bold);
            label1.ForeColor = SystemColors.AppWorkspace;
            label1.Location = new Point(78, 150);
            label1.Margin = new Padding(4, 0, 4, 0);
            label1.Name = "label1";
            label1.Size = new Size(117, 28);
            label1.TabIndex = 74;
            label1.Text = "Service Name";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Sitka Banner", 14.2499981F, FontStyle.Bold);
            label6.ForeColor = SystemColors.AppWorkspace;
            label6.Location = new Point(71, 90);
            label6.Margin = new Padding(4, 0, 4, 0);
            label6.Name = "label6";
            label6.Size = new Size(124, 28);
            label6.TabIndex = 73;
            label6.Text = "Room Number";
            // 
            // iconPictureBox2
            // 
            iconPictureBox2.BackColor = Color.FromArgb(51, 51, 76);
            iconPictureBox2.ForeColor = SystemColors.AppWorkspace;
            iconPictureBox2.IconChar = FontAwesome.Sharp.IconChar.HandHoldingHand;
            iconPictureBox2.IconColor = SystemColors.AppWorkspace;
            iconPictureBox2.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconPictureBox2.IconSize = 67;
            iconPictureBox2.Location = new Point(5, 8);
            iconPictureBox2.Name = "iconPictureBox2";
            iconPictureBox2.Size = new Size(69, 67);
            iconPictureBox2.TabIndex = 72;
            iconPictureBox2.TabStop = false;
            // 
            // label7
            // 
            label7.Font = new Font("Sitka Banner", 17F, FontStyle.Bold);
            label7.ForeColor = SystemColors.AppWorkspace;
            label7.Location = new Point(71, 23);
            label7.Name = "label7";
            label7.Size = new Size(166, 39);
            label7.TabIndex = 70;
            label7.Text = "\"There for you\"";
            // 
            // RNotxt
            // 
            RNotxt.BackColor = Color.FromArgb(51, 51, 76);
            RNotxt.BorderStyle = BorderStyle.None;
            RNotxt.Font = new Font("Sitka Banner", 12.2499981F, FontStyle.Bold);
            RNotxt.ForeColor = SystemColors.AppWorkspace;
            RNotxt.Location = new Point(278, 102);
            RNotxt.Margin = new Padding(3, 4, 3, 4);
            RNotxt.Name = "RNotxt";
            RNotxt.Size = new Size(328, 21);
            RNotxt.TabIndex = 51;
            RNotxt.TextChanged += RNotxt_TextChanged;
            // 
            // snametxt
            // 
            snametxt.BackColor = Color.FromArgb(51, 51, 76);
            snametxt.BorderStyle = BorderStyle.None;
            snametxt.Font = new Font("Sitka Banner", 12.2499981F, FontStyle.Bold);
            snametxt.ForeColor = SystemColors.AppWorkspace;
            snametxt.Location = new Point(277, 154);
            snametxt.Margin = new Padding(3, 4, 3, 4);
            snametxt.Name = "snametxt";
            snametxt.Size = new Size(328, 21);
            snametxt.TabIndex = 49;
            // 
            // destxt
            // 
            destxt.BackColor = Color.FromArgb(51, 51, 76);
            destxt.BorderStyle = BorderStyle.None;
            destxt.Font = new Font("Sitka Banner", 12.2499981F, FontStyle.Bold);
            destxt.ForeColor = SystemColors.AppWorkspace;
            destxt.Location = new Point(278, 218);
            destxt.Name = "destxt";
            destxt.Size = new Size(328, 50);
            destxt.TabIndex = 48;
            destxt.Text = "";
            // 
            // pritxt
            // 
            pritxt.BackColor = Color.FromArgb(51, 51, 76);
            pritxt.BorderStyle = BorderStyle.None;
            pritxt.Font = new Font("Sitka Banner", 12.2499981F, FontStyle.Bold);
            pritxt.ForeColor = SystemColors.AppWorkspace;
            pritxt.Location = new Point(278, 305);
            pritxt.Margin = new Padding(3, 4, 3, 4);
            pritxt.Name = "pritxt";
            pritxt.Size = new Size(328, 21);
            pritxt.TabIndex = 46;
            // 
            // Addsalbtn
            // 
            Addsalbtn.BackColor = Color.FromArgb(51, 51, 76);
            Addsalbtn.Font = new Font("Sitka Banner", 12.2499981F, FontStyle.Bold);
            Addsalbtn.ForeColor = SystemColors.AppWorkspace;
            Addsalbtn.Location = new Point(571, 338);
            Addsalbtn.Margin = new Padding(3, 4, 3, 4);
            Addsalbtn.Name = "Addsalbtn";
            Addsalbtn.Size = new Size(293, 38);
            Addsalbtn.TabIndex = 35;
            Addsalbtn.Text = "Add Service";
            Addsalbtn.UseVisualStyleBackColor = false;
            Addsalbtn.Click += Addsalbtn_Click;
            // 
            // tabControl1
            // 
            tabControl1.Alignment = TabAlignment.Bottom;
            tabControl1.Controls.Add(tabPage1);
            tabControl1.Controls.Add(tabPage2);
            tabControl1.Controls.Add(tabPage3);
            tabControl1.Dock = DockStyle.Fill;
            tabControl1.Location = new Point(0, 0);
            tabControl1.Margin = new Padding(2);
            tabControl1.Name = "tabControl1";
            tabControl1.SelectedIndex = 0;
            tabControl1.Size = new Size(880, 420);
            tabControl1.TabIndex = 75;
            // 
            // Services
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(51, 51, 76);
            ClientSize = new Size(880, 420);
            Controls.Add(tabControl1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "Services";
            Text = "Services";
            tabPage3.ResumeLayout(false);
            tabPage3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox12).EndInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox11).EndInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox8).EndInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox7).EndInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox6).EndInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox5).EndInit();
            tabPage2.ResumeLayout(false);
            tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox10).EndInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox9).EndInit();
            ((System.ComponentModel.ISupportInitialize)salgrid).EndInit();
            tabPage1.ResumeLayout(false);
            tabPage1.PerformLayout();
            panel6.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)iconPictureBox4).EndInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox3).EndInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)iconguest).EndInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox2).EndInit();
            tabControl1.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        private TabPage tabPage3;
        private TextBox uRtxt;
        private TextBox Usnametxt;
        private RichTextBox Udestxt;
        private TextBox Upritxt;
        private TextBox Upidtxt;
        private Button updatebtn;
        private TabPage tabPage2;
        private Button button1;
        private Button Disbtn;
        private Button searchbtn;
        private TextBox searchtxt;
        private DataGridView salgrid;
        private TabPage tabPage1;
        private TextBox RNotxt;
        private TextBox snametxt;
        private RichTextBox destxt;
        private TextBox pritxt;
        private Button Addsalbtn;
        private TabControl tabControl1;
        private Label label7;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox2;
        private Label label14;
        private Label label3;
        private Label label1;
        private Label label6;
        private FontAwesome.Sharp.IconPictureBox iconguest;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox4;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox3;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox1;
        private Panel panel3;
        private Panel panel2;
        private Panel panel1;
        private Panel panel6;
        private Panel panel11;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox9;
        private Label label18;
        private Label label2;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox10;
        private Panel panel5;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox5;
        private Label label11;
        private Label label13;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox12;
        private Label label9;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox11;
        private Label label10;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox8;
        private Label label12;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox7;
        private Label label5;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox6;
        private Label label4;
        private ComboBox sertext;
    }
}
﻿
namespace DBMS_HMS
{
    partial class Reservation
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Res_idsearch = new TextBox();
            tabPage2 = new TabPage();
            panel17 = new Panel();
            iconPictureBox5 = new FontAwesome.Sharp.IconPictureBox();
            iconPictureBox4 = new FontAwesome.Sharp.IconPictureBox();
            iconPictureBox3 = new FontAwesome.Sharp.IconPictureBox();
            iconPictureBox2 = new FontAwesome.Sharp.IconPictureBox();
            iconPictureBox10 = new FontAwesome.Sharp.IconPictureBox();
            label6 = new Label();
            iconPictureBox1 = new FontAwesome.Sharp.IconPictureBox();
            label1 = new Label();
            button2 = new Button();
            label13 = new Label();
            G_combo = new TextBox();
            R_nocombo = new ComboBox();
            checkout = new DateTimePicker();
            checkin = new DateTimePicker();
            Rtypecombo = new ComboBox();
            Res_addGbtn = new Button();
            label5 = new Label();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            tabPage1 = new TabPage();
            panel1 = new Panel();
            iconPictureBox13 = new FontAwesome.Sharp.IconPictureBox();
            label9 = new Label();
            iconPictureBox12 = new FontAwesome.Sharp.IconPictureBox();
            label8 = new Label();
            iconPictureBox11 = new FontAwesome.Sharp.IconPictureBox();
            label12 = new Label();
            iconPictureBox9 = new FontAwesome.Sharp.IconPictureBox();
            label14 = new Label();
            iconPictureBox8 = new FontAwesome.Sharp.IconPictureBox();
            label10 = new Label();
            Nocombo = new ComboBox();
            OutdateTime = new DateTimePicker();
            Typecombo = new ComboBox();
            txtReservationID = new TextBox();
            updateGbtn = new Button();
            tabControl1 = new TabControl();
            tabPage4 = new TabPage();
            panel4 = new Panel();
            iconPictureBox7 = new FontAwesome.Sharp.IconPictureBox();
            label7 = new Label();
            iconPictureBox6 = new FontAwesome.Sharp.IconPictureBox();
            label11 = new Label();
            clearbtn = new Button();
            R_datagrid = new DataGridView();
            Res_searchbtn = new Button();
            tabPage3 = new TabPage();
            iconPictureBox14 = new FontAwesome.Sharp.IconPictureBox();
            label15 = new Label();
            button1 = new Button();
            dataGridView1 = new DataGridView();
            tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox5).BeginInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox10).BeginInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox1).BeginInit();
            tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox13).BeginInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox12).BeginInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox11).BeginInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox9).BeginInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox8).BeginInit();
            tabControl1.SuspendLayout();
            tabPage4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox7).BeginInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox6).BeginInit();
            ((System.ComponentModel.ISupportInitialize)R_datagrid).BeginInit();
            tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox14).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // Res_idsearch
            // 
            Res_idsearch.BackColor = Color.FromArgb(51, 51, 76);
            Res_idsearch.BorderStyle = BorderStyle.None;
            Res_idsearch.Font = new Font("Sitka Banner", 12.2499981F, FontStyle.Bold);
            Res_idsearch.ForeColor = SystemColors.AppWorkspace;
            Res_idsearch.Location = new Point(177, 62);
            Res_idsearch.Margin = new Padding(4, 3, 4, 3);
            Res_idsearch.Name = "Res_idsearch";
            Res_idsearch.Size = new Size(247, 21);
            Res_idsearch.TabIndex = 29;
            // 
            // tabPage2
            // 
            tabPage2.BackColor = Color.FromArgb(51, 51, 76);
            tabPage2.Controls.Add(panel17);
            tabPage2.Controls.Add(iconPictureBox5);
            tabPage2.Controls.Add(iconPictureBox4);
            tabPage2.Controls.Add(iconPictureBox3);
            tabPage2.Controls.Add(iconPictureBox2);
            tabPage2.Controls.Add(iconPictureBox10);
            tabPage2.Controls.Add(label6);
            tabPage2.Controls.Add(iconPictureBox1);
            tabPage2.Controls.Add(label1);
            tabPage2.Controls.Add(button2);
            tabPage2.Controls.Add(label13);
            tabPage2.Controls.Add(G_combo);
            tabPage2.Controls.Add(R_nocombo);
            tabPage2.Controls.Add(checkout);
            tabPage2.Controls.Add(checkin);
            tabPage2.Controls.Add(Rtypecombo);
            tabPage2.Controls.Add(Res_addGbtn);
            tabPage2.Controls.Add(label5);
            tabPage2.Controls.Add(label4);
            tabPage2.Controls.Add(label3);
            tabPage2.Controls.Add(label2);
            tabPage2.Font = new Font("Microsoft Sans Serif", 11F, FontStyle.Bold, GraphicsUnit.Point, 0);
            tabPage2.Location = new Point(4, 4);
            tabPage2.Margin = new Padding(4, 3, 4, 3);
            tabPage2.Name = "tabPage2";
            tabPage2.Padding = new Padding(4, 3, 4, 3);
            tabPage2.Size = new Size(872, 392);
            tabPage2.TabIndex = 1;
            tabPage2.Text = "Add Reservation";
            tabPage2.Click += tabPage2_Click;
            // 
            // panel17
            // 
            panel17.BackColor = Color.Gray;
            panel17.Location = new Point(159, 102);
            panel17.Name = "panel17";
            panel17.Size = new Size(704, 1);
            panel17.TabIndex = 87;
            // 
            // iconPictureBox5
            // 
            iconPictureBox5.BackColor = Color.FromArgb(51, 51, 76);
            iconPictureBox5.ForeColor = SystemColors.AppWorkspace;
            iconPictureBox5.IconChar = FontAwesome.Sharp.IconChar.CalendarMinus;
            iconPictureBox5.IconColor = SystemColors.AppWorkspace;
            iconPictureBox5.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconPictureBox5.IconSize = 28;
            iconPictureBox5.Location = new Point(422, 277);
            iconPictureBox5.Name = "iconPictureBox5";
            iconPictureBox5.Size = new Size(28, 32);
            iconPictureBox5.TabIndex = 71;
            iconPictureBox5.TabStop = false;
            // 
            // iconPictureBox4
            // 
            iconPictureBox4.BackColor = Color.FromArgb(51, 51, 76);
            iconPictureBox4.ForeColor = SystemColors.AppWorkspace;
            iconPictureBox4.IconChar = FontAwesome.Sharp.IconChar.CalendarCheck;
            iconPictureBox4.IconColor = SystemColors.AppWorkspace;
            iconPictureBox4.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconPictureBox4.IconSize = 28;
            iconPictureBox4.Location = new Point(422, 173);
            iconPictureBox4.Name = "iconPictureBox4";
            iconPictureBox4.Size = new Size(28, 32);
            iconPictureBox4.TabIndex = 70;
            iconPictureBox4.TabStop = false;
            // 
            // iconPictureBox3
            // 
            iconPictureBox3.BackColor = Color.FromArgb(51, 51, 76);
            iconPictureBox3.ForeColor = SystemColors.AppWorkspace;
            iconPictureBox3.IconChar = FontAwesome.Sharp.IconChar.BedPulse;
            iconPictureBox3.IconColor = SystemColors.AppWorkspace;
            iconPictureBox3.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconPictureBox3.IconSize = 28;
            iconPictureBox3.Location = new Point(19, 271);
            iconPictureBox3.Name = "iconPictureBox3";
            iconPictureBox3.Size = new Size(28, 32);
            iconPictureBox3.TabIndex = 69;
            iconPictureBox3.TabStop = false;
            // 
            // iconPictureBox2
            // 
            iconPictureBox2.BackColor = Color.FromArgb(51, 51, 76);
            iconPictureBox2.ForeColor = SystemColors.AppWorkspace;
            iconPictureBox2.IconChar = FontAwesome.Sharp.IconChar.Bed;
            iconPictureBox2.IconColor = SystemColors.AppWorkspace;
            iconPictureBox2.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconPictureBox2.IconSize = 28;
            iconPictureBox2.Location = new Point(19, 173);
            iconPictureBox2.Name = "iconPictureBox2";
            iconPictureBox2.Size = new Size(28, 32);
            iconPictureBox2.TabIndex = 68;
            iconPictureBox2.TabStop = false;
            // 
            // iconPictureBox10
            // 
            iconPictureBox10.BackColor = Color.FromArgb(51, 51, 76);
            iconPictureBox10.ForeColor = SystemColors.AppWorkspace;
            iconPictureBox10.IconChar = FontAwesome.Sharp.IconChar.Search;
            iconPictureBox10.IconColor = SystemColors.AppWorkspace;
            iconPictureBox10.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconPictureBox10.IconSize = 39;
            iconPictureBox10.Location = new Point(8, 74);
            iconPictureBox10.Name = "iconPictureBox10";
            iconPictureBox10.Size = new Size(39, 48);
            iconPictureBox10.TabIndex = 67;
            iconPictureBox10.TabStop = false;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Sitka Banner", 14.2499981F, FontStyle.Bold);
            label6.ForeColor = SystemColors.AppWorkspace;
            label6.Location = new Point(44, 81);
            label6.Margin = new Padding(4, 0, 4, 0);
            label6.Name = "label6";
            label6.Size = new Size(78, 28);
            label6.TabIndex = 66;
            label6.Text = "Guest ID";
            // 
            // iconPictureBox1
            // 
            iconPictureBox1.BackColor = Color.FromArgb(51, 51, 76);
            iconPictureBox1.ForeColor = SystemColors.AppWorkspace;
            iconPictureBox1.IconChar = FontAwesome.Sharp.IconChar.Ticket;
            iconPictureBox1.IconColor = SystemColors.AppWorkspace;
            iconPictureBox1.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconPictureBox1.IconSize = 39;
            iconPictureBox1.Location = new Point(8, 6);
            iconPictureBox1.Name = "iconPictureBox1";
            iconPictureBox1.Size = new Size(39, 46);
            iconPictureBox1.TabIndex = 51;
            iconPictureBox1.TabStop = false;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Sitka Banner", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.FromArgb(204, 204, 204);
            label1.Location = new Point(44, 6);
            label1.Name = "label1";
            label1.Size = new Size(176, 35);
            label1.TabIndex = 50;
            label1.Text = "Add Reservation";
            // 
            // button2
            // 
            button2.BackColor = Color.FromArgb(51, 51, 76);
            button2.FlatStyle = FlatStyle.Flat;
            button2.Font = new Font("Sitka Banner", 18F, FontStyle.Bold);
            button2.ForeColor = SystemColors.AppWorkspace;
            button2.Location = new Point(19, 325);
            button2.Margin = new Padding(4, 3, 4, 3);
            button2.Name = "button2";
            button2.Size = new Size(287, 44);
            button2.TabIndex = 49;
            button2.Text = "Add Facilities";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Font = new Font("Microsoft Tai Le", 15.75F);
            label13.Location = new Point(490, 62);
            label13.Margin = new Padding(4, 0, 4, 0);
            label13.Name = "label13";
            label13.Size = new Size(0, 26);
            label13.TabIndex = 32;
            // 
            // G_combo
            // 
            G_combo.BackColor = Color.FromArgb(51, 51, 76);
            G_combo.BorderStyle = BorderStyle.None;
            G_combo.Font = new Font("Sitka Banner", 14.2499981F, FontStyle.Bold);
            G_combo.ForeColor = SystemColors.AppWorkspace;
            G_combo.Location = new Point(159, 74);
            G_combo.Margin = new Padding(2);
            G_combo.Name = "G_combo";
            G_combo.Size = new Size(706, 24);
            G_combo.TabIndex = 31;
            G_combo.TextChanged += G_combo_TextChanged;
            // 
            // R_nocombo
            // 
            R_nocombo.BackColor = Color.FromArgb(51, 51, 76);
            R_nocombo.FlatStyle = FlatStyle.Flat;
            R_nocombo.Font = new Font("Sitka Banner", 11.2499981F, FontStyle.Bold);
            R_nocombo.ForeColor = SystemColors.AppWorkspace;
            R_nocombo.FormattingEnabled = true;
            R_nocombo.Location = new Point(159, 277);
            R_nocombo.Margin = new Padding(4, 3, 4, 3);
            R_nocombo.Name = "R_nocombo";
            R_nocombo.Size = new Size(222, 29);
            R_nocombo.TabIndex = 27;
            // 
            // checkout
            // 
            checkout.CalendarMonthBackground = Color.FromArgb(51, 51, 76);
            checkout.CalendarTitleBackColor = Color.FromArgb(51, 51, 76);
            checkout.Location = new Point(584, 277);
            checkout.Margin = new Padding(4, 3, 4, 3);
            checkout.Name = "checkout";
            checkout.Size = new Size(281, 24);
            checkout.TabIndex = 26;
            checkout.ValueChanged += checkout_ValueChanged;
            // 
            // checkin
            // 
            checkin.CalendarMonthBackground = Color.FromArgb(51, 51, 76);
            checkin.CalendarTitleBackColor = Color.FromArgb(51, 51, 76);
            checkin.Location = new Point(580, 177);
            checkin.Margin = new Padding(4, 3, 4, 3);
            checkin.Name = "checkin";
            checkin.Size = new Size(284, 24);
            checkin.TabIndex = 25;
            checkin.ValueChanged += checkin_ValueChanged;
            // 
            // Rtypecombo
            // 
            Rtypecombo.BackColor = Color.FromArgb(51, 51, 76);
            Rtypecombo.FlatStyle = FlatStyle.Flat;
            Rtypecombo.Font = new Font("Sitka Banner", 11.2499981F, FontStyle.Bold);
            Rtypecombo.ForeColor = SystemColors.AppWorkspace;
            Rtypecombo.FormattingEnabled = true;
            Rtypecombo.Items.AddRange(new object[] { "Single", "Double ", "Family ", "Suite" });
            Rtypecombo.Location = new Point(159, 178);
            Rtypecombo.Margin = new Padding(4, 3, 4, 3);
            Rtypecombo.Name = "Rtypecombo";
            Rtypecombo.Size = new Size(222, 29);
            Rtypecombo.TabIndex = 24;
            Rtypecombo.SelectedIndexChanged += Rtypecombo_SelectedIndexChanged;
            // 
            // Res_addGbtn
            // 
            Res_addGbtn.BackColor = Color.FromArgb(51, 51, 76);
            Res_addGbtn.FlatStyle = FlatStyle.Flat;
            Res_addGbtn.Font = new Font("Sitka Banner", 18F, FontStyle.Bold);
            Res_addGbtn.ForeColor = SystemColors.AppWorkspace;
            Res_addGbtn.Location = new Point(580, 325);
            Res_addGbtn.Margin = new Padding(4, 3, 4, 3);
            Res_addGbtn.Name = "Res_addGbtn";
            Res_addGbtn.Size = new Size(283, 44);
            Res_addGbtn.TabIndex = 23;
            Res_addGbtn.Text = "Confirm Reservation";
            Res_addGbtn.UseVisualStyleBackColor = false;
            Res_addGbtn.Click += Res_addGbtn_Click;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Sitka Banner", 14.2499981F, FontStyle.Bold);
            label5.ForeColor = SystemColors.AppWorkspace;
            label5.Location = new Point(452, 275);
            label5.Margin = new Padding(4, 0, 4, 0);
            label5.Name = "label5";
            label5.Size = new Size(124, 28);
            label5.TabIndex = 15;
            label5.Text = "CheckOut Date";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Sitka Banner", 14.2499981F, FontStyle.Bold);
            label4.ForeColor = SystemColors.AppWorkspace;
            label4.Location = new Point(44, 271);
            label4.Margin = new Padding(4, 0, 4, 0);
            label4.Name = "label4";
            label4.Size = new Size(82, 28);
            label4.TabIndex = 14;
            label4.Text = "Room No";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Sitka Banner", 14.2499981F, FontStyle.Bold);
            label3.ForeColor = SystemColors.AppWorkspace;
            label3.Location = new Point(452, 173);
            label3.Margin = new Padding(4, 0, 4, 0);
            label3.Name = "label3";
            label3.Size = new Size(112, 28);
            label3.TabIndex = 13;
            label3.Text = "CheckIn Date";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Sitka Banner", 14.2499981F, FontStyle.Bold);
            label2.ForeColor = SystemColors.AppWorkspace;
            label2.Location = new Point(44, 173);
            label2.Margin = new Padding(4, 0, 4, 0);
            label2.Name = "label2";
            label2.Size = new Size(98, 28);
            label2.TabIndex = 12;
            label2.Text = "Room Type";
            // 
            // tabPage1
            // 
            tabPage1.BackColor = Color.FromArgb(51, 51, 76);
            tabPage1.Controls.Add(panel1);
            tabPage1.Controls.Add(iconPictureBox13);
            tabPage1.Controls.Add(label9);
            tabPage1.Controls.Add(iconPictureBox12);
            tabPage1.Controls.Add(label8);
            tabPage1.Controls.Add(iconPictureBox11);
            tabPage1.Controls.Add(label12);
            tabPage1.Controls.Add(iconPictureBox9);
            tabPage1.Controls.Add(label14);
            tabPage1.Controls.Add(iconPictureBox8);
            tabPage1.Controls.Add(label10);
            tabPage1.Controls.Add(Nocombo);
            tabPage1.Controls.Add(OutdateTime);
            tabPage1.Controls.Add(Typecombo);
            tabPage1.Controls.Add(txtReservationID);
            tabPage1.Controls.Add(updateGbtn);
            tabPage1.Font = new Font("Microsoft Sans Serif", 11F, FontStyle.Bold);
            tabPage1.Location = new Point(4, 4);
            tabPage1.Margin = new Padding(4, 3, 4, 3);
            tabPage1.Name = "tabPage1";
            tabPage1.Size = new Size(872, 392);
            tabPage1.TabIndex = 2;
            tabPage1.Text = "Update Reservation";
            // 
            // panel1
            // 
            panel1.BackColor = Color.Gray;
            panel1.Location = new Point(180, 74);
            panel1.Name = "panel1";
            panel1.Size = new Size(662, 1);
            panel1.TabIndex = 88;
            // 
            // iconPictureBox13
            // 
            iconPictureBox13.BackColor = Color.FromArgb(51, 51, 76);
            iconPictureBox13.ForeColor = SystemColors.AppWorkspace;
            iconPictureBox13.IconChar = FontAwesome.Sharp.IconChar.BedPulse;
            iconPictureBox13.IconColor = SystemColors.AppWorkspace;
            iconPictureBox13.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconPictureBox13.IconSize = 28;
            iconPictureBox13.Location = new Point(12, 256);
            iconPictureBox13.Name = "iconPictureBox13";
            iconPictureBox13.Size = new Size(28, 32);
            iconPictureBox13.TabIndex = 75;
            iconPictureBox13.TabStop = false;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Sitka Banner", 14.2499981F, FontStyle.Bold);
            label9.ForeColor = SystemColors.AppWorkspace;
            label9.Location = new Point(37, 256);
            label9.Margin = new Padding(4, 0, 4, 0);
            label9.Name = "label9";
            label9.Size = new Size(82, 28);
            label9.TabIndex = 74;
            label9.Text = "Room No";
            // 
            // iconPictureBox12
            // 
            iconPictureBox12.BackColor = Color.FromArgb(51, 51, 76);
            iconPictureBox12.ForeColor = SystemColors.AppWorkspace;
            iconPictureBox12.IconChar = FontAwesome.Sharp.IconChar.CalendarMinus;
            iconPictureBox12.IconColor = SystemColors.AppWorkspace;
            iconPictureBox12.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconPictureBox12.IconSize = 28;
            iconPictureBox12.Location = new Point(7, 191);
            iconPictureBox12.Name = "iconPictureBox12";
            iconPictureBox12.Size = new Size(28, 32);
            iconPictureBox12.TabIndex = 73;
            iconPictureBox12.TabStop = false;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Sitka Banner", 14.2499981F, FontStyle.Bold);
            label8.ForeColor = SystemColors.AppWorkspace;
            label8.Location = new Point(37, 189);
            label8.Margin = new Padding(4, 0, 4, 0);
            label8.Name = "label8";
            label8.Size = new Size(124, 28);
            label8.TabIndex = 72;
            label8.Text = "CheckOut Date";
            // 
            // iconPictureBox11
            // 
            iconPictureBox11.BackColor = Color.FromArgb(51, 51, 76);
            iconPictureBox11.ForeColor = SystemColors.AppWorkspace;
            iconPictureBox11.IconChar = FontAwesome.Sharp.IconChar.Bed;
            iconPictureBox11.IconColor = SystemColors.AppWorkspace;
            iconPictureBox11.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconPictureBox11.IconSize = 28;
            iconPictureBox11.Location = new Point(12, 131);
            iconPictureBox11.Name = "iconPictureBox11";
            iconPictureBox11.Size = new Size(28, 32);
            iconPictureBox11.TabIndex = 71;
            iconPictureBox11.TabStop = false;
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Font = new Font("Sitka Banner", 14.2499981F, FontStyle.Bold);
            label12.ForeColor = SystemColors.AppWorkspace;
            label12.Location = new Point(37, 131);
            label12.Margin = new Padding(4, 0, 4, 0);
            label12.Name = "label12";
            label12.Size = new Size(98, 28);
            label12.TabIndex = 70;
            label12.Text = "Room Type";
            // 
            // iconPictureBox9
            // 
            iconPictureBox9.BackColor = Color.FromArgb(51, 51, 76);
            iconPictureBox9.ForeColor = SystemColors.AppWorkspace;
            iconPictureBox9.IconChar = FontAwesome.Sharp.IconChar.Search;
            iconPictureBox9.IconColor = SystemColors.AppWorkspace;
            iconPictureBox9.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconPictureBox9.IconSize = 39;
            iconPictureBox9.Location = new Point(10, 47);
            iconPictureBox9.Name = "iconPictureBox9";
            iconPictureBox9.Size = new Size(39, 48);
            iconPictureBox9.TabIndex = 69;
            iconPictureBox9.TabStop = false;
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Font = new Font("Sitka Banner", 14.2499981F, FontStyle.Bold);
            label14.ForeColor = SystemColors.AppWorkspace;
            label14.Location = new Point(46, 56);
            label14.Margin = new Padding(4, 0, 4, 0);
            label14.Name = "label14";
            label14.Size = new Size(125, 28);
            label14.TabIndex = 68;
            label14.Text = "Reservation ID";
            // 
            // iconPictureBox8
            // 
            iconPictureBox8.BackColor = Color.FromArgb(51, 51, 76);
            iconPictureBox8.ForeColor = SystemColors.AppWorkspace;
            iconPictureBox8.IconChar = FontAwesome.Sharp.IconChar.Ticket;
            iconPictureBox8.IconColor = SystemColors.AppWorkspace;
            iconPictureBox8.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconPictureBox8.IconSize = 39;
            iconPictureBox8.Location = new Point(10, 5);
            iconPictureBox8.Name = "iconPictureBox8";
            iconPictureBox8.Size = new Size(39, 46);
            iconPictureBox8.TabIndex = 55;
            iconPictureBox8.TabStop = false;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Sitka Banner", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label10.ForeColor = Color.FromArgb(204, 204, 204);
            label10.Location = new Point(46, 5);
            label10.Name = "label10";
            label10.Size = new Size(207, 35);
            label10.TabIndex = 54;
            label10.Text = "Update Reservation";
            // 
            // Nocombo
            // 
            Nocombo.BackColor = Color.FromArgb(51, 51, 76);
            Nocombo.Font = new Font("Sitka Banner", 11.2499981F, FontStyle.Bold);
            Nocombo.ForeColor = SystemColors.AppWorkspace;
            Nocombo.FormattingEnabled = true;
            Nocombo.Location = new Point(179, 260);
            Nocombo.Margin = new Padding(4, 3, 4, 3);
            Nocombo.Name = "Nocombo";
            Nocombo.Size = new Size(339, 29);
            Nocombo.TabIndex = 38;
            Nocombo.Text = "RoomNO";
            // 
            // OutdateTime
            // 
            OutdateTime.Location = new Point(180, 193);
            OutdateTime.Margin = new Padding(4, 3, 4, 3);
            OutdateTime.Name = "OutdateTime";
            OutdateTime.Size = new Size(340, 24);
            OutdateTime.TabIndex = 37;
            // 
            // Typecombo
            // 
            Typecombo.BackColor = Color.FromArgb(51, 51, 76);
            Typecombo.Font = new Font("Sitka Banner", 11.2499981F, FontStyle.Bold);
            Typecombo.ForeColor = SystemColors.AppWorkspace;
            Typecombo.FormattingEnabled = true;
            Typecombo.Items.AddRange(new object[] { "Single", "Double ", "Family ", "Suite" });
            Typecombo.Location = new Point(180, 135);
            Typecombo.Margin = new Padding(4, 3, 4, 3);
            Typecombo.Name = "Typecombo";
            Typecombo.Size = new Size(339, 29);
            Typecombo.TabIndex = 35;
            Typecombo.SelectedIndexChanged += Typecombo_SelectedIndexChanged;
            // 
            // txtReservationID
            // 
            txtReservationID.BackColor = Color.FromArgb(51, 51, 76);
            txtReservationID.BorderStyle = BorderStyle.None;
            txtReservationID.Font = new Font("Sitka Banner", 12.2499981F, FontStyle.Bold);
            txtReservationID.ForeColor = SystemColors.AppWorkspace;
            txtReservationID.Location = new Point(180, 51);
            txtReservationID.Margin = new Padding(4, 3, 4, 3);
            txtReservationID.Name = "txtReservationID";
            txtReservationID.Size = new Size(661, 21);
            txtReservationID.TabIndex = 30;
            txtReservationID.TextChanged += txtReservationID_TextChanged;
            // 
            // updateGbtn
            // 
            updateGbtn.BackColor = Color.FromArgb(51, 51, 76);
            updateGbtn.FlatStyle = FlatStyle.Flat;
            updateGbtn.Font = new Font("Sitka Banner", 18F, FontStyle.Bold);
            updateGbtn.ForeColor = SystemColors.AppWorkspace;
            updateGbtn.Location = new Point(493, 332);
            updateGbtn.Margin = new Padding(4, 3, 4, 3);
            updateGbtn.Name = "updateGbtn";
            updateGbtn.Size = new Size(370, 44);
            updateGbtn.TabIndex = 22;
            updateGbtn.Text = "Update Reservation";
            updateGbtn.UseVisualStyleBackColor = false;
            updateGbtn.Click += updateGbtn_Click;
            // 
            // tabControl1
            // 
            tabControl1.Alignment = TabAlignment.Bottom;
            tabControl1.Controls.Add(tabPage2);
            tabControl1.Controls.Add(tabPage4);
            tabControl1.Controls.Add(tabPage1);
            tabControl1.Controls.Add(tabPage3);
            tabControl1.Dock = DockStyle.Fill;
            tabControl1.Location = new Point(0, 0);
            tabControl1.Margin = new Padding(4, 3, 4, 3);
            tabControl1.Name = "tabControl1";
            tabControl1.SelectedIndex = 0;
            tabControl1.Size = new Size(880, 420);
            tabControl1.TabIndex = 2;
            // 
            // tabPage4
            // 
            tabPage4.BackColor = Color.FromArgb(51, 51, 76);
            tabPage4.Controls.Add(panel4);
            tabPage4.Controls.Add(iconPictureBox7);
            tabPage4.Controls.Add(label7);
            tabPage4.Controls.Add(iconPictureBox6);
            tabPage4.Controls.Add(label11);
            tabPage4.Controls.Add(clearbtn);
            tabPage4.Controls.Add(R_datagrid);
            tabPage4.Controls.Add(Res_idsearch);
            tabPage4.Controls.Add(Res_searchbtn);
            tabPage4.Font = new Font("Microsoft Sans Serif", 11F, FontStyle.Bold);
            tabPage4.Location = new Point(4, 4);
            tabPage4.Margin = new Padding(4, 3, 4, 3);
            tabPage4.Name = "tabPage4";
            tabPage4.Size = new Size(872, 392);
            tabPage4.TabIndex = 4;
            tabPage4.Text = "Search Reservation";
            // 
            // panel4
            // 
            panel4.BackColor = Color.Gray;
            panel4.Location = new Point(176, 88);
            panel4.Name = "panel4";
            panel4.Size = new Size(250, 1);
            panel4.TabIndex = 70;
            // 
            // iconPictureBox7
            // 
            iconPictureBox7.BackColor = Color.FromArgb(51, 51, 76);
            iconPictureBox7.ForeColor = SystemColors.AppWorkspace;
            iconPictureBox7.IconChar = FontAwesome.Sharp.IconChar.Search;
            iconPictureBox7.IconColor = SystemColors.AppWorkspace;
            iconPictureBox7.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconPictureBox7.IconSize = 39;
            iconPictureBox7.Location = new Point(8, 52);
            iconPictureBox7.Name = "iconPictureBox7";
            iconPictureBox7.Size = new Size(39, 48);
            iconPictureBox7.TabIndex = 67;
            iconPictureBox7.TabStop = false;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Sitka Banner", 14.2499981F, FontStyle.Bold);
            label7.ForeColor = SystemColors.AppWorkspace;
            label7.Location = new Point(44, 59);
            label7.Margin = new Padding(4, 0, 4, 0);
            label7.Name = "label7";
            label7.Size = new Size(125, 28);
            label7.TabIndex = 66;
            label7.Text = "Reservation ID";
            // 
            // iconPictureBox6
            // 
            iconPictureBox6.BackColor = Color.FromArgb(51, 51, 76);
            iconPictureBox6.ForeColor = SystemColors.AppWorkspace;
            iconPictureBox6.IconChar = FontAwesome.Sharp.IconChar.Ticket;
            iconPictureBox6.IconColor = SystemColors.AppWorkspace;
            iconPictureBox6.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconPictureBox6.IconSize = 39;
            iconPictureBox6.Location = new Point(8, 5);
            iconPictureBox6.Name = "iconPictureBox6";
            iconPictureBox6.Size = new Size(39, 46);
            iconPictureBox6.TabIndex = 53;
            iconPictureBox6.TabStop = false;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new Font("Sitka Banner", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label11.ForeColor = Color.FromArgb(204, 204, 204);
            label11.Location = new Point(44, 5);
            label11.Name = "label11";
            label11.Size = new Size(205, 35);
            label11.TabIndex = 52;
            label11.Text = "Search Reservation";
            // 
            // clearbtn
            // 
            clearbtn.BackColor = Color.FromArgb(51, 51, 76);
            clearbtn.FlatStyle = FlatStyle.Flat;
            clearbtn.Font = new Font("Sitka Banner", 14F, FontStyle.Bold);
            clearbtn.ForeColor = SystemColors.AppWorkspace;
            clearbtn.Location = new Point(668, 52);
            clearbtn.Margin = new Padding(4, 3, 4, 3);
            clearbtn.Name = "clearbtn";
            clearbtn.Size = new Size(195, 42);
            clearbtn.TabIndex = 32;
            clearbtn.Text = "Display Reservations";
            clearbtn.UseVisualStyleBackColor = false;
            clearbtn.Click += clearbtn_Click;
            // 
            // R_datagrid
            // 
            R_datagrid.BackgroundColor = Color.FromArgb(51, 51, 76);
            R_datagrid.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            R_datagrid.Dock = DockStyle.Bottom;
            R_datagrid.Location = new Point(0, 122);
            R_datagrid.Margin = new Padding(4, 3, 4, 3);
            R_datagrid.Name = "R_datagrid";
            R_datagrid.RowHeadersWidth = 62;
            R_datagrid.Size = new Size(872, 270);
            R_datagrid.TabIndex = 31;
            R_datagrid.CellContentClick += R_datagrid_CellContentClick;
            // 
            // Res_searchbtn
            // 
            Res_searchbtn.BackColor = Color.FromArgb(51, 51, 76);
            Res_searchbtn.FlatStyle = FlatStyle.Flat;
            Res_searchbtn.Font = new Font("Sitka Banner", 14F, FontStyle.Bold);
            Res_searchbtn.ForeColor = SystemColors.AppWorkspace;
            Res_searchbtn.Location = new Point(444, 52);
            Res_searchbtn.Margin = new Padding(4, 3, 4, 3);
            Res_searchbtn.Name = "Res_searchbtn";
            Res_searchbtn.RightToLeft = RightToLeft.No;
            Res_searchbtn.Size = new Size(201, 42);
            Res_searchbtn.TabIndex = 28;
            Res_searchbtn.Text = "Search Reservation";
            Res_searchbtn.UseVisualStyleBackColor = false;
            Res_searchbtn.Click += Res_searchbtn_Click;
            // 
            // tabPage3
            // 
            tabPage3.BackColor = Color.FromArgb(51, 51, 76);
            tabPage3.Controls.Add(iconPictureBox14);
            tabPage3.Controls.Add(label15);
            tabPage3.Controls.Add(button1);
            tabPage3.Controls.Add(dataGridView1);
            tabPage3.Location = new Point(4, 4);
            tabPage3.Margin = new Padding(2);
            tabPage3.Name = "tabPage3";
            tabPage3.Padding = new Padding(2);
            tabPage3.Size = new Size(872, 392);
            tabPage3.TabIndex = 5;
            tabPage3.Text = "AuditTable";
            // 
            // iconPictureBox14
            // 
            iconPictureBox14.BackColor = Color.FromArgb(51, 51, 76);
            iconPictureBox14.ForeColor = SystemColors.AppWorkspace;
            iconPictureBox14.IconChar = FontAwesome.Sharp.IconChar.Search;
            iconPictureBox14.IconColor = SystemColors.AppWorkspace;
            iconPictureBox14.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconPictureBox14.IconSize = 39;
            iconPictureBox14.Location = new Point(31, 20);
            iconPictureBox14.Name = "iconPictureBox14";
            iconPictureBox14.Size = new Size(39, 48);
            iconPictureBox14.TabIndex = 69;
            iconPictureBox14.TabStop = false;
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.Font = new Font("Sitka Banner", 14.2499981F, FontStyle.Bold);
            label15.ForeColor = SystemColors.AppWorkspace;
            label15.Location = new Point(67, 27);
            label15.Margin = new Padding(4, 0, 4, 0);
            label15.Name = "label15";
            label15.Size = new Size(232, 28);
            label15.TabIndex = 68;
            label15.Text = "Reservation Previous Record";
            // 
            // button1
            // 
            button1.BackColor = Color.FromArgb(51, 51, 76);
            button1.FlatStyle = FlatStyle.Flat;
            button1.Font = new Font("Sitka Banner", 18F, FontStyle.Bold);
            button1.ForeColor = SystemColors.AppWorkspace;
            button1.Location = new Point(400, 22);
            button1.Margin = new Padding(4, 3, 4, 3);
            button1.Name = "button1";
            button1.RightToLeft = RightToLeft.No;
            button1.Size = new Size(297, 42);
            button1.TabIndex = 44;
            button1.Text = "Display";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // dataGridView1
            // 
            dataGridView1.BackgroundColor = Color.FromArgb(51, 51, 76);
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Dock = DockStyle.Bottom;
            dataGridView1.Location = new Point(2, 93);
            dataGridView1.Margin = new Padding(2);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 62;
            dataGridView1.RowTemplate.Height = 28;
            dataGridView1.Size = new Size(868, 297);
            dataGridView1.TabIndex = 0;
            dataGridView1.CellContentClick += dataGridView1_CellContentClick;
            // 
            // Reservation
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(39, 39, 58);
            ClientSize = new Size(880, 420);
            Controls.Add(tabControl1);
            FormBorderStyle = FormBorderStyle.None;
            Margin = new Padding(4, 3, 4, 3);
            Name = "Reservation";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Reservation";
            Load += Reservation_Load;
            tabPage2.ResumeLayout(false);
            tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox5).EndInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox4).EndInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox3).EndInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox10).EndInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox1).EndInit();
            tabPage1.ResumeLayout(false);
            tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox13).EndInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox12).EndInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox11).EndInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox9).EndInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox8).EndInit();
            tabControl1.ResumeLayout(false);
            tabPage4.ResumeLayout(false);
            tabPage4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox7).EndInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox6).EndInit();
            ((System.ComponentModel.ISupportInitialize)R_datagrid).EndInit();
            tabPage3.ResumeLayout(false);
            tabPage3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox14).EndInit();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private System.Windows.Forms.TextBox Res_idsearch;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Button Res_addGbtn;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TextBox txtReservationID;
        private System.Windows.Forms.Button updateGbtn;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.DataGridView R_datagrid;
        private System.Windows.Forms.Button Res_searchbtn;
        private System.Windows.Forms.DateTimePicker checkin;
        private System.Windows.Forms.ComboBox Rtypecombo;
        private System.Windows.Forms.DateTimePicker checkout;
        private System.Windows.Forms.ComboBox R_nocombo;
        private System.Windows.Forms.Button clearbtn;
        private System.Windows.Forms.DateTimePicker OutdateTime;
        private System.Windows.Forms.ComboBox Typecombo;
        private System.Windows.Forms.TextBox G_combo;
        private System.Windows.Forms.ComboBox Nocombo;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button button1;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox1;
        private Label label1;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox10;
        private Label label6;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox5;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox4;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox3;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox2;
        private Panel panel17;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox6;
        private Label label11;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox7;
        private Label label7;
        private Panel panel4;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox8;
        private Label label10;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox11;
        private Label label12;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox9;
        private Label label14;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox13;
        private Label label9;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox12;
        private Label label8;
        private Panel panel1;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox14;
        private Label label15;
    }
}
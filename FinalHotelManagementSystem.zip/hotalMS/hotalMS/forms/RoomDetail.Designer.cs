﻿namespace hotalMS.forms
{
    partial class RoomDetail
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label3 = new Label();
            Displaybtn = new Button();
            label2 = new Label();
            Rtyp = new TextBox();
            label1 = new Label();
            R_idsearch = new TextBox();
            dataGridView1 = new DataGridView();
            iconRoomId = new FontAwesome.Sharp.IconPictureBox();
            iconRoomstatus = new FontAwesome.Sharp.IconPictureBox();
            iconPictureBox1 = new FontAwesome.Sharp.IconPictureBox();
            iconPictureBox2 = new FontAwesome.Sharp.IconPictureBox();
            iconPictureBox3 = new FontAwesome.Sharp.IconPictureBox();
            panel17 = new Panel();
            panel1 = new Panel();
            panel4 = new Panel();
            panel2 = new Panel();
            panel3 = new Panel();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)iconRoomId).BeginInit();
            ((System.ComponentModel.ISupportInitialize)iconRoomstatus).BeginInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox3).BeginInit();
            SuspendLayout();
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Sitka Banner", 20F, FontStyle.Bold);
            label3.ForeColor = SystemColors.AppWorkspace;
            label3.Location = new Point(54, 9);
            label3.Margin = new Padding(2, 0, 2, 0);
            label3.Name = "label3";
            label3.Size = new Size(125, 39);
            label3.TabIndex = 92;
            label3.Text = "RoomInfo";
            label3.Click += label3_Click;
            // 
            // Displaybtn
            // 
            Displaybtn.BackColor = Color.FromArgb(51, 51, 76);
            Displaybtn.Font = new Font("Sitka Banner", 14F, FontStyle.Bold);
            Displaybtn.ForeColor = SystemColors.AppWorkspace;
            Displaybtn.Location = new Point(577, 137);
            Displaybtn.Margin = new Padding(3, 4, 3, 4);
            Displaybtn.Name = "Displaybtn";
            Displaybtn.RightToLeft = RightToLeft.No;
            Displaybtn.Size = new Size(291, 41);
            Displaybtn.TabIndex = 91;
            Displaybtn.Text = "Display Room Detail";
            Displaybtn.UseVisualStyleBackColor = false;
            Displaybtn.Click += Displaybtn_Click;
            // 
            // label2
            // 
            label2.Font = new Font("Sitka Banner", 14.2499981F, FontStyle.Bold);
            label2.ForeColor = SystemColors.AppWorkspace;
            label2.Location = new Point(469, 72);
            label2.Name = "label2";
            label2.Size = new Size(110, 41);
            label2.TabIndex = 89;
            label2.Text = "Room Status";
            // 
            // Rtyp
            // 
            Rtyp.BackColor = Color.FromArgb(51, 51, 76);
            Rtyp.BorderStyle = BorderStyle.None;
            Rtyp.Font = new Font("Sitka Banner", 14.2499981F, FontStyle.Bold);
            Rtyp.ForeColor = SystemColors.AppWorkspace;
            Rtyp.Location = new Point(585, 63);
            Rtyp.Margin = new Padding(3, 4, 3, 4);
            Rtyp.Multiline = true;
            Rtyp.Name = "Rtyp";
            Rtyp.Size = new Size(252, 36);
            Rtyp.TabIndex = 88;
            // 
            // label1
            // 
            label1.Font = new Font("Sitka Banner", 14.2499981F, FontStyle.Bold);
            label1.ForeColor = SystemColors.AppWorkspace;
            label1.Location = new Point(40, 72);
            label1.Name = "label1";
            label1.Size = new Size(85, 32);
            label1.TabIndex = 86;
            label1.Text = "Room ID";
            // 
            // R_idsearch
            // 
            R_idsearch.BackColor = Color.FromArgb(51, 51, 76);
            R_idsearch.BorderStyle = BorderStyle.None;
            R_idsearch.Font = new Font("Sitka Banner", 14.2499981F, FontStyle.Bold);
            R_idsearch.ForeColor = SystemColors.AppWorkspace;
            R_idsearch.Location = new Point(140, 67);
            R_idsearch.Margin = new Padding(3, 4, 3, 4);
            R_idsearch.Multiline = true;
            R_idsearch.Name = "R_idsearch";
            R_idsearch.Size = new Size(248, 32);
            R_idsearch.TabIndex = 85;
            // 
            // dataGridView1
            // 
            dataGridView1.BackgroundColor = Color.FromArgb(204, 204, 204);
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Dock = DockStyle.Bottom;
            dataGridView1.Location = new Point(0, 193);
            dataGridView1.Margin = new Padding(2);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 62;
            dataGridView1.RowTemplate.Height = 28;
            dataGridView1.Size = new Size(880, 227);
            dataGridView1.TabIndex = 84;
            // 
            // iconRoomId
            // 
            iconRoomId.BackColor = Color.FromArgb(51, 51, 76);
            iconRoomId.ForeColor = SystemColors.AppWorkspace;
            iconRoomId.IconChar = FontAwesome.Sharp.IconChar.Search;
            iconRoomId.IconColor = SystemColors.AppWorkspace;
            iconRoomId.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconRoomId.Location = new Point(379, 67);
            iconRoomId.Name = "iconRoomId";
            iconRoomId.Size = new Size(32, 32);
            iconRoomId.TabIndex = 93;
            iconRoomId.TabStop = false;
            iconRoomId.Click += iconRoomId_Click;
            // 
            // iconRoomstatus
            // 
            iconRoomstatus.BackColor = Color.FromArgb(51, 51, 76);
            iconRoomstatus.ForeColor = SystemColors.AppWorkspace;
            iconRoomstatus.IconChar = FontAwesome.Sharp.IconChar.Search;
            iconRoomstatus.IconColor = SystemColors.AppWorkspace;
            iconRoomstatus.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconRoomstatus.Location = new Point(836, 67);
            iconRoomstatus.Name = "iconRoomstatus";
            iconRoomstatus.Size = new Size(32, 32);
            iconRoomstatus.TabIndex = 94;
            iconRoomstatus.TabStop = false;
            iconRoomstatus.Click += iconRoomstatus_Click;
            // 
            // iconPictureBox1
            // 
            iconPictureBox1.BackColor = Color.FromArgb(51, 51, 76);
            iconPictureBox1.ForeColor = SystemColors.AppWorkspace;
            iconPictureBox1.IconChar = FontAwesome.Sharp.IconChar.Bed;
            iconPictureBox1.IconColor = SystemColors.AppWorkspace;
            iconPictureBox1.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconPictureBox1.IconSize = 45;
            iconPictureBox1.Location = new Point(12, 9);
            iconPictureBox1.Name = "iconPictureBox1";
            iconPictureBox1.Size = new Size(46, 45);
            iconPictureBox1.TabIndex = 95;
            iconPictureBox1.TabStop = false;
            // 
            // iconPictureBox2
            // 
            iconPictureBox2.BackColor = Color.FromArgb(51, 51, 76);
            iconPictureBox2.ForeColor = SystemColors.AppWorkspace;
            iconPictureBox2.IconChar = FontAwesome.Sharp.IconChar.BedPulse;
            iconPictureBox2.IconColor = SystemColors.AppWorkspace;
            iconPictureBox2.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconPictureBox2.Location = new Point(12, 73);
            iconPictureBox2.Name = "iconPictureBox2";
            iconPictureBox2.Size = new Size(32, 32);
            iconPictureBox2.TabIndex = 96;
            iconPictureBox2.TabStop = false;
            // 
            // iconPictureBox3
            // 
            iconPictureBox3.BackColor = Color.FromArgb(51, 51, 76);
            iconPictureBox3.ForeColor = SystemColors.AppWorkspace;
            iconPictureBox3.IconChar = FontAwesome.Sharp.IconChar.BedPulse;
            iconPictureBox3.IconColor = SystemColors.AppWorkspace;
            iconPictureBox3.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconPictureBox3.Location = new Point(440, 72);
            iconPictureBox3.Name = "iconPictureBox3";
            iconPictureBox3.Size = new Size(32, 32);
            iconPictureBox3.TabIndex = 97;
            iconPictureBox3.TabStop = false;
            // 
            // panel17
            // 
            panel17.BackColor = Color.Gray;
            panel17.Location = new Point(142, 98);
            panel17.Name = "panel17";
            panel17.Size = new Size(246, 1);
            panel17.TabIndex = 98;
            // 
            // panel1
            // 
            panel1.BackColor = Color.Gray;
            panel1.Location = new Point(585, 98);
            panel1.Name = "panel1";
            panel1.Size = new Size(250, 1);
            panel1.TabIndex = 99;
            // 
            // panel4
            // 
            panel4.BackColor = SystemColors.ButtonFace;
            panel4.Dock = DockStyle.Left;
            panel4.Location = new Point(0, 0);
            panel4.Name = "panel4";
            panel4.Size = new Size(5, 193);
            panel4.TabIndex = 100;
            // 
            // panel2
            // 
            panel2.BackColor = SystemColors.ButtonFace;
            panel2.Dock = DockStyle.Top;
            panel2.Location = new Point(5, 0);
            panel2.Name = "panel2";
            panel2.Size = new Size(875, 5);
            panel2.TabIndex = 101;
            // 
            // panel3
            // 
            panel3.BackColor = SystemColors.ButtonFace;
            panel3.Dock = DockStyle.Right;
            panel3.Location = new Point(875, 5);
            panel3.Name = "panel3";
            panel3.Size = new Size(5, 188);
            panel3.TabIndex = 102;
            // 
            // RoomDetail
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(51, 51, 76);
            ClientSize = new Size(880, 420);
            Controls.Add(panel3);
            Controls.Add(panel2);
            Controls.Add(panel4);
            Controls.Add(panel1);
            Controls.Add(panel17);
            Controls.Add(iconPictureBox3);
            Controls.Add(iconPictureBox2);
            Controls.Add(iconPictureBox1);
            Controls.Add(iconRoomstatus);
            Controls.Add(iconRoomId);
            Controls.Add(label3);
            Controls.Add(Displaybtn);
            Controls.Add(label2);
            Controls.Add(Rtyp);
            Controls.Add(label1);
            Controls.Add(R_idsearch);
            Controls.Add(dataGridView1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "RoomDetail";
            Text = "RoomDetail";
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ((System.ComponentModel.ISupportInitialize)iconRoomId).EndInit();
            ((System.ComponentModel.ISupportInitialize)iconRoomstatus).EndInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox3).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label3;
        private Button Displaybtn;
        private Label label2;
        private TextBox Rtyp;
        private Label label1;
        private TextBox R_idsearch;
        private DataGridView dataGridView1;
        private FontAwesome.Sharp.IconPictureBox iconRoomId;
        private FontAwesome.Sharp.IconPictureBox iconRoomstatus;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox1;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox2;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox3;
        private Panel panel17;
        private Panel panel1;
        private Panel panel4;
        private Panel panel2;
        private Panel panel3;
    }
}
﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace hotalMS.forms
{
    public partial class ViewDetails : Form
    {
        public ViewDetails()
        {
            InitializeComponent();
        }

        private void searchbtn_Click(object sender, EventArgs e)
        {
            Search();
        }

        SqlConnection con = new SqlConnection("Data Source=DESKTOP-KFDUOB5\\MSSQLSERVER2022;Initial Catalog=HotelManagementSystem;Integrated Security=True;Encrypt=True;TrustServerCertificate=True");
        
        public void Search()
        {
            try
            {

                if (checktext.SelectedItem == null)
                {
                    MessageBox.Show("Please select a search option (ViewGuestInfo,ViewReservationInfo,RoomInfo Or MembershipInfo).");
                    return;
                }
                
                    //string searchTerm = detailsearchtxt.Text.Trim();
                    if (checktext.SelectedItem.ToString() == "GuestInfo")
                    {
                        con.Open();
                        string query = "select * from Guests";

                        SqlCommand cmd = new SqlCommand(query, con);
                        cmd.ExecuteNonQuery();
                        SqlDataAdapter da = new SqlDataAdapter(cmd);
                        SqlCommandBuilder cb = new SqlCommandBuilder(da);
                        var ds = new DataSet();
                        da.Fill(ds);
                        detailgrid.DataSource = ds.Tables[0];
                        con.Close();
                    }

                   else if (checktext.SelectedItem.ToString() == "ReservationInfo")
                    {
                        con.Open();
                        string query = "select * from Reservations";

                        SqlCommand cmd = new SqlCommand(query, con);
                        cmd.ExecuteNonQuery();
                        SqlDataAdapter da = new SqlDataAdapter(cmd);
                        SqlCommandBuilder cb = new SqlCommandBuilder(da);
                        var ds = new DataSet();
                        da.Fill(ds);
                        detailgrid.DataSource = ds.Tables[0];
                        con.Close();
                    }
                    else if (checktext.SelectedItem.ToString() == "RoomInfo")
                    {
                        con.Open();
                        string query = "select * from ReservationView";

                        SqlCommand cmd = new SqlCommand(query, con);
                        cmd.ExecuteNonQuery();
                        SqlDataAdapter da = new SqlDataAdapter(cmd);
                        SqlCommandBuilder cb = new SqlCommandBuilder(da);
                        var ds = new DataSet();
                        da.Fill(ds);
                        detailgrid.DataSource = ds.Tables[0];
                        con.Close();
                    }
                    else if (checktext.SelectedItem.ToString() == "MembershipInfo")
                    {
                        con.Open();
                        string query = "select * from Memberships";

                        SqlCommand cmd = new SqlCommand(query, con);
                        cmd.ExecuteNonQuery();
                        SqlDataAdapter da = new SqlDataAdapter(cmd);
                        SqlCommandBuilder cb = new SqlCommandBuilder(da);
                        var ds = new DataSet();
                        da.Fill(ds);
                        detailgrid.DataSource = ds.Tables[0];
                        con.Close();
                    }


                  
                //}
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
            finally
            {
                con.Close();
               
            }
        }

    }
}

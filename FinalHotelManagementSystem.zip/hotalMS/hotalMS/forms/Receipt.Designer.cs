﻿
namespace DBMS_HMS
{
    partial class Receipt
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Receipt));
            label2 = new Label();
            printDocument1 = new System.Drawing.Printing.PrintDocument();
            printPreviewDialog1 = new PrintPreviewDialog();
            txtReceipt = new TextBox();
            iconPictureBox5 = new FontAwesome.Sharp.IconPictureBox();
            label1 = new Label();
            Displaybtn = new Button();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox5).BeginInit();
            SuspendLayout();
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label2.ForeColor = SystemColors.AppWorkspace;
            label2.Location = new Point(430, 0);
            label2.Name = "label2";
            label2.Size = new Size(25, 30);
            label2.TabIndex = 78;
            label2.Text = "X";
            label2.Click += label2_Click;
            // 
            // printDocument1
            // 
            printDocument1.PrintPage += printDocument1_PrintPage;
            // 
            // printPreviewDialog1
            // 
            printPreviewDialog1.AutoScrollMargin = new Size(0, 0);
            printPreviewDialog1.AutoScrollMinSize = new Size(0, 0);
            printPreviewDialog1.ClientSize = new Size(400, 300);
            printPreviewDialog1.Enabled = true;
            printPreviewDialog1.Icon = (Icon)resources.GetObject("printPreviewDialog1.Icon");
            printPreviewDialog1.Name = "printPreviewDialog1";
            printPreviewDialog1.Visible = false;
            // 
            // txtReceipt
            // 
            txtReceipt.Location = new Point(37, 77);
            txtReceipt.MaxLength = 42767;
            txtReceipt.Multiline = true;
            txtReceipt.Name = "txtReceipt";
            txtReceipt.Size = new Size(383, 481);
            txtReceipt.TabIndex = 79;
            // 
            // iconPictureBox5
            // 
            iconPictureBox5.BackColor = Color.FromArgb(51, 51, 76);
            iconPictureBox5.ForeColor = SystemColors.AppWorkspace;
            iconPictureBox5.IconChar = FontAwesome.Sharp.IconChar.Hotel;
            iconPictureBox5.IconColor = SystemColors.AppWorkspace;
            iconPictureBox5.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconPictureBox5.Location = new Point(89, 28);
            iconPictureBox5.Name = "iconPictureBox5";
            iconPictureBox5.Size = new Size(32, 32);
            iconPictureBox5.TabIndex = 81;
            iconPictureBox5.TabStop = false;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Sitka Banner", 14.2499981F, FontStyle.Bold);
            label1.ForeColor = SystemColors.AppWorkspace;
            label1.Location = new Point(117, 28);
            label1.Name = "label1";
            label1.Size = new Size(216, 28);
            label1.TabIndex = 80;
            label1.Text = "Hotel Management System";
            // 
            // Displaybtn
            // 
            Displaybtn.BackColor = Color.FromArgb(51, 51, 76);
            Displaybtn.Font = new Font("Sitka Banner", 14F, FontStyle.Bold);
            Displaybtn.ForeColor = SystemColors.AppWorkspace;
            Displaybtn.Location = new Point(89, 583);
            Displaybtn.Margin = new Padding(3, 4, 3, 4);
            Displaybtn.Name = "Displaybtn";
            Displaybtn.RightToLeft = RightToLeft.No;
            Displaybtn.Size = new Size(291, 41);
            Displaybtn.TabIndex = 92;
            Displaybtn.Text = "Print Receipt";
            Displaybtn.UseVisualStyleBackColor = false;
            Displaybtn.Click += Displaybtn_Click;
            // 
            // Receipt
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(51, 51, 76);
            ClientSize = new Size(457, 637);
            Controls.Add(Displaybtn);
            Controls.Add(iconPictureBox5);
            Controls.Add(label1);
            Controls.Add(txtReceipt);
            Controls.Add(label2);
            FormBorderStyle = FormBorderStyle.None;
            Margin = new Padding(2);
            Name = "Receipt";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Receipt";
            Load += Receipt_Load;
            ((System.ComponentModel.ISupportInitialize)iconPictureBox5).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Label label2;
        private System.Drawing.Printing.PrintDocument printDocument1;
        private PrintPreviewDialog printPreviewDialog1;
        private TextBox txtReceipt;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox5;
        private Label label1;
        private Button Displaybtn;
    }
}
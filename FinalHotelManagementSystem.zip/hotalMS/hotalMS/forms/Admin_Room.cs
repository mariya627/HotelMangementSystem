﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using hotalMS;

namespace DBMS_HMS
{
    public partial class Admin_Room : Form
    {
        public Admin_Room()
        {
            InitializeComponent();
        }
        //SqlConnection con = new SqlConnection("Data Source=MARIYA;Initial Catalog=HostelManagementSystem;Integrated Security=True");
        SqlConnection con = new SqlConnection("Data Source=DESKTOP-KFDUOB5\\MSSQLSERVER2022;Initial Catalog=HotelManagementSystem;Integrated Security=True;Encrypt=True;TrustServerCertificate=True");
        private void Addbtn_Click(object sender, EventArgs e)
        {

        }
        public void Display()
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("select * from Room", con);
            cmd.ExecuteNonQuery();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
            con.Close();

        }


        private void tabPage2_Enter(object sender, EventArgs e)
        {
            //  using (SqlConnection connection = new SqlConnection("Data Source=MAHAD-PC;Initial Catalog=DBMS;Integrated Security=True"))
            {
                con.Open();

                string query = "SELECT * FROM Room WHERE Room_No LIKE @SearchTerm";
                using (SqlCommand command = new SqlCommand(query, con))
                {
                    // Add the search term parameter
                    command.Parameters.AddWithValue("@SearchTerm", "%" + searchtxt.Text + "%");

                    // Execute the query
                    SqlDataReader reader = command.ExecuteReader();

                    // Process the query results
                    while (reader.Read())
                    {
                        // Process each row
                        // Example: string result = reader.GetString(0);
                    }

                    reader.Close();
                }
            }
        }

        private void updatebtn_Click(object sender, EventArgs e)
        {
            int roomid = int.Parse(IDtxt.Text);
            int roomno = int.Parse(roomtxt.Text);
            int limit = int.Parse(limtxt.Text);
            string roomtype = comboBox.Text, price = prtxt.Text, status = Status.Text;
            con.Open();
            SqlCommand c = new SqlCommand("Exec UpdateRoom '" + roomid + "','" + roomno + "','" + roomtype + "','" + limit + "','" + price + "','" + status + "'", con);
            c.ExecuteNonQuery();
            MessageBox.Show("Successfully Updated...");
            con.Close();
            Display();
        }

        private void delbtn_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are you sure you want to delete?", "Delete Document", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                int roomid = int.Parse(IDtxt.Text);
                con.Open();
                SqlCommand c = new SqlCommand("Exec DelRoom '" + roomid + "'", con);
                c.ExecuteNonQuery();
                MessageBox.Show("Successfully Deleted...");
                con.Close();
                Display();
            }
            IDtxt.Text = "";
            RoomNotxt.Text = "";
            Limittxt.Text = "";
            RoomTypecomboBox.SelectedIndex = -1;
            Pricetxt.Text = "";
            Status.Text = "";
        }

        private void searchbtn_Click(object sender, EventArgs e)
        {
            int roomid = int.Parse(searchtxt.Text);
            con.Open();
            SqlCommand c = new SqlCommand("Exec SearchRoom '" + roomid + "'", con);
            c.ExecuteNonQuery();

            SqlDataAdapter da = new SqlDataAdapter(c);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
            con.Close();
        }

        private void RoomTypecomboBox_SelectedIndexChanged(object sender, EventArgs e)
        {

        }



        private void button1_Click(object sender, EventArgs e)
        {
            if (RoomNotxt.Text.Trim() == string.Empty || Limittxt.Text.Trim() == string.Empty || Pricetxt.Text.Trim() == string.Empty || RoomTypecomboBox.Text == string.Empty)
            {
                MessageBox.Show("Please fill all filds.", "Require all fields", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                int roomno = int.Parse(RoomNotxt.Text);
                int limit = int.Parse(Limittxt.Text);
                string roomtype = RoomTypecomboBox.Text, price = Pricetxt.Text, status = "Vacant";
                if (IsRoomNoDuplicate(roomno))
                {
                    MessageBox.Show("Room number already exists. Please enter a unique room number.", "Duplicate Room Number", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
                try
                {
                    con.Open();
                    SqlCommand c = new SqlCommand("Exec AddRoom '" + roomno + "','" + roomtype + "','" + limit + "','" + price + "','" + status + "'", con);
                    c.ExecuteNonQuery();
                    MessageBox.Show("Successfully Inserted...");
                    Display();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error occurred while inserting the room: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                finally
                {
                    con.Close();
                }
                RoomNotxt.Text = "";
                Limittxt.Text = "";
                RoomTypecomboBox.SelectedIndex = -1;
                Pricetxt.Text = "";
            }
        }
        private bool IsRoomNoDuplicate(int roomNo)
        {
            bool isDuplicate = false;
            string query = "SELECT COUNT(*) FROM Room WHERE Room_No = @RoomNo";
            SqlCommand command = new SqlCommand(query, con);
            command.Parameters.AddWithValue("@RoomNo", roomNo);
            con.Open();
            int count = (int)command.ExecuteScalar();
            isDuplicate = (count > 0);
            con.Close();
            return isDuplicate;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //Admin_Home ad = new Admin_Home();
            //ad.Show();
        }

        private void label16_Click(object sender, EventArgs e)
        {
            Visible = false;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Display();
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            //Admin_Home ad = new Admin_Home();
            //this.Hide();
            //ad.Show();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            //Admin_Home ad = new Admin_Home();
            //this.Hide();
            //ad.Show();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {


        }

        private void label15_Click(object sender, EventArgs e)
        {

        }

        private void Admin_Room_Load(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void prtxt_TextChanged(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void iconPictureBox15_Click(object sender, EventArgs e)
        {
            int roomId;
            if (int.TryParse(searchtxt.Text, out roomId))
            {
                using (SqlConnection con = new SqlConnection("Data Source=DESKTOP-KFDUOB5\\MSSQLSERVER2022;Initial Catalog=HotelManagementSystem;Integrated Security=True;Encrypt=True;TrustServerCertificate=True"))
                {
                    con.Open();
                    SqlCommand cmd = new SqlCommand("SearchRoom", con);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@Room_ID", roomId);

                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    dataGridView1.DataSource = dt;

                    con.Close();
                }
            }
            else
            {
                MessageBox.Show("Invalid Room ID!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void tabPage3_Click(object sender, EventArgs e)
        {

        }
    }
}

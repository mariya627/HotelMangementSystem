﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using hotalMS;

namespace DBMS_HMS
{
    public partial class Users : Form
    {
        SqlConnection con = new SqlConnection("Data Source=DESKTOP-KFDUOB5\\MSSQLSERVER2022;Initial Catalog=HotelManagementSystem;Integrated Security=True;Encrypt=True;TrustServerCertificate=True");

        public Users()
        {
            InitializeComponent();
        }

        private void UserNametxt_TextChanged(object sender, EventArgs e)
        {

        }

        private void E_close_Click(object sender, EventArgs e)
        {
            Visible = false;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //Admin_Home ad = new Admin_Home();
            //this.Hide();
            //ad.Show();
        }

        private void addbtn_Click(object sender, EventArgs e)
        {
            if (UserNametxt.Text.Trim() == string.Empty || Passwordtxt.Text.Trim() == string.Empty )
            {
                MessageBox.Show("Please fill all filds.", "Require all fields", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            if (MessageBox.Show("Are you sure you want to add user?", "Add Document", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                con.Open();
                string UserName = UserNametxt.Text;
                string UserPassword = Passwordtxt.Text;
                SqlCommand c = new SqlCommand("Exec AddUser '" + UserName + "','" + UserPassword + "'", con);
                c.ExecuteNonQuery();
                MessageBox.Show("Successfully Inserted...");
                con.Close();
                Display();
            }
        }
        public void Display()
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("select * from Users", con);
            cmd.ExecuteNonQuery();
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
            con.Close();
        }

        private void searchbtn_Click(object sender, EventArgs e)
        {
                string searchTerm = Idtxt.Text.Trim();
                con.Open();
                SqlCommand command;
                SqlDataAdapter adapter = new SqlDataAdapter();
                DataTable dt = new DataTable();

                if (int.TryParse(searchTerm, out int User_ID))
                {
                    // Search by Employee ID
                    command = new SqlCommand("Exec SearchByUserID @User_ID", con);
                    command.Parameters.AddWithValue("@User_ID", User_ID);
                }
                else
                {
                    // Search by UserName
                    command = new SqlCommand("Exec SearchByUserName @UserName", con);
                    command.Parameters.AddWithValue("@UserName", searchTerm);
                }

            adapter.SelectCommand = command;
            adapter.Fill(dt);
            //dataGridView1.DataSource = dt;
            if (dataGridView1.Rows.Count > 0)
            {
                dataGridView1.DataSource = dt;
            }
            else
            {
                MessageBox.Show("User ID or Name  not found in the database.");
            }
            con.Close();


        }

        private void button2_Click(object sender, EventArgs e)
        {
            Display();
        }
        

        private void button3_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are you sure you want to Update?", "Update Document", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {

                int User_ID = int.Parse(UIdtxt.Text);
                con.Open();
                SqlCommand c = new SqlCommand("UpdateUser", con);
                c.CommandType = CommandType.StoredProcedure;
                c.Parameters.AddWithValue("@User_ID", User_ID);
                c.Parameters.AddWithValue("@UserName", UName.Text);
                c.Parameters.AddWithValue("@UserPassword", UPass.Text);
                int rowsaffected = c.ExecuteNonQuery();
                MessageBox.Show("Successfully Updated...");

                con.Close();

            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are you sure you want to delete?", "Delete Document", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                int User_ID = int.Parse(UIdtxt.Text);
                con.Open();
                SqlCommand c = new SqlCommand("Exec DeleteUser '" + User_ID + "'", con);
                c.ExecuteNonQuery();
                MessageBox.Show("Successfully Deleted...");
                con.Close();
                UIdtxt.Clear();
                Display();
            }
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            //Admin_Home ad = new Admin_Home();
            //this.Hide();
            //ad.Show();
        }

        private void UIdtxt_TextChanged(object sender, EventArgs e)
        {
            int userId = int.Parse(UIdtxt.Text);

            // Perform database query to fetch user details based on userId
            string query = "SELECT UserName, UserPassword FROM Users WHERE User_ID = @UserId";

            using (SqlConnection connection = new SqlConnection("Data Source=DESKTOP-KFDUOB5\\MSSQLSERVER2022;Initial Catalog=HotelManagementSystem;Integrated Security=True;Encrypt=True;TrustServerCertificate=True"))
            {
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@UserId", userId);

                connection.Open();

                SqlDataReader reader = command.ExecuteReader();
                if (reader.Read())
                {
                    string userName = reader.GetString(reader.GetOrdinal("UserName"));
                    string userPassword = reader.GetString(reader.GetOrdinal("UserPassword"));

                    UName.Text = userName;
                    UPass.Text = userPassword;
                }
                else
                {
                    UName.Text = string.Empty;
                    UPass.Text = string.Empty;
                }

                reader.Close();
            }
        }

        private void tabPage2_Click(object sender, EventArgs e)
        {

        }
    }
}

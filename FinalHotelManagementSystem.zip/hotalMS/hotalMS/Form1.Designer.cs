﻿namespace hotalMS
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            panelMenu = new Panel();
            iconroomD = new FontAwesome.Sharp.IconPictureBox();
            iconlog = new FontAwesome.Sharp.IconPictureBox();
            logoutbtn = new Button();
            RoomDbtn = new Button();
            iconservice = new FontAwesome.Sharp.IconPictureBox();
            iconcheckout = new FontAwesome.Sharp.IconPictureBox();
            checkoutbtn = new Button();
            iconser = new FontAwesome.Sharp.IconPictureBox();
            serbtn = new Button();
            iconfac = new FontAwesome.Sharp.IconPictureBox();
            iconres = new FontAwesome.Sharp.IconPictureBox();
            iconmem = new FontAwesome.Sharp.IconPictureBox();
            iconbox2 = new FontAwesome.Sharp.IconPictureBox();
            iconguest = new FontAwesome.Sharp.IconPictureBox();
            Membershipbtn = new Button();
            Resbtn = new Button();
            Guestbtn = new Button();
            panellogo = new Panel();
            iconPictureBox1 = new FontAwesome.Sharp.IconPictureBox();
            label1 = new Label();
            notifyIcon1 = new NotifyIcon(components);
            paneltitle = new Panel();
            iconPictureBox4 = new FontAwesome.Sharp.IconPictureBox();
            labeltitle = new Label();
            paneldesktop = new Panel();
            panelMenu.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)iconroomD).BeginInit();
            ((System.ComponentModel.ISupportInitialize)iconlog).BeginInit();
            ((System.ComponentModel.ISupportInitialize)iconservice).BeginInit();
            ((System.ComponentModel.ISupportInitialize)iconcheckout).BeginInit();
            ((System.ComponentModel.ISupportInitialize)iconser).BeginInit();
            ((System.ComponentModel.ISupportInitialize)iconfac).BeginInit();
            ((System.ComponentModel.ISupportInitialize)iconres).BeginInit();
            ((System.ComponentModel.ISupportInitialize)iconmem).BeginInit();
            ((System.ComponentModel.ISupportInitialize)iconbox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)iconguest).BeginInit();
            panellogo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox1).BeginInit();
            paneltitle.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox4).BeginInit();
            SuspendLayout();
            // 
            // panelMenu
            // 
            panelMenu.BackColor = Color.FromArgb(51, 51, 76);
            panelMenu.Controls.Add(iconroomD);
            panelMenu.Controls.Add(iconlog);
            panelMenu.Controls.Add(logoutbtn);
            panelMenu.Controls.Add(RoomDbtn);
            panelMenu.Controls.Add(iconservice);
            panelMenu.Controls.Add(iconcheckout);
            panelMenu.Controls.Add(checkoutbtn);
            panelMenu.Controls.Add(iconser);
            panelMenu.Controls.Add(serbtn);
            panelMenu.Controls.Add(iconfac);
            panelMenu.Controls.Add(iconres);
            panelMenu.Controls.Add(iconmem);
            panelMenu.Controls.Add(iconbox2);
            panelMenu.Controls.Add(iconguest);
            panelMenu.Controls.Add(Membershipbtn);
            panelMenu.Controls.Add(Resbtn);
            panelMenu.Controls.Add(Guestbtn);
            panelMenu.Controls.Add(panellogo);
            panelMenu.Dock = DockStyle.Left;
            panelMenu.Location = new Point(0, 0);
            panelMenu.Name = "panelMenu";
            panelMenu.Size = new Size(220, 500);
            panelMenu.TabIndex = 0;
            // 
            // iconroomD
            // 
            iconroomD.BackColor = Color.FromArgb(51, 51, 76);
            iconroomD.ForeColor = Color.Gainsboro;
            iconroomD.IconChar = FontAwesome.Sharp.IconChar.BookOpen;
            iconroomD.IconColor = Color.Gainsboro;
            iconroomD.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconroomD.Location = new Point(6, 402);
            iconroomD.Name = "iconroomD";
            iconroomD.Size = new Size(37, 32);
            iconroomD.TabIndex = 69;
            iconroomD.TabStop = false;
            // 
            // iconlog
            // 
            iconlog.BackColor = Color.FromArgb(51, 51, 76);
            iconlog.ForeColor = SystemColors.AppWorkspace;
            iconlog.IconChar = FontAwesome.Sharp.IconChar.SignOut;
            iconlog.IconColor = SystemColors.AppWorkspace;
            iconlog.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconlog.Location = new Point(6, 456);
            iconlog.Name = "iconlog";
            iconlog.Size = new Size(32, 32);
            iconlog.TabIndex = 68;
            iconlog.TabStop = false;
            // 
            // logoutbtn
            // 
            logoutbtn.Dock = DockStyle.Top;
            logoutbtn.FlatAppearance.BorderSize = 0;
            logoutbtn.FlatStyle = FlatStyle.Flat;
            logoutbtn.Font = new Font("Sitka Banner", 14.2499981F, FontStyle.Bold);
            logoutbtn.ForeColor = Color.Gainsboro;
            logoutbtn.Location = new Point(0, 440);
            logoutbtn.Name = "logoutbtn";
            logoutbtn.Size = new Size(220, 60);
            logoutbtn.TabIndex = 67;
            logoutbtn.Text = "LogOut";
            logoutbtn.TextImageRelation = TextImageRelation.ImageBeforeText;
            logoutbtn.UseVisualStyleBackColor = true;
            logoutbtn.Click += logoutbtn_Click;
            // 
            // RoomDbtn
            // 
            RoomDbtn.Dock = DockStyle.Top;
            RoomDbtn.FlatAppearance.BorderSize = 0;
            RoomDbtn.FlatStyle = FlatStyle.Flat;
            RoomDbtn.Font = new Font("Sitka Banner", 14.2499981F, FontStyle.Bold);
            RoomDbtn.ForeColor = Color.Gainsboro;
            RoomDbtn.Location = new Point(0, 380);
            RoomDbtn.Name = "RoomDbtn";
            RoomDbtn.Size = new Size(220, 60);
            RoomDbtn.TabIndex = 17;
            RoomDbtn.Text = "RoomDetails";
            RoomDbtn.TextImageRelation = TextImageRelation.ImageBeforeText;
            RoomDbtn.UseVisualStyleBackColor = true;
            RoomDbtn.Click += RoomDbtn_Click;
            // 
            // iconservice
            // 
            iconservice.BackColor = Color.FromArgb(51, 51, 76);
            iconservice.ForeColor = Color.Gainsboro;
            iconservice.IconChar = FontAwesome.Sharp.IconChar.HandHoldingHeart;
            iconservice.IconColor = Color.Gainsboro;
            iconservice.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconservice.Location = new Point(6, 282);
            iconservice.Name = "iconservice";
            iconservice.Size = new Size(37, 32);
            iconservice.TabIndex = 16;
            iconservice.TabStop = false;
            // 
            // iconcheckout
            // 
            iconcheckout.BackColor = Color.FromArgb(51, 51, 76);
            iconcheckout.ForeColor = Color.Gainsboro;
            iconcheckout.IconChar = FontAwesome.Sharp.IconChar.CheckCircle;
            iconcheckout.IconColor = Color.Gainsboro;
            iconcheckout.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconcheckout.Location = new Point(6, 337);
            iconcheckout.Name = "iconcheckout";
            iconcheckout.Size = new Size(37, 32);
            iconcheckout.TabIndex = 15;
            iconcheckout.TabStop = false;
            // 
            // checkoutbtn
            // 
            checkoutbtn.Dock = DockStyle.Top;
            checkoutbtn.FlatAppearance.BorderSize = 0;
            checkoutbtn.FlatStyle = FlatStyle.Flat;
            checkoutbtn.Font = new Font("Sitka Banner", 14.2499981F, FontStyle.Bold);
            checkoutbtn.ForeColor = Color.Gainsboro;
            checkoutbtn.Location = new Point(0, 320);
            checkoutbtn.Name = "checkoutbtn";
            checkoutbtn.Size = new Size(220, 60);
            checkoutbtn.TabIndex = 14;
            checkoutbtn.Text = "CheckOut";
            checkoutbtn.TextImageRelation = TextImageRelation.ImageBeforeText;
            checkoutbtn.UseVisualStyleBackColor = true;
            checkoutbtn.Click += checkoutbtn_Click;
            // 
            // iconser
            // 
            iconser.BackColor = Color.FromArgb(51, 51, 76);
            iconser.ForeColor = Color.Gainsboro;
            iconser.IconChar = FontAwesome.Sharp.IconChar.HandHoldingHeart;
            iconser.IconColor = Color.Gainsboro;
            iconser.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconser.Location = new Point(8, 337);
            iconser.Name = "iconser";
            iconser.Size = new Size(37, 32);
            iconser.TabIndex = 13;
            iconser.TabStop = false;
            // 
            // serbtn
            // 
            serbtn.Dock = DockStyle.Top;
            serbtn.FlatAppearance.BorderSize = 0;
            serbtn.FlatStyle = FlatStyle.Flat;
            serbtn.Font = new Font("Sitka Banner", 14.2499981F, FontStyle.Bold);
            serbtn.ForeColor = Color.Gainsboro;
            serbtn.Location = new Point(0, 260);
            serbtn.Name = "serbtn";
            serbtn.Size = new Size(220, 60);
            serbtn.TabIndex = 12;
            serbtn.Text = "Services";
            serbtn.TextImageRelation = TextImageRelation.ImageBeforeText;
            serbtn.UseVisualStyleBackColor = true;
            serbtn.Click += serbtn_Click_1;
            // 
            // iconfac
            // 
            iconfac.BackColor = Color.FromArgb(51, 51, 76);
            iconfac.ForeColor = Color.Gainsboro;
            iconfac.IconChar = FontAwesome.Sharp.IconChar.BuildingUser;
            iconfac.IconColor = Color.Gainsboro;
            iconfac.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconfac.Location = new Point(8, 271);
            iconfac.Name = "iconfac";
            iconfac.Size = new Size(37, 32);
            iconfac.TabIndex = 11;
            iconfac.TabStop = false;
            // 
            // iconres
            // 
            iconres.BackColor = Color.FromArgb(51, 51, 76);
            iconres.ForeColor = Color.Gainsboro;
            iconres.IconChar = FontAwesome.Sharp.IconChar.Ticket;
            iconres.IconColor = Color.Gainsboro;
            iconres.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconres.IconSize = 35;
            iconres.Location = new Point(8, 157);
            iconres.Name = "iconres";
            iconres.Size = new Size(35, 37);
            iconres.TabIndex = 9;
            iconres.TabStop = false;
            // 
            // iconmem
            // 
            iconmem.BackColor = Color.FromArgb(51, 51, 76);
            iconmem.ForeColor = Color.Gainsboro;
            iconmem.IconChar = FontAwesome.Sharp.IconChar.UserPlus;
            iconmem.IconColor = Color.Gainsboro;
            iconmem.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconmem.IconSize = 37;
            iconmem.Location = new Point(8, 216);
            iconmem.Name = "iconmem";
            iconmem.Size = new Size(37, 38);
            iconmem.TabIndex = 8;
            iconmem.TabStop = false;
            // 
            // iconbox2
            // 
            iconbox2.BackColor = Color.FromArgb(51, 51, 76);
            iconbox2.ForeColor = SystemColors.Control;
            iconbox2.IconChar = FontAwesome.Sharp.IconChar.UserLarge;
            iconbox2.IconColor = SystemColors.Control;
            iconbox2.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconbox2.IconSize = 37;
            iconbox2.Location = new Point(116, 266);
            iconbox2.Name = "iconbox2";
            iconbox2.Size = new Size(37, 37);
            iconbox2.TabIndex = 7;
            iconbox2.TabStop = false;
            // 
            // iconguest
            // 
            iconguest.BackColor = Color.FromArgb(51, 51, 76);
            iconguest.ForeColor = Color.Gainsboro;
            iconguest.IconChar = FontAwesome.Sharp.IconChar.PeopleLine;
            iconguest.IconColor = Color.Gainsboro;
            iconguest.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconguest.IconSize = 40;
            iconguest.Location = new Point(3, 92);
            iconguest.Name = "iconguest";
            iconguest.Size = new Size(40, 42);
            iconguest.TabIndex = 6;
            iconguest.TabStop = false;
            // 
            // Membershipbtn
            // 
            Membershipbtn.Dock = DockStyle.Top;
            Membershipbtn.FlatAppearance.BorderSize = 0;
            Membershipbtn.FlatStyle = FlatStyle.Flat;
            Membershipbtn.Font = new Font("Sitka Banner", 14.2499981F, FontStyle.Bold);
            Membershipbtn.ForeColor = Color.Gainsboro;
            Membershipbtn.Location = new Point(0, 200);
            Membershipbtn.Name = "Membershipbtn";
            Membershipbtn.Size = new Size(220, 60);
            Membershipbtn.TabIndex = 4;
            Membershipbtn.Text = "Membership";
            Membershipbtn.TextImageRelation = TextImageRelation.ImageBeforeText;
            Membershipbtn.UseVisualStyleBackColor = true;
            Membershipbtn.Click += Membershipbtn_Click;
            // 
            // Resbtn
            // 
            Resbtn.Dock = DockStyle.Top;
            Resbtn.FlatAppearance.BorderSize = 0;
            Resbtn.FlatStyle = FlatStyle.Flat;
            Resbtn.Font = new Font("Sitka Banner", 14.2499981F, FontStyle.Bold);
            Resbtn.ForeColor = SystemColors.ButtonShadow;
            Resbtn.Location = new Point(0, 140);
            Resbtn.Name = "Resbtn";
            Resbtn.Size = new Size(220, 60);
            Resbtn.TabIndex = 2;
            Resbtn.Text = "Reservation";
            Resbtn.UseVisualStyleBackColor = true;
            Resbtn.Click += Resbtn_Click;
            // 
            // Guestbtn
            // 
            Guestbtn.Dock = DockStyle.Top;
            Guestbtn.FlatAppearance.BorderSize = 0;
            Guestbtn.FlatStyle = FlatStyle.Flat;
            Guestbtn.Font = new Font("Sitka Banner", 14.2499981F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Guestbtn.ForeColor = Color.Gainsboro;
            Guestbtn.Location = new Point(0, 80);
            Guestbtn.Name = "Guestbtn";
            Guestbtn.Size = new Size(220, 60);
            Guestbtn.TabIndex = 1;
            Guestbtn.Text = "GuestInfo";
            Guestbtn.TextImageRelation = TextImageRelation.ImageBeforeText;
            Guestbtn.UseVisualStyleBackColor = true;
            Guestbtn.Click += Guestbtn_Click_1;
            // 
            // panellogo
            // 
            panellogo.BackColor = Color.FromArgb(39, 39, 58);
            panellogo.Controls.Add(iconPictureBox1);
            panellogo.Controls.Add(label1);
            panellogo.Dock = DockStyle.Top;
            panellogo.Location = new Point(0, 0);
            panellogo.Name = "panellogo";
            panellogo.Size = new Size(220, 80);
            panellogo.TabIndex = 0;
            // 
            // iconPictureBox1
            // 
            iconPictureBox1.BackColor = Color.FromArgb(39, 39, 58);
            iconPictureBox1.ForeColor = SystemColors.AppWorkspace;
            iconPictureBox1.IconChar = FontAwesome.Sharp.IconChar.Hotel;
            iconPictureBox1.IconColor = SystemColors.AppWorkspace;
            iconPictureBox1.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconPictureBox1.IconSize = 50;
            iconPictureBox1.Location = new Point(8, 12);
            iconPictureBox1.Name = "iconPictureBox1";
            iconPictureBox1.Size = new Size(50, 62);
            iconPictureBox1.TabIndex = 1;
            iconPictureBox1.TabStop = false;
            // 
            // label1
            // 
            label1.Font = new Font("Sitka Banner", 14.2499981F, FontStyle.Bold);
            label1.ForeColor = SystemColors.AppWorkspace;
            label1.Location = new Point(60, 9);
            label1.Name = "label1";
            label1.Size = new Size(160, 68);
            label1.TabIndex = 0;
            label1.Text = "Hotel Management \r\nSystem\r\n\r\n";
            // 
            // notifyIcon1
            // 
            notifyIcon1.Text = "notifyIcon1";
            notifyIcon1.Visible = true;
            // 
            // paneltitle
            // 
            paneltitle.BackColor = Color.FromArgb(39, 39, 58);
            paneltitle.Controls.Add(iconPictureBox4);
            paneltitle.Controls.Add(labeltitle);
            paneltitle.Dock = DockStyle.Top;
            paneltitle.Location = new Point(220, 0);
            paneltitle.Name = "paneltitle";
            paneltitle.Size = new Size(880, 80);
            paneltitle.TabIndex = 1;
            // 
            // iconPictureBox4
            // 
            iconPictureBox4.BackColor = Color.FromArgb(39, 39, 58);
            iconPictureBox4.ForeColor = SystemColors.AppWorkspace;
            iconPictureBox4.IconChar = FontAwesome.Sharp.IconChar.X;
            iconPictureBox4.IconColor = SystemColors.AppWorkspace;
            iconPictureBox4.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconPictureBox4.IconSize = 28;
            iconPictureBox4.Location = new Point(852, 0);
            iconPictureBox4.Name = "iconPictureBox4";
            iconPictureBox4.Size = new Size(28, 28);
            iconPictureBox4.TabIndex = 64;
            iconPictureBox4.TabStop = false;
            iconPictureBox4.Click += iconPictureBox4_Click;
            // 
            // labeltitle
            // 
            labeltitle.AutoSize = true;
            labeltitle.Font = new Font("Segoe UI", 16F);
            labeltitle.ForeColor = SystemColors.ControlLight;
            labeltitle.Location = new Point(325, 21);
            labeltitle.Name = "labeltitle";
            labeltitle.Size = new Size(73, 30);
            labeltitle.TabIndex = 0;
            labeltitle.Text = "Home";
            // 
            // paneldesktop
            // 
            paneldesktop.BackColor = SystemColors.ButtonShadow;
            paneldesktop.Dock = DockStyle.Fill;
            paneldesktop.Location = new Point(220, 80);
            paneldesktop.Name = "paneldesktop";
            paneldesktop.Size = new Size(880, 420);
            paneldesktop.TabIndex = 2;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1100, 500);
            Controls.Add(paneldesktop);
            Controls.Add(paneltitle);
            Controls.Add(panelMenu);
            FormBorderStyle = FormBorderStyle.None;
            Name = "Form1";
            Text = "Form1";
            panelMenu.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)iconroomD).EndInit();
            ((System.ComponentModel.ISupportInitialize)iconlog).EndInit();
            ((System.ComponentModel.ISupportInitialize)iconservice).EndInit();
            ((System.ComponentModel.ISupportInitialize)iconcheckout).EndInit();
            ((System.ComponentModel.ISupportInitialize)iconser).EndInit();
            ((System.ComponentModel.ISupportInitialize)iconfac).EndInit();
            ((System.ComponentModel.ISupportInitialize)iconres).EndInit();
            ((System.ComponentModel.ISupportInitialize)iconmem).EndInit();
            ((System.ComponentModel.ISupportInitialize)iconbox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)iconguest).EndInit();
            panellogo.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)iconPictureBox1).EndInit();
            paneltitle.ResumeLayout(false);
            paneltitle.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox4).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Panel panelMenu;
        private Panel panellogo;
        private Button Guestbtn;
        private Button Membershipbtn;
        private Button Resbtn;
        private NotifyIcon notifyIcon1;
        private FontAwesome.Sharp.IconPictureBox iconguest;
        private FontAwesome.Sharp.IconPictureBox iconbox2;
        private FontAwesome.Sharp.IconPictureBox iconmem;
        private Panel paneltitle;
        private Label labeltitle;
        private Panel paneldesktop;
        private FontAwesome.Sharp.IconPictureBox iconres;
        private FontAwesome.Sharp.IconPictureBox iconfac;
        private FontAwesome.Sharp.IconPictureBox iconser;
        private Button serbtn;
        private FontAwesome.Sharp.IconPictureBox iconcheckout;
        private Button checkoutbtn;
        private Label label1;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox1;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox4;
        private Button RoomDbtn;
        private FontAwesome.Sharp.IconPictureBox iconservice;
        private FontAwesome.Sharp.IconPictureBox iconlog;
        private Button logoutbtn;
        private FontAwesome.Sharp.IconPictureBox iconroomD;
    }
}

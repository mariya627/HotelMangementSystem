﻿namespace hotalMS
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            labeltitle = new Label();
            paneltitle = new Panel();
            iconPictureBox4 = new FontAwesome.Sharp.IconPictureBox();
            iconlog = new FontAwesome.Sharp.IconPictureBox();
            logoutbtn = new Button();
            notifyIcon1 = new NotifyIcon(components);
            label1 = new Label();
            iconroom = new FontAwesome.Sharp.IconPictureBox();
            icondetail = new FontAwesome.Sharp.IconPictureBox();
            viewdetailbtn = new Button();
            ManageRoombtn = new Button();
            Manageuserbtn = new Button();
            panellogo = new Panel();
            panelMenu = new Panel();
            iconuser = new FontAwesome.Sharp.IconPictureBox();
            paneldesktop = new Panel();
            paneltitle.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)iconlog).BeginInit();
            ((System.ComponentModel.ISupportInitialize)iconroom).BeginInit();
            ((System.ComponentModel.ISupportInitialize)icondetail).BeginInit();
            panellogo.SuspendLayout();
            panelMenu.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)iconuser).BeginInit();
            SuspendLayout();
            // 
            // labeltitle
            // 
            labeltitle.AutoSize = true;
            labeltitle.Font = new Font("Segoe UI", 16F);
            labeltitle.ForeColor = SystemColors.ControlLight;
            labeltitle.Location = new Point(325, 21);
            labeltitle.Name = "labeltitle";
            labeltitle.Size = new Size(73, 30);
            labeltitle.TabIndex = 0;
            labeltitle.Text = "Home";
            // 
            // paneltitle
            // 
            paneltitle.BackColor = Color.FromArgb(39, 39, 58);
            paneltitle.Controls.Add(iconPictureBox4);
            paneltitle.Controls.Add(labeltitle);
            paneltitle.Dock = DockStyle.Top;
            paneltitle.Location = new Point(220, 0);
            paneltitle.Name = "paneltitle";
            paneltitle.Size = new Size(880, 80);
            paneltitle.TabIndex = 4;
            // 
            // iconPictureBox4
            // 
            iconPictureBox4.BackColor = Color.FromArgb(39, 39, 58);
            iconPictureBox4.ForeColor = SystemColors.AppWorkspace;
            iconPictureBox4.IconChar = FontAwesome.Sharp.IconChar.X;
            iconPictureBox4.IconColor = SystemColors.AppWorkspace;
            iconPictureBox4.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconPictureBox4.IconSize = 28;
            iconPictureBox4.Location = new Point(852, 0);
            iconPictureBox4.Name = "iconPictureBox4";
            iconPictureBox4.Size = new Size(28, 28);
            iconPictureBox4.TabIndex = 64;
            iconPictureBox4.TabStop = false;
            // 
            // iconlog
            // 
            iconlog.BackColor = Color.FromArgb(51, 51, 76);
            iconlog.ForeColor = SystemColors.AppWorkspace;
            iconlog.IconChar = FontAwesome.Sharp.IconChar.SignOut;
            iconlog.IconColor = SystemColors.AppWorkspace;
            iconlog.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconlog.Location = new Point(8, 478);
            iconlog.Name = "iconlog";
            iconlog.Size = new Size(37, 32);
            iconlog.TabIndex = 68;
            iconlog.TabStop = false;
            // 
            // logoutbtn
            // 
            logoutbtn.Dock = DockStyle.Top;
            logoutbtn.FlatAppearance.BorderSize = 0;
            logoutbtn.FlatStyle = FlatStyle.Flat;
            logoutbtn.Font = new Font("Sitka Banner", 16.2499981F, FontStyle.Bold);
            logoutbtn.ForeColor = Color.Gainsboro;
            logoutbtn.Location = new Point(0, 437);
            logoutbtn.Name = "logoutbtn";
            logoutbtn.Size = new Size(220, 111);
            logoutbtn.TabIndex = 67;
            logoutbtn.Text = "LogOut";
            logoutbtn.TextImageRelation = TextImageRelation.ImageBeforeText;
            logoutbtn.UseVisualStyleBackColor = true;
            logoutbtn.Click += logoutbtn_Click;
            // 
            // notifyIcon1
            // 
            notifyIcon1.Text = "notifyIcon1";
            notifyIcon1.Visible = true;
            notifyIcon1.MouseDoubleClick += notifyIcon1_MouseDoubleClick;
            // 
            // label1
            // 
            label1.Font = new Font("Sitka Banner", 16.2499981F, FontStyle.Bold);
            label1.ForeColor = SystemColors.AppWorkspace;
            label1.Location = new Point(0, 0);
            label1.Name = "label1";
            label1.Size = new Size(220, 77);
            label1.TabIndex = 0;
            label1.Text = "Hotel Management \r\nSystem\r\n\r\n";
            // 
            // iconroom
            // 
            iconroom.BackColor = Color.FromArgb(51, 51, 76);
            iconroom.ForeColor = Color.Gainsboro;
            iconroom.IconChar = FontAwesome.Sharp.IconChar.Bed;
            iconroom.IconColor = Color.Gainsboro;
            iconroom.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconroom.IconSize = 42;
            iconroom.Location = new Point(3, 257);
            iconroom.Name = "iconroom";
            iconroom.Size = new Size(42, 45);
            iconroom.TabIndex = 9;
            iconroom.TabStop = false;
            // 
            // icondetail
            // 
            icondetail.BackColor = Color.FromArgb(51, 51, 76);
            icondetail.ForeColor = Color.Gainsboro;
            icondetail.IconChar = FontAwesome.Sharp.IconChar.Book;
            icondetail.IconColor = Color.Gainsboro;
            icondetail.IconFont = FontAwesome.Sharp.IconFont.Auto;
            icondetail.IconSize = 34;
            icondetail.Location = new Point(8, 374);
            icondetail.Name = "icondetail";
            icondetail.Size = new Size(34, 34);
            icondetail.TabIndex = 8;
            icondetail.TabStop = false;
            // 
            // viewdetailbtn
            // 
            viewdetailbtn.Dock = DockStyle.Top;
            viewdetailbtn.FlatAppearance.BorderSize = 0;
            viewdetailbtn.FlatStyle = FlatStyle.Flat;
            viewdetailbtn.Font = new Font("Sitka Banner", 16.2499981F, FontStyle.Bold);
            viewdetailbtn.ForeColor = Color.Gainsboro;
            viewdetailbtn.Location = new Point(0, 341);
            viewdetailbtn.Name = "viewdetailbtn";
            viewdetailbtn.Size = new Size(220, 96);
            viewdetailbtn.TabIndex = 4;
            viewdetailbtn.Text = "View Details";
            viewdetailbtn.TextImageRelation = TextImageRelation.ImageBeforeText;
            viewdetailbtn.UseVisualStyleBackColor = true;
            viewdetailbtn.Click += viewdetailbtn_Click;
            // 
            // ManageRoombtn
            // 
            ManageRoombtn.Dock = DockStyle.Top;
            ManageRoombtn.FlatAppearance.BorderSize = 0;
            ManageRoombtn.FlatStyle = FlatStyle.Flat;
            ManageRoombtn.Font = new Font("Sitka Banner", 16.2499981F, FontStyle.Bold);
            ManageRoombtn.ForeColor = SystemColors.AppWorkspace;
            ManageRoombtn.Location = new Point(0, 219);
            ManageRoombtn.Name = "ManageRoombtn";
            ManageRoombtn.Size = new Size(220, 122);
            ManageRoombtn.TabIndex = 2;
            ManageRoombtn.Text = "ManageRoom";
            ManageRoombtn.UseVisualStyleBackColor = true;
            ManageRoombtn.Click += ManageRoombtn_Click;
            // 
            // Manageuserbtn
            // 
            Manageuserbtn.Dock = DockStyle.Top;
            Manageuserbtn.FlatAppearance.BorderSize = 0;
            Manageuserbtn.FlatStyle = FlatStyle.Flat;
            Manageuserbtn.Font = new Font("Sitka Banner", 16.2499981F, FontStyle.Bold);
            Manageuserbtn.ForeColor = Color.Gainsboro;
            Manageuserbtn.Location = new Point(0, 80);
            Manageuserbtn.Name = "Manageuserbtn";
            Manageuserbtn.Size = new Size(220, 139);
            Manageuserbtn.TabIndex = 1;
            Manageuserbtn.Text = "ManageUsers";
            Manageuserbtn.TextImageRelation = TextImageRelation.ImageBeforeText;
            Manageuserbtn.UseVisualStyleBackColor = true;
            Manageuserbtn.Click += Manageuserbtn_Click;
            // 
            // panellogo
            // 
            panellogo.BackColor = Color.FromArgb(39, 39, 58);
            panellogo.Controls.Add(label1);
            panellogo.Dock = DockStyle.Top;
            panellogo.Location = new Point(0, 0);
            panellogo.Name = "panellogo";
            panellogo.Size = new Size(220, 80);
            panellogo.TabIndex = 0;
            // 
            // panelMenu
            // 
            panelMenu.BackColor = Color.FromArgb(51, 51, 76);
            panelMenu.Controls.Add(iconlog);
            panelMenu.Controls.Add(logoutbtn);
            panelMenu.Controls.Add(iconroom);
            panelMenu.Controls.Add(icondetail);
            panelMenu.Controls.Add(iconuser);
            panelMenu.Controls.Add(viewdetailbtn);
            panelMenu.Controls.Add(ManageRoombtn);
            panelMenu.Controls.Add(Manageuserbtn);
            panelMenu.Controls.Add(panellogo);
            panelMenu.Dock = DockStyle.Left;
            panelMenu.Location = new Point(0, 0);
            panelMenu.Name = "panelMenu";
            panelMenu.Size = new Size(220, 551);
            panelMenu.TabIndex = 3;
            // 
            // iconuser
            // 
            iconuser.BackColor = Color.FromArgb(51, 51, 76);
            iconuser.ForeColor = Color.Gainsboro;
            iconuser.IconChar = FontAwesome.Sharp.IconChar.PeopleLine;
            iconuser.IconColor = Color.Gainsboro;
            iconuser.IconFont = FontAwesome.Sharp.IconFont.Auto;
            iconuser.IconSize = 45;
            iconuser.Location = new Point(0, 128);
            iconuser.Name = "iconuser";
            iconuser.Size = new Size(45, 46);
            iconuser.TabIndex = 6;
            iconuser.TabStop = false;
            // 
            // paneldesktop
            // 
            paneldesktop.BackColor = SystemColors.AppWorkspace;
            paneldesktop.Dock = DockStyle.Fill;
            paneldesktop.Location = new Point(220, 80);
            paneldesktop.Name = "paneldesktop";
            paneldesktop.Size = new Size(880, 471);
            paneldesktop.TabIndex = 5;
            // 
            // Form2
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1100, 551);
            Controls.Add(paneldesktop);
            Controls.Add(paneltitle);
            Controls.Add(panelMenu);
            FormBorderStyle = FormBorderStyle.None;
            Name = "Form2";
            Text = "Form2";
            paneltitle.ResumeLayout(false);
            paneltitle.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)iconPictureBox4).EndInit();
            ((System.ComponentModel.ISupportInitialize)iconlog).EndInit();
            ((System.ComponentModel.ISupportInitialize)iconroom).EndInit();
            ((System.ComponentModel.ISupportInitialize)icondetail).EndInit();
            panellogo.ResumeLayout(false);
            panelMenu.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)iconuser).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Label labeltitle;
        private Panel paneltitle;
        private FontAwesome.Sharp.IconPictureBox iconPictureBox4;
        private FontAwesome.Sharp.IconPictureBox iconlog;
        private Button logoutbtn;
        private NotifyIcon notifyIcon1;
        private Label label1;
        private FontAwesome.Sharp.IconPictureBox iconroom;
        private FontAwesome.Sharp.IconPictureBox icondetail;
        private Button viewdetailbtn;
        private Button ManageRoombtn;
        private Button Manageuserbtn;
        private Panel panellogo;
        private Panel panelMenu;
        private FontAwesome.Sharp.IconPictureBox iconuser;
        private Panel paneldesktop;
    }
}